namespace CSharpVideoStudio;

/// <summary>Multi-clip selection. Tracks are resolved from the project on demand so they never go stale after a move.</summary>
public sealed class TimelineSelection
{
    private readonly Project _project;
    private readonly List<Clip> _clips = new();

    public TimelineSelection(Project project) => _project = project;

    public IReadOnlyList<Clip> Clips => _clips;
    public int Count => _clips.Count;

    /// <summary>Primary (last selected) clip.</summary>
    public Clip? Clip => _clips.Count > 0 ? _clips[^1] : null;
    public Track? Track => Clip is { } c ? TrackOf(c) : null;
    public bool HasSelection => _clips.Count > 0;

    public bool IsSelected(Clip clip) => _clips.Contains(clip);

    public Track? TrackOf(Clip clip) => _project.Tracks.FirstOrDefault(t => t.Clips.Contains(clip));

    /// <summary>Exclusive select. The track argument is kept for API compatibility.</summary>
    public void Select(Track track, Clip clip) => Select(clip);

    public void Select(Clip clip)
    {
        _clips.Clear();
        _clips.Add(clip);
    }

    public void Add(Clip clip)
    {
        _clips.Remove(clip);
        _clips.Add(clip);
    }

    /// <returns>true when the clip is selected afterwards.</returns>
    public bool Toggle(Clip clip)
    {
        if (_clips.Remove(clip)) return false;
        _clips.Add(clip);
        return true;
    }

    public void Clear() => _clips.Clear();

    /// <summary>Drops clips that no longer exist in the project (after delete / undo).</summary>
    public void Prune()
    {
        HashSet<Clip> alive = _project.Tracks.SelectMany(t => t.Clips).ToHashSet();
        _clips.RemoveAll(c => !alive.Contains(c));
    }
}
