﻿using CSharpVideoStudio.Timeline;

namespace CSharpVideoStudio;

/// <summary>Facade that owns the timeline interaction services. UI-agnostic.</summary>
public sealed class TimelineController
{
    public ProjectEditor Editor { get; }
    public TimelineSelection Selection { get; }
    public TimelineState State { get; } = new TimelineState();

    public TimelineCoordinateService Coordinates { get; } = new TimelineCoordinateService();
    public TimelineSnapEngine Snap { get; } = new TimelineSnapEngine();
    public TimelineAutoScrollService AutoScroll { get; } = new TimelineAutoScrollService();
    public TimelineDragController Drag { get; }
    public TimelineDropController Drop { get; }

    public TimelineController(Project project)
    {
        Editor = new ProjectEditor(project);
        Selection = new TimelineSelection(project);
        Coordinates.FrameRate = FrameRate.FromDouble(project.FrameRate);
        Drag = new TimelineDragController(Editor, Selection, Coordinates, Snap);
        Drop = new TimelineDropController(Editor, Coordinates, Snap);
    }

    public Project Project => Editor.Project;
    public TimeSpan Duration => Project.Duration;

    public void Select(Track track, Clip clip)
    {
        Selection.Select(clip);
        State.ActiveTrack = track;
        State.ActiveClip = clip;
    }

    public void ClearSelection()
    {
        Selection.Clear();
        State.ActiveTrack = null;
        State.ActiveClip = null;
    }

    public Clip? FindClipAt(TimeSpan position)
    {
        foreach (Track track in Project.Tracks)
        {
            Clip? clip = track.Clips.FirstOrDefault(x => position >= x.Start && position < x.End);
            if (clip != null) return clip;
        }
        return null;
    }

    /// <summary>
    /// The clip the preview monitor should show at <paramref name="position"/>: the first video/image clip.
    /// Audio clips never count, otherwise an audio track listed before the video track would hide the picture.
    /// </summary>
    public Clip? FindVisualClipAt(TimeSpan position)
    {
        foreach (Track track in Project.Tracks)
        {
            if (track.Type != TrackType.Video || !track.IsVisible) continue;
            Clip? clip = track.Clips.FirstOrDefault(x => position >= x.Start && position < x.End);
            if (clip != null) return clip;
        }
        return null;
    }

    public ValidationResult TrimClip(Track track, Clip clip, TimeSpan newSourceStart, TimeSpan newDuration, TimeSpan newStart) =>
        Editor.TryTrimClip(track, clip, newSourceStart, newDuration, newStart);

    /// <summary>Deletes every selected clip as one undo step. Clips on locked tracks are skipped.</summary>
    public int DeleteSelected()
    {
        List<IEditCommand> cmds = new();
        foreach (Clip c in Selection.Clips.ToList())
        {
            Track? t = Selection.TrackOf(c);
            if (t is null || t.IsLocked) continue;
            cmds.Add(new RemoveClipCommand(t, c));
        }
        if (cmds.Count > 0)
            Editor.Commands.Execute(new CompositeCommand(cmds, "Delete clips"));
        Selection.Prune();
        return cmds.Count;
    }

    public bool LinkSelected()
    {
        List<Clip> clips = Selection.Clips.ToList();
        if (clips.Count < 2) return false;
        Editor.Commands.Execute(new LinkClipsCommand(clips));
        return true;
    }

    /// <summary>Unlinks the whole link group of every selected clip.</summary>
    public bool UnlinkSelected()
    {
        HashSet<Guid> groups = Selection.Clips.Where(c => c.LinkGroupId.HasValue).Select(c => c.LinkGroupId!.Value).ToHashSet();
        if (groups.Count == 0) return false;
        List<Clip> members = Project.Tracks.SelectMany(t => t.Clips).Where(c => c.LinkGroupId is { } g && groups.Contains(g)).ToList();
        Editor.Commands.Execute(new UnlinkClipsCommand(members));
        return true;
    }

    /// <summary>Creates a linked audio clip for a video clip as ONE undo step.</summary>
    public AudioClip? ExtractAudio(Track sourceTrack, VideoClip videoClip)
    {
        if (videoClip.Media is null || videoClip.Duration <= TimeSpan.Zero) return null;

        AudioClip audio = new(videoClip.Media, videoClip.Start, videoClip.Duration, videoClip.SourceStart) { Volume = 1.0 };
        Track? track = TrackPicker.FindFreeTrack(Project, audio);
        Track? created = track is null ? TrackPicker.CreateTrack(Project, TrackType.Audio) : null;
        Track target = track ?? created!;

        List<IEditCommand> cmds = new();
        if (created is not null) cmds.Add(new AddTrackCommand(Project, created, Project.Tracks.Count));
        cmds.Add(new AddClipCommand(target, audio));
        cmds.Add(new LinkClipsCommand(new Clip[] { videoClip, audio }));
        Editor.Commands.Execute(new CompositeCommand(cmds, "Extract audio"));
        return audio;
    }

    public void Undo() { Editor.Undo(); Selection.Prune(); }
    public void Redo() { Editor.Redo(); Selection.Prune(); }
}
