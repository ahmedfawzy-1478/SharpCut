﻿namespace CSharpVideoStudio;

public sealed class AddClipCommand : IEditCommand
{
    private readonly Track _track;

    private readonly Clip _clip;

    public AddClipCommand(
        Track track,
        Clip clip)
    {
        _track = track;
        _clip = clip;
    }

    public void Execute()
    {
        if (!_track.Clips.Contains(_clip))
        {
            _track.AddClip(_clip);
        }
    }

    public void Undo()
    {
        _track.RemoveClip(_clip);
    }
}