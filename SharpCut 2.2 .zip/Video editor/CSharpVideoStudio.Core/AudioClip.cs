﻿using System;

namespace CSharpVideoStudio;

public class AudioClip : Clip
{
    public AudioClip() { }

    public AudioClip(MediaItem media, TimeSpan start, TimeSpan duration, TimeSpan sourceStart)
    {
        Media = media;
        Start = start;
        Duration = duration;
        SourceStart = sourceStart;
        Volume = 1.0;
        Opacity = 1.0;
        Speed = 1.0;
        Scale = 1.0;
        Rotation = 0.0;
    }

    public override Clip Clone()
    {
        return new AudioClip(Media, Start, Duration, SourceStart)
        {
            Id = Guid.NewGuid(),
            Muted = Muted,
            Volume = Volume,
            Opacity = Opacity,
            Speed = Speed,
            Scale = Scale,
            Rotation = Rotation
        };
    }
}