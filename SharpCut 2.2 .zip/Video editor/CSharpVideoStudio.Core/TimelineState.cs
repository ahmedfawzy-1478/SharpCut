namespace CSharpVideoStudio;

public sealed class TimelineState
{
    public TimeSpan Position { get; set; }

    public Track? ActiveTrack { get; set; }

    public Clip? ActiveClip { get; set; }
}
