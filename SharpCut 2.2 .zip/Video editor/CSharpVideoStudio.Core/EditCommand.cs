﻿namespace CSharpVideoStudio;

public interface IEditCommand
{
    void Execute();
    void Undo();
}