﻿namespace CSharpVideoStudio;

public enum TrackType
{
    Video,
    Audio
}