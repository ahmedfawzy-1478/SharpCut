namespace CSharpVideoStudio.Timeline;

/// <summary>Edge auto-scroll: speed ramps up (quadratically) as the pointer nears / passes the viewport edge.</summary>
public sealed class TimelineAutoScrollService
{
    public double EdgeZone { get; set; } = 60;
    public double MaxSpeed { get; set; } = 1400;   // px per second

    public (double Dx, double Dy) ComputeVelocity(double viewportX, double viewportY, double viewportWidth, double viewportHeight) =>
        (Axis(viewportX, viewportWidth), Axis(viewportY, viewportHeight));

    private double Axis(double pos, double size)
    {
        double zone = Math.Min(EdgeZone, size / 2);
        if (zone <= 0) return 0;
        if (pos < zone) return -MaxSpeed * Ramp((zone - pos) / zone);
        if (pos > size - zone) return MaxSpeed * Ramp((pos - (size - zone)) / zone);
        return 0;
    }

    private static double Ramp(double t)
    {
        t = Math.Clamp(t, 0, 1);
        return t * t;
    }

    /// <summary>Returns the new clamped scroll offsets after <paramref name="dt"/>.</summary>
    public (double X, double Y) Advance((double Dx, double Dy) velocity, TimeSpan dt,
        double offsetX, double offsetY, double maxX, double maxY) =>
        (Math.Clamp(offsetX + velocity.Dx * dt.TotalSeconds, 0, Math.Max(0, maxX)),
         Math.Clamp(offsetY + velocity.Dy * dt.TotalSeconds, 0, Math.Max(0, maxY)));
}
