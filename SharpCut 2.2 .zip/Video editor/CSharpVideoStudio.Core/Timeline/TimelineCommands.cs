namespace CSharpVideoStudio;

public sealed record ClipMove(Clip Clip, Track OldTrack, TimeSpan OldStart, Track NewTrack, TimeSpan NewStart);

/// <summary>One undo step for any number of clips (single drag, group drag, track change).</summary>
public sealed class MoveClipsCommand : IEditCommand
{
    private readonly IReadOnlyList<ClipMove> _moves;

    public MoveClipsCommand(IReadOnlyList<ClipMove> moves) => _moves = moves;

    public void Execute() => Apply(forward: true);
    public void Undo() => Apply(forward: false);

    private void Apply(bool forward)
    {
        // Remove all first, then add all: avoids transient overlaps and order dependence in a group move.
        foreach (ClipMove m in _moves)
            (forward ? m.OldTrack : m.NewTrack).Clips.Remove(m.Clip);

        foreach (ClipMove m in _moves)
        {
            m.Clip.Start = forward ? m.NewStart : m.OldStart;
            (forward ? m.NewTrack : m.OldTrack).Clips.Add(m.Clip);
        }

        foreach (Track t in _moves.SelectMany(m => new[] { m.OldTrack, m.NewTrack }).Distinct())
            t.SortClips();
    }
}

public sealed class CompositeCommand : IEditCommand
{
    private readonly IReadOnlyList<IEditCommand> _commands;
    public string Name { get; }

    public CompositeCommand(IReadOnlyList<IEditCommand> commands, string name)
    {
        _commands = commands;
        Name = name;
    }

    public void Execute() { foreach (IEditCommand c in _commands) c.Execute(); }
    public void Undo() { for (int i = _commands.Count - 1; i >= 0; i--) _commands[i].Undo(); }
}

public sealed class AddTrackCommand : IEditCommand
{
    private readonly Project _project;
    private readonly Track _track;
    private readonly int _index;

    public AddTrackCommand(Project project, Track track, int index)
    {
        _project = project;
        _track = track;
        _index = index;
    }

    public void Execute()
    {
        if (!_project.Tracks.Contains(_track))
            _project.Tracks.Insert(Math.Clamp(_index, 0, _project.Tracks.Count), _track);
    }

    public void Undo() => _project.Tracks.Remove(_track);
}

public sealed class LinkClipsCommand : IEditCommand
{
    private readonly IReadOnlyList<Clip> _clips;
    private readonly Dictionary<Clip, Guid?> _old;
    private readonly Guid _group = Guid.NewGuid();

    public LinkClipsCommand(IReadOnlyList<Clip> clips)
    {
        _clips = clips;
        _old = clips.ToDictionary(c => c, c => c.LinkGroupId);
    }

    public void Execute() { foreach (Clip c in _clips) c.LinkGroupId = _group; }
    public void Undo() { foreach (Clip c in _clips) c.LinkGroupId = _old[c]; }
}

public sealed class UnlinkClipsCommand : IEditCommand
{
    private readonly IReadOnlyList<Clip> _clips;
    private readonly Dictionary<Clip, Guid?> _old;

    public UnlinkClipsCommand(IReadOnlyList<Clip> clips)
    {
        _clips = clips;
        _old = clips.ToDictionary(c => c, c => c.LinkGroupId);
    }

    public void Execute() { foreach (Clip c in _clips) c.LinkGroupId = null; }
    public void Undo() { foreach (Clip c in _clips) c.LinkGroupId = _old[c]; }
}

public sealed class SetTrackLockedCommand : IEditCommand
{
    private readonly Track _track;
    private readonly bool _locked;
    private readonly bool _previous;

    public SetTrackLockedCommand(Track track, bool locked)
    {
        _track = track;
        _locked = locked;
        _previous = track.IsLocked;
    }

    public void Execute() => _track.IsLocked = _locked;
    public void Undo() => _track.IsLocked = _previous;
}
