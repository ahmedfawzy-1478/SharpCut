namespace CSharpVideoStudio;

public sealed class Marker
{
    public Guid Id { get; } = Guid.NewGuid();
    public TimeSpan Time { get; set; }
    public string Name { get; set; } = "";
}
