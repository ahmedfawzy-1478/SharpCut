namespace CSharpVideoStudio.Timeline;

/// <summary>Rational frame rate (e.g. 30000/1001). All conversions use integer math so there is no drift.</summary>
public readonly record struct FrameRate
{
    private const long TicksPerSecond = TimeSpan.TicksPerSecond;

    public int Numerator { get; }
    public int Denominator { get; }

    public FrameRate(int numerator, int denominator)
    {
        if (numerator <= 0) throw new ArgumentOutOfRangeException(nameof(numerator));
        if (denominator <= 0) throw new ArgumentOutOfRangeException(nameof(denominator));
        int g = Gcd(numerator, denominator);
        Numerator = numerator / g;
        Denominator = denominator / g;
    }

    public static FrameRate Fps24 => new(24, 1);
    public static FrameRate Fps23_976 => new(24000, 1001);
    public static FrameRate Fps25 => new(25, 1);
    public static FrameRate Fps29_97 => new(30000, 1001);
    public static FrameRate Fps30 => new(30, 1);
    public static FrameRate Fps50 => new(50, 1);
    public static FrameRate Fps59_94 => new(60000, 1001);
    public static FrameRate Fps60 => new(60, 1);

    public double Value => (double)Numerator / Denominator;

    /// <summary>Maps a double (e.g. 29.97) to the matching standard rational rate.</summary>
    public static FrameRate FromDouble(double fps)
    {
        if (double.IsNaN(fps) || fps <= 0) return Fps30;
        foreach (FrameRate known in new[] { Fps23_976, Fps29_97, Fps59_94 })
            if (Math.Abs(known.Value - fps) < 0.005) return known;
        return new FrameRate((int)Math.Round(fps * 1000), 1000);
    }

    /// <summary>Frame index containing <paramref name="time"/> (floor).</summary>
    public long TimeToFrame(TimeSpan time) =>
        FloorDiv((Int128)time.Ticks * Numerator, (Int128)Denominator * TicksPerSecond);

    /// <summary>
    /// Start time of a frame, rounded UP to the next tick. Rounding up (not to nearest) guarantees
    /// TimeToFrame(FrameToTime(n)) == n; nearest-rounding could land a tick before the frame boundary.
    /// </summary>
    public TimeSpan FrameToTime(long frame)
    {
        Int128 num = (Int128)frame * Denominator * TicksPerSecond;
        long ticks = (long)-FloorDiv(-num, Numerator);   // ceil(num / Numerator)
        return TimeSpan.FromTicks(ticks);
    }

    public TimeSpan SnapToFrame(TimeSpan time) =>
        FrameToTime((long)Math.Round(
            (double)((Int128)time.Ticks * Numerator) / ((double)Denominator * TicksPerSecond),
            MidpointRounding.AwayFromZero));

    public TimeSpan OneFrame => FrameToTime(1);

    private static long FloorDiv(Int128 a, Int128 b)
    {
        Int128 q = a / b;
        if (a % b != 0 && (a < 0) != (b < 0)) q--;
        return (long)q;
    }

    private static int Gcd(int a, int b) { while (b != 0) (a, b) = (b, a % b); return a; }
}
