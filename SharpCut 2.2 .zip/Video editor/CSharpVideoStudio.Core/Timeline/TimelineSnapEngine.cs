namespace CSharpVideoStudio.Timeline;

public enum SnapKind { Playhead, ClipStart, ClipEnd, Marker, InPoint, OutPoint, TimelineStart, TimelineEnd, Custom }

public readonly record struct SnapPoint(TimeSpan Time, SnapKind Kind);

public sealed class SnapContext
{
    public SnapContext(Project project, IReadOnlySet<Guid> excludedClips, TimeSpan playhead)
    {
        Project = project;
        ExcludedClips = excludedClips;
        Playhead = playhead;
    }
    public Project Project { get; }
    public IReadOnlySet<Guid> ExcludedClips { get; }
    public TimeSpan Playhead { get; }
}

/// <summary>Anything that can contribute snap targets. Add new sources without touching the engine.</summary>
public interface ISnapSource
{
    IEnumerable<SnapPoint> GetSnapPoints(SnapContext context);
}

public sealed class PlayheadSnapSource : ISnapSource
{
    public IEnumerable<SnapPoint> GetSnapPoints(SnapContext c) { yield return new(c.Playhead, SnapKind.Playhead); }
}

public sealed class ClipEdgeSnapSource : ISnapSource
{
    public IEnumerable<SnapPoint> GetSnapPoints(SnapContext c)
    {
        foreach (Track t in c.Project.Tracks)
            foreach (Clip clip in t.Clips)
            {
                if (c.ExcludedClips.Contains(clip.Id)) continue;
                yield return new(clip.Start, SnapKind.ClipStart);
                yield return new(clip.End, SnapKind.ClipEnd);
            }
    }
}

public sealed class MarkerSnapSource : ISnapSource
{
    public IEnumerable<SnapPoint> GetSnapPoints(SnapContext c)
    {
        foreach (Marker m in c.Project.Markers) yield return new(m.Time, SnapKind.Marker);
    }
}

public sealed class InOutSnapSource : ISnapSource
{
    public IEnumerable<SnapPoint> GetSnapPoints(SnapContext c)
    {
        if (c.Project.InPoint is { } i) yield return new(i, SnapKind.InPoint);
        if (c.Project.OutPoint is { } o) yield return new(o, SnapKind.OutPoint);
    }
}

public sealed class TimelineBoundsSnapSource : ISnapSource
{
    public IEnumerable<SnapPoint> GetSnapPoints(SnapContext c)
    {
        yield return new(TimeSpan.Zero, SnapKind.TimelineStart);
    }
}

public readonly record struct SnapResult(bool Snapped, TimeSpan Adjustment, SnapPoint? Point);

/// <summary>Sorted snap targets, built once per drag so MouseMove is a handful of binary searches.</summary>
public sealed class SnapIndex
{
    private readonly SnapPoint[] _points;
    public SnapIndex(IEnumerable<SnapPoint> points) =>
        _points = points.OrderBy(p => p.Time.Ticks).ToArray();

    public int Count => _points.Length;

    /// <summary>Best adjustment (point - edge) over all edges within the threshold; ties keep the first found.</summary>
    public SnapResult Snap(IReadOnlyList<TimeSpan> edges, TimeSpan threshold)
    {
        long best = long.MaxValue;
        SnapPoint? bestPoint = null;
        long bestAdjust = 0;

        foreach (TimeSpan edge in edges)
        {
            int idx = LowerBound(edge.Ticks);
            for (int k = idx - 1; k <= idx; k++)
            {
                if (k < 0 || k >= _points.Length) continue;
                long distance = Math.Abs(_points[k].Time.Ticks - edge.Ticks);
                if (distance <= threshold.Ticks && distance < best)
                {
                    best = distance;
                    bestPoint = _points[k];
                    bestAdjust = _points[k].Time.Ticks - edge.Ticks;
                }
            }
        }

        return bestPoint is null
            ? new SnapResult(false, TimeSpan.Zero, null)
            : new SnapResult(true, TimeSpan.FromTicks(bestAdjust), bestPoint);
    }

    private int LowerBound(long ticks)
    {
        int lo = 0, hi = _points.Length;
        while (lo < hi)
        {
            int mid = (lo + hi) / 2;
            if (_points[mid].Time.Ticks < ticks) lo = mid + 1; else hi = mid;
        }
        return lo;
    }
}

public sealed class TimelineSnapEngine
{
    private readonly List<ISnapSource> _sources = new()
    {
        new PlayheadSnapSource(), new ClipEdgeSnapSource(), new MarkerSnapSource(),
        new InOutSnapSource(), new TimelineBoundsSnapSource()
    };

    public bool Enabled { get; set; } = true;
    public double ThresholdPixels { get; set; } = 10;

    public void RegisterSource(ISnapSource source) => _sources.Add(source);

    public SnapIndex BuildIndex(SnapContext context) =>
        new(_sources.SelectMany(s => s.GetSnapPoints(context)));

    public TimeSpan ThresholdTime(ITimelineCoordinateService coords) =>
        coords.PixelsToDuration(ThresholdPixels);
}
