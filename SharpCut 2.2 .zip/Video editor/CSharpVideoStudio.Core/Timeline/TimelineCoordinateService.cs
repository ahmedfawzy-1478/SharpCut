namespace CSharpVideoStudio.Timeline;

/// <summary>
/// The single owner of Time &lt;-&gt; Pixel and Track &lt;-&gt; Y math. Views and view-models never do their own.
/// "Content" coordinates are relative to the scrollable canvas; "viewport" coordinates are relative to the visible area.
/// </summary>
public interface ITimelineCoordinateService
{
    double PixelsPerSecond { get; }
    double TrackHeight { get; }
    double HorizontalOffset { get; }
    double VerticalOffset { get; }
    FrameRate FrameRate { get; }

    double TimeToContentX(TimeSpan time);
    TimeSpan ContentXToTime(double x);
    double TimeToViewportX(TimeSpan time);
    TimeSpan ViewportXToTime(double x);
    double DurationToPixels(TimeSpan duration);
    TimeSpan PixelsToDuration(double pixels);

    double TrackTop(int trackIndex);
    /// <summary>-1 when above the first track; may be >= track count for empty rows below.</summary>
    int ContentYToTrackIndex(double y);
    double ViewportYToContentY(double y);
    double ViewportXToContentX(double x);

    long TimeToFrame(TimeSpan time);
    TimeSpan FrameToTime(long frame);
    TimeSpan SnapToFrame(TimeSpan time);
}

public sealed class TimelineCoordinateService : ITimelineCoordinateService
{
    public const double MinPixelsPerSecond = 0.05;
    public const double MaxPixelsPerSecond = 20000;

    private double _pps = 80;

    public double PixelsPerSecond
    {
        get => _pps;
        set => _pps = Math.Clamp(value, MinPixelsPerSecond, MaxPixelsPerSecond);
    }

    public double TrackHeight { get; set; } = 65;
    public double HorizontalOffset { get; set; }
    public double VerticalOffset { get; set; }
    public FrameRate FrameRate { get; set; } = FrameRate.Fps30;

    public double TimeToContentX(TimeSpan time) => time.Ticks * _pps / TimeSpan.TicksPerSecond;

    public TimeSpan ContentXToTime(double x) =>
        TimeSpan.FromTicks((long)Math.Round(x / _pps * TimeSpan.TicksPerSecond));

    public double TimeToViewportX(TimeSpan time) => TimeToContentX(time) - HorizontalOffset;
    public TimeSpan ViewportXToTime(double x) => ContentXToTime(x + HorizontalOffset);
    public double DurationToPixels(TimeSpan duration) => TimeToContentX(duration);
    public TimeSpan PixelsToDuration(double pixels) => ContentXToTime(pixels);

    public double TrackTop(int trackIndex) => trackIndex * TrackHeight;

    public int ContentYToTrackIndex(double y) => y < 0 ? -1 : (int)Math.Floor(y / TrackHeight);
    public double ViewportYToContentY(double y) => y + VerticalOffset;
    public double ViewportXToContentX(double x) => x + HorizontalOffset;

    public long TimeToFrame(TimeSpan time) => FrameRate.TimeToFrame(time);
    public TimeSpan FrameToTime(long frame) => FrameRate.FrameToTime(frame);
    public TimeSpan SnapToFrame(TimeSpan time) => FrameRate.SnapToFrame(time);
}
