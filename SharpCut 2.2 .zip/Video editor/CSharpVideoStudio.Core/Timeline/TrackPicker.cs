namespace CSharpVideoStudio.Timeline;

public static class TrackPicker
{
    public static TrackType RequiredType(Clip clip) => clip is AudioClip ? TrackType.Audio : TrackType.Video;

    /// <summary>First compatible, unlocked track where the clip fits; otherwise null (caller creates a track).</summary>
    public static Track? FindFreeTrack(Project project, Clip clip)
    {
        foreach (Track t in project.Tracks)
        {
            if (t.IsLocked || !t.CanAccept(clip)) continue;
            if (!t.HasOverlap(clip)) return t;
        }
        return null;
    }

    public static Track CreateTrack(Project project, TrackType type)
    {
        int n = project.Tracks.Count(t => t.Type == type) + 1;
        return new Track(type == TrackType.Video ? $"Video {n}" : $"Audio {n}", type);
    }
}
