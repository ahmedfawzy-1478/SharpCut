namespace CSharpVideoStudio.Timeline;

public sealed record DropPreview(bool IsValid, string? Message, int TrackIndex, TimeSpan Start, TimeSpan Duration,
    bool CreatesTrack, SnapPoint? Snap);

public sealed record DropOutcome(bool Success, Clip? Clip, string? Message);

/// <summary>Turns "a media item was dropped here" into a real, validated, undoable model change.</summary>
public sealed class TimelineDropController
{
    public static readonly TimeSpan DefaultImageDuration = TimeSpan.FromSeconds(5);

    private readonly ProjectEditor _editor;
    private readonly ITimelineCoordinateService _coords;
    private readonly TimelineSnapEngine _snap;

    public TimelineDropController(ProjectEditor editor, ITimelineCoordinateService coords, TimelineSnapEngine snap)
    {
        _editor = editor;
        _coords = coords;
        _snap = snap;
    }

    private sealed record Plan(Clip? Clip, Track? Track, Track? NewTrack, int TrackIndex, ValidationResult Validation, SnapPoint? Snap);

    public static Clip? CreateClip(MediaItem media, TimeSpan start) => media.Type switch
    {
        MediaType.Video => new VideoClip(media, start, media.Duration, TimeSpan.Zero),
        MediaType.Audio => new AudioClip(media, start, media.Duration, TimeSpan.Zero),
        MediaType.Image => new ImageClip(media, start, media.Duration > TimeSpan.Zero ? media.Duration : DefaultImageDuration),
        _ => null
    };

    public DropPreview Preview(MediaItem media, double x, double y, TimeSpan playhead, PointerModifiers mods = PointerModifiers.None)
    {
        Plan p = PlanAt(media, x, y, playhead, mods);
        return new DropPreview(p.Validation.IsValid, p.Validation.IsValid ? null : p.Validation.Message,
            p.TrackIndex, p.Clip?.Start ?? TimeSpan.Zero, p.Clip?.Duration ?? TimeSpan.Zero, p.NewTrack is not null, p.Snap);
    }

    public DropOutcome Drop(MediaItem media, double x, double y, TimeSpan playhead, PointerModifiers mods = PointerModifiers.None) =>
        Execute(PlanAt(media, x, y, playhead, mods));

    /// <summary>Double-click / "Add to timeline": at the playhead on the first track with room, else a new track.</summary>
    public DropOutcome AddAtPlayhead(MediaItem media, TimeSpan playhead)
    {
        Clip? clip = CreateClip(media, _coords.SnapToFrame(playhead < TimeSpan.Zero ? TimeSpan.Zero : playhead));
        if (clip is null)
            return new DropOutcome(false, null, "Media is not valid.");

        ValidationResult v = _editor.Validation.ValidateNewClip(_editor.Project, null, clip);
        if (!v.IsValid)
            return new DropOutcome(false, null, v.Message);

        Track? track = TrackPicker.FindFreeTrack(_editor.Project, clip);
        Track? created = track is null ? TrackPicker.CreateTrack(_editor.Project, TrackPicker.RequiredType(clip)) : null;
        return Execute(new Plan(clip, track, created, track is null ? _editor.Project.Tracks.Count : _editor.Project.Tracks.IndexOf(track), v, null));
    }

    private Plan PlanAt(MediaItem media, double x, double y, TimeSpan playhead, PointerModifiers mods)
    {
        Project project = _editor.Project;
        TimeSpan start = _coords.SnapToFrame(_coords.ContentXToTime(x));
        if (start < TimeSpan.Zero) start = TimeSpan.Zero;

        Clip? clip = CreateClip(media, start);
        if (clip is null)
            return new Plan(null, null, null, 0, ValidationResult.Fail(Rejection.InvalidMedia, "Media is not valid."), null);

        SnapPoint? snap = null;
        if (_snap.Enabled && (mods & PointerModifiers.Alt) == 0 && clip.Duration > TimeSpan.Zero)
        {
            SnapIndex index = _snap.BuildIndex(new SnapContext(project, new HashSet<Guid>(), playhead));
            SnapResult r = index.Snap(new[] { clip.Start, clip.End }, _snap.ThresholdTime(_coords));
            if (r.Snapped && clip.Start + r.Adjustment >= TimeSpan.Zero)
            {
                clip.Start += r.Adjustment;
                snap = r.Point;
            }
        }

        int index2 = Math.Max(0, _coords.ContentYToTrackIndex(y));
        if (index2 >= project.Tracks.Count)
        {
            Track created = TrackPicker.CreateTrack(project, TrackPicker.RequiredType(clip));
            return new Plan(clip, null, created, project.Tracks.Count, _editor.Validation.ValidateNewClip(project, null, clip), snap);
        }

        Track target = project.Tracks[index2];
        return new Plan(clip, target, null, index2, _editor.Validation.ValidateNewClip(project, target, clip), snap);
    }

    private DropOutcome Execute(Plan plan)
    {
        if (!plan.Validation.IsValid || plan.Clip is null)
            return new DropOutcome(false, null, plan.Validation.Message);   // model untouched

        if (plan.NewTrack is not null)
        {
            _editor.Commands.Execute(new CompositeCommand(new IEditCommand[]
            {
                new AddTrackCommand(_editor.Project, plan.NewTrack, plan.TrackIndex),
                new AddClipCommand(plan.NewTrack, plan.Clip)
            }, "Add clip on new track"));
        }
        else
        {
            _editor.Commands.Execute(new AddClipCommand(plan.Track!, plan.Clip));
        }

        return new DropOutcome(true, plan.Clip, null);
    }
}
