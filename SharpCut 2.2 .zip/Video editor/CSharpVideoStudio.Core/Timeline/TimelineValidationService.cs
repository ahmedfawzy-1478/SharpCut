namespace CSharpVideoStudio.Timeline;

public enum Rejection
{
    None, NothingToMove, TrackLocked, TrackTypeMismatch, TrackMissing,
    Overlap, NegativeTime, InvalidDuration, InvalidMedia
}

public sealed record ValidationResult(bool IsValid, Rejection Reason, string Message)
{
    public static ValidationResult Ok { get; } = new(true, Rejection.None, "");
    public static ValidationResult Fail(Rejection reason, string message) => new(false, reason, message);
}

public sealed record PlannedMove(Clip Clip, Track SourceTrack, Track TargetTrack, TimeSpan NewStart);

/// <summary>All timeline edit rules live here so drag preview, commit, drop and tests agree.</summary>
public sealed class TimelineValidationService
{
    public static bool IsCompatible(Track track, Clip clip) => track.CanAccept(clip);

    public ValidationResult ValidateMoves(Project project, IReadOnlyList<PlannedMove> moves)
    {
        if (moves.Count == 0)
            return ValidationResult.Fail(Rejection.NothingToMove, "Nothing to move.");

        HashSet<Guid> moving = moves.Select(m => m.Clip.Id).ToHashSet();

        foreach (PlannedMove m in moves)
        {
            if (m.Clip.Duration <= TimeSpan.Zero)
                return ValidationResult.Fail(Rejection.InvalidDuration, "A clip has an invalid duration.");
            if (m.NewStart < TimeSpan.Zero)
                return ValidationResult.Fail(Rejection.NegativeTime, "Clips can't start before 00:00.");
            if (m.SourceTrack.IsLocked)
                return ValidationResult.Fail(Rejection.TrackLocked, $"Track \"{m.SourceTrack.Name}\" is locked.");
            if (m.TargetTrack.IsLocked)
                return ValidationResult.Fail(Rejection.TrackLocked, $"Track \"{m.TargetTrack.Name}\" is locked.");
            if (!project.Tracks.Contains(m.TargetTrack))
                return ValidationResult.Fail(Rejection.TrackMissing, "Target track doesn't exist.");
            if (!IsCompatible(m.TargetTrack, m.Clip))
                return ValidationResult.Fail(Rejection.TrackTypeMismatch,
                    m.TargetTrack.Type == TrackType.Audio
                        ? "Video clips can't be placed on audio tracks."
                        : "Audio clips can't be placed on video tracks.");
        }

        foreach (IGrouping<Track, PlannedMove> group in moves.GroupBy(m => m.TargetTrack))
        {
            List<PlannedMove> planned = group.ToList();

            foreach (PlannedMove m in planned)
            {
                TimeSpan end = m.NewStart + m.Clip.Duration;

                foreach (Clip other in group.Key.Clips)
                    if (!moving.Contains(other.Id) && m.NewStart < other.End && end > other.Start)
                        return ValidationResult.Fail(Rejection.Overlap, "Overlaps another clip.");

                foreach (PlannedMove o in planned)
                    if (!ReferenceEquals(o, m) && m.NewStart < o.NewStart + o.Clip.Duration && end > o.NewStart)
                        return ValidationResult.Fail(Rejection.Overlap, "Moved clips would overlap each other.");
            }
        }

        return ValidationResult.Ok;
    }

    public ValidationResult ValidateTrim(Project project, Track track, Clip clip,
        TimeSpan newStart, TimeSpan newSourceStart, TimeSpan newDuration)
    {
        if (track.IsLocked)
            return ValidationResult.Fail(Rejection.TrackLocked, $"Track \"{track.Name}\" is locked.");
        if (newDuration <= TimeSpan.Zero)
            return ValidationResult.Fail(Rejection.InvalidDuration, "Clip can't be shorter than one frame.");
        if (newStart < TimeSpan.Zero || newSourceStart < TimeSpan.Zero)
            return ValidationResult.Fail(Rejection.NegativeTime, "Can't trim before the start of the media or timeline.");

        TimeSpan end = newStart + newDuration;
        foreach (Clip other in track.Clips)
            if (!ReferenceEquals(other, clip) && newStart < other.End && end > other.Start)
                return ValidationResult.Fail(Rejection.Overlap, "Overlaps another clip.");

        return ValidationResult.Ok;
    }

    /// <summary>Validates adding a brand-new clip. <paramref name="track"/> null means "on a new track of the right type".</summary>
    public ValidationResult ValidateNewClip(Project project, Track? track, Clip clip)
    {
        if (clip.Media is null || string.IsNullOrWhiteSpace(clip.Media.FilePath))
            return ValidationResult.Fail(Rejection.InvalidMedia, "Media is not valid.");
        if (clip.Duration <= TimeSpan.Zero)
            return ValidationResult.Fail(Rejection.InvalidDuration, "Media duration is unknown or zero.");
        if (clip.Start < TimeSpan.Zero)
            return ValidationResult.Fail(Rejection.NegativeTime, "Clips can't start before 00:00.");
        if (track is null)
            return ValidationResult.Ok;
        if (track.IsLocked)
            return ValidationResult.Fail(Rejection.TrackLocked, $"Track \"{track.Name}\" is locked.");
        if (!IsCompatible(track, clip))
            return ValidationResult.Fail(Rejection.TrackTypeMismatch,
                track.Type == TrackType.Audio ? "Video can't go on an audio track." : "Audio can't go on a video track.");
        foreach (Clip other in track.Clips)
            if (clip.Start < other.End && clip.End > other.Start)
                return ValidationResult.Fail(Rejection.Overlap, "Overlaps another clip.");
        return ValidationResult.Ok;
    }
}
