namespace CSharpVideoStudio.Timeline;

public enum DragState { Idle, PotentialDrag, Dragging }
public enum DragKind { Move, TrimLeft, TrimRight }
public enum DragResult { None, Click, Committed, NoChange, Rejected, Cancelled }

[Flags]
public enum PointerModifiers { None = 0, Shift = 1, Ctrl = 2, Alt = 4 }

public sealed record DragOutcome(DragResult Result, string? Message = null);
public sealed record GhostClip(Guid ClipId, int TrackIndex, TimeSpan Start, TimeSpan Duration, bool IsValid);

public sealed record DragPreview(
    bool IsValid, Rejection Reason, string? Message, int TargetTrackIndex,
    IReadOnlyList<GhostClip> Ghosts, SnapPoint? Snap, TimeSpan PrimaryStart);

/// <summary>
/// Pointer drag state machine: Idle -> PotentialDrag -> Dragging -> (Commit | Cancel).
/// It never touches the model while dragging. It only produces a <see cref="DragPreview"/>;
/// on release it executes ONE command through the editor. Works in content coordinates (UI-agnostic).
/// </summary>
public sealed class TimelineDragController
{
    public const double MinDragDistancePixels = 4;

    private sealed record Moving(Clip Clip, Track Source, TimeSpan OriginalStart);

    private readonly ProjectEditor _editor;
    private readonly TimelineSelection _selection;
    private readonly ITimelineCoordinateService _coords;
    private readonly TimelineSnapEngine _snap;

    private double _downX, _downY;
    private Clip? _clip;
    private DragKind _kind;
    private PointerModifiers _downMods;
    private TimeSpan _playhead;
    private TimeSpan _grabOffset;

    private List<Moving> _moving = new();
    private Moving? _primary;
    private TimeSpan _minDelta;
    private SnapIndex? _snapIndex;
    private TimeSpan[] _edges = Array.Empty<TimeSpan>();
    private Dictionary<Track, int> _trackIndex = new();
    private Dictionary<Track, int> _ordinal = new();
    private List<Track> _primaryTypeTracks = new();

    private DragPreview? _preview;
    private IReadOnlyList<PlannedMove> _planned = Array.Empty<PlannedMove>();
    private TrimPlan? _trimPlan;
    private (long, long, int, bool, Rejection)? _lastKey;

    private sealed record TrimPlan(Track Track, Clip Clip, TimeSpan NewStart, TimeSpan NewSource, TimeSpan NewDuration);

    public TimelineDragController(ProjectEditor editor, TimelineSelection selection,
        ITimelineCoordinateService coords, TimelineSnapEngine snap)
    {
        _editor = editor;
        _selection = selection;
        _coords = coords;
        _snap = snap;
    }

    public DragState State { get; private set; } = DragState.Idle;
    public DragPreview? Preview => _preview;

    public event Action? Started;
    public event Action<DragPreview>? PreviewChanged;
    public event Action<DragOutcome>? Ended;

    /// <returns>true when the selection changed (the view should refresh selection visuals, not rebuild).</returns>
    public bool PointerDown(double x, double y, Clip clip, DragKind kind, PointerModifiers mods, TimeSpan playhead)
    {
        if (State != DragState.Idle)
            Cancel();

        bool changed = false;
        if ((mods & PointerModifiers.Ctrl) != 0)
        {
            _selection.Toggle(clip);
            return true;                        // Ctrl-click toggles only, never starts a drag
        }
        if ((mods & PointerModifiers.Shift) != 0)
        {
            if (!_selection.IsSelected(clip)) { _selection.Add(clip); changed = true; }
        }
        else if (!_selection.IsSelected(clip))
        {
            _selection.Select(clip);
            changed = true;
        }

        _downX = x; _downY = y;
        _clip = clip;
        _kind = kind;
        _downMods = mods;
        _playhead = playhead;

        TimeSpan pointerTime = _coords.ContentXToTime(x);
        _grabOffset = kind switch
        {
            DragKind.TrimRight => pointerTime - clip.End,
            _ => pointerTime - clip.Start          // Move & TrimLeft: offset from the clip start (no jump)
        };

        State = DragState.PotentialDrag;
        return changed;
    }

    public void PointerMove(double x, double y, PointerModifiers mods = PointerModifiers.None)
    {
        if (State == DragState.Idle || _clip is null) return;

        if (State == DragState.PotentialDrag)
        {
            double dx = x - _downX, dy = y - _downY;
            if (dx * dx + dy * dy < MinDragDistancePixels * MinDragDistancePixels) return;
            BeginDrag();
            if (_moving.Count == 0) { Cancel(); return; }   // clip vanished from the project
        }

        DragPreview preview = _kind == DragKind.Move ? ComputeMove(x, y, mods) : ComputeTrim(x, mods);
        (long, long, int, bool, Rejection) key =
            (preview.PrimaryStart.Ticks, preview.Ghosts.Count > 0 ? preview.Ghosts[0].Duration.Ticks : 0,
             preview.TargetTrackIndex, preview.IsValid, preview.Reason);

        _preview = preview;
        if (_lastKey != key)
        {
            _lastKey = key;
            PreviewChanged?.Invoke(preview);
        }
    }

    public DragOutcome PointerUp(double x, double y, PointerModifiers mods = PointerModifiers.None)
    {
        if (State == DragState.Idle || _clip is null)
            return new DragOutcome(DragResult.None);

        if (State == DragState.PotentialDrag)
        {
            // A click, not a drag: a plain click on one member of a multi-selection selects just that clip.
            if (_selection.Count > 1 && (_downMods & (PointerModifiers.Ctrl | PointerModifiers.Shift)) == 0)
                _selection.Select(_clip);
            Reset();
            DragOutcome click = new(DragResult.Click);
            Ended?.Invoke(click);
            return click;
        }

        PointerMove(x, y, mods);                // final position
        DragOutcome outcome = Commit();
        Reset();
        Ended?.Invoke(outcome);
        return outcome;
    }

    /// <summary>Escape / lost capture. The model was never modified, so nothing needs to be rolled back.</summary>
    public void Cancel()
    {
        if (State == DragState.Idle) return;
        bool wasDragging = State == DragState.Dragging;
        Reset();
        if (wasDragging) Ended?.Invoke(new DragOutcome(DragResult.Cancelled));
    }

    private void Reset()
    {
        State = DragState.Idle;
        _clip = null;
        _preview = null;
        _planned = Array.Empty<PlannedMove>();
        _trimPlan = null;
        _moving = new();
        _primary = null;
        _snapIndex = null;
        _lastKey = null;
    }

    // ------------------------------------------------------------------ begin

    private void BeginDrag()
    {
        Project project = _editor.Project;
        _trackIndex = new Dictionary<Track, int>();
        for (int i = 0; i < project.Tracks.Count; i++) _trackIndex[project.Tracks[i]] = i;

        Dictionary<Guid, Track> owner = new();
        foreach (Track t in project.Tracks)
            foreach (Clip c in t.Clips) owner[c.Id] = t;

        _moving = new List<Moving>();
        if (_kind == DragKind.Move)
        {
            HashSet<Guid> groups = _selection.Clips.Where(c => c.LinkGroupId.HasValue).Select(c => c.LinkGroupId!.Value).ToHashSet();
            HashSet<Guid> ids = new();
            foreach (Clip c in _selection.Clips)
                if (owner.ContainsKey(c.Id) && ids.Add(c.Id)) _moving.Add(new Moving(c, owner[c.Id], c.Start));
            if (groups.Count > 0)
                foreach (Track t in project.Tracks)
                    foreach (Clip c in t.Clips)
                        if (c.LinkGroupId is { } g && groups.Contains(g) && ids.Add(c.Id))
                            _moving.Add(new Moving(c, t, c.Start));
        }
        else if (owner.TryGetValue(_clip!.Id, out Track? t))
        {
            _moving.Add(new Moving(_clip, t, _clip.Start));
        }

        _primary = _moving.FirstOrDefault(m => ReferenceEquals(m.Clip, _clip)) ?? _moving.FirstOrDefault();
        _minDelta = _moving.Count == 0 ? TimeSpan.Zero : -_moving.Min(m => m.OriginalStart);

        TrackType primaryType = _primary is null ? TrackType.Video : _primary.Source.Type;
        _primaryTypeTracks = project.Tracks.Where(t => t.Type == primaryType).ToList();
        _ordinal = new Dictionary<Track, int>();
        for (int i = 0; i < _primaryTypeTracks.Count; i++) _ordinal[_primaryTypeTracks[i]] = i;

        HashSet<Guid> excluded = _moving.Select(m => m.Clip.Id).ToHashSet();
        _snapIndex = _snap.BuildIndex(new SnapContext(project, excluded, _playhead));
        _edges = new TimeSpan[_kind == DragKind.Move ? _moving.Count * 2 : 1];

        State = DragState.Dragging;
        Started?.Invoke();
    }

    // ------------------------------------------------------------------ move

    private DragPreview ComputeMove(double x, double y, PointerModifiers mods)
    {
        if (_primary is null)
            return Invalid(Rejection.NothingToMove, "Nothing to move.", 0, TimeSpan.Zero);

        TimeSpan primaryStart = _primary.OriginalStart;
        TimeSpan pointerTime = _coords.ContentXToTime(x);
        TimeSpan delta = _coords.SnapToFrame(pointerTime - _grabOffset) - primaryStart;
        if (delta < _minDelta) delta = _minDelta;

        SnapPoint? snap = null;
        if (_snap.Enabled && (mods & PointerModifiers.Alt) == 0 && _snapIndex is not null)
        {
            for (int i = 0; i < _moving.Count; i++)
            {
                _edges[i * 2] = _moving[i].OriginalStart + delta;
                _edges[i * 2 + 1] = _moving[i].OriginalStart + _moving[i].Clip.Duration + delta;
            }
            SnapResult r = _snapIndex.Snap(_edges, _snap.ThresholdTime(_coords));
            if (r.Snapped)
            {
                delta += r.Adjustment;
                snap = r.Point;
                if (delta < _minDelta) { delta = _minDelta; snap = null; }
            }
        }

        Project project = _editor.Project;
        int hovered = Math.Max(0, _coords.ContentYToTrackIndex(y));

        if (hovered >= project.Tracks.Count)
            return Invalid(Rejection.TrackMissing, "Drop on an existing track.", hovered, primaryStart + delta, delta);

        Track target = project.Tracks[hovered];
        if (!TimelineValidationService.IsCompatible(target, _primary.Clip))
            return Invalid(Rejection.TrackTypeMismatch,
                target.Type == TrackType.Audio ? "Video clips can't be placed on audio tracks."
                                               : "Audio clips can't be placed on video tracks.",
                hovered, primaryStart + delta, delta);

        // Vertical movement is expressed in "tracks of the primary's type"; clips of the other type
        // (linked partners / mixed selection) keep their own track and only move in time.
        int ordDelta = _ordinal[target] - _ordinal[_primary.Source];
        List<PlannedMove> planned = new(_moving.Count);
        foreach (Moving m in _moving)
        {
            Track dest = m.Source;
            if (m.Source.Type == _primary.Source.Type)
            {
                int ord = _ordinal[m.Source] + ordDelta;
                if (ord < 0 || ord >= _primaryTypeTracks.Count)
                    return Invalid(Rejection.TrackMissing, "Not enough tracks for the whole group.", hovered, primaryStart + delta, delta);
                dest = _primaryTypeTracks[ord];
            }
            planned.Add(new PlannedMove(m.Clip, m.Source, dest, m.OriginalStart + delta));
        }

        ValidationResult v = _editor.Validation.ValidateMoves(project, planned);
        _planned = planned;

        List<GhostClip> ghosts = new(planned.Count);
        foreach (PlannedMove p in planned)
            ghosts.Add(new GhostClip(p.Clip.Id, _trackIndex[p.TargetTrack], p.NewStart, p.Clip.Duration, v.IsValid));

        return new DragPreview(v.IsValid, v.Reason, v.IsValid ? null : v.Message, hovered, ghosts, v.IsValid ? snap : null, primaryStart + delta);
    }

    private DragPreview Invalid(Rejection reason, string message, int hovered, TimeSpan primaryStart, TimeSpan? delta = null)
    {
        _planned = Array.Empty<PlannedMove>();
        List<GhostClip> ghosts = new(_moving.Count);
        foreach (Moving m in _moving)
        {
            bool isPrimary = ReferenceEquals(m, _primary);
            int row = isPrimary ? hovered : _trackIndex[m.Source];
            ghosts.Add(new GhostClip(m.Clip.Id, row, m.OriginalStart + (delta ?? TimeSpan.Zero), m.Clip.Duration, false));
        }
        return new DragPreview(false, reason, message, hovered, ghosts, null, primaryStart);
    }

    // ------------------------------------------------------------------ trim

    private DragPreview ComputeTrim(double x, PointerModifiers mods)
    {
        Moving m = _moving[0];
        Clip clip = m.Clip;
        TimeSpan one = _coords.FrameRate.OneFrame;
        TimeSpan edge = _coords.SnapToFrame(_coords.ContentXToTime(x) - _grabOffset);

        SnapPoint? snap = null;
        if (_snap.Enabled && (mods & PointerModifiers.Alt) == 0 && _snapIndex is not null)
        {
            _edges[0] = edge;
            SnapResult r = _snapIndex.Snap(_edges, _snap.ThresholdTime(_coords));
            if (r.Snapped) { edge += r.Adjustment; snap = r.Point; }
        }

        TimeSpan newStart = clip.Start, newSource = clip.SourceStart, newDuration = clip.Duration;
        if (_kind == DragKind.TrimLeft)
        {
            TimeSpan minStart = TimeSpan.FromTicks(Math.Max(0, (clip.Start - clip.SourceStart).Ticks));
            edge = TimeSpan.FromTicks(Math.Clamp(edge.Ticks, minStart.Ticks, (clip.End - one).Ticks));
            newStart = edge;
            newSource = clip.SourceStart + (edge - clip.Start);
            newDuration = clip.End - edge;
        }
        else
        {
            if (edge < clip.Start + one) edge = clip.Start + one;
            newDuration = edge - clip.Start;
        }

        ValidationResult v = _editor.Validation.ValidateTrim(_editor.Project, m.Source, clip, newStart, newSource, newDuration);
        _trimPlan = new TrimPlan(m.Source, clip, newStart, newSource, newDuration);

        GhostClip ghost = new(clip.Id, _trackIndex[m.Source], newStart, newDuration, v.IsValid);
        return new DragPreview(v.IsValid, v.Reason, v.IsValid ? null : v.Message, ghost.TrackIndex, new[] { ghost }, v.IsValid ? snap : null, newStart);
    }

    // ------------------------------------------------------------------ commit

    private DragOutcome Commit()
    {
        if (_preview is null || !_preview.IsValid)
            return new DragOutcome(DragResult.Rejected, _preview?.Message);

        if (_kind == DragKind.Move)
        {
            bool changed = _planned.Any(p => p.NewStart != p.Clip.Start || p.TargetTrack != p.SourceTrack);
            if (!changed) return new DragOutcome(DragResult.NoChange);
            ValidationResult r = _editor.TryMoveClips(_planned);   // ONE MoveClipsCommand
            return r.IsValid ? new DragOutcome(DragResult.Committed) : new DragOutcome(DragResult.Rejected, r.Message);
        }

        TrimPlan? t = _trimPlan;
        if (t is null || (t.NewStart == t.Clip.Start && t.NewDuration == t.Clip.Duration))
            return new DragOutcome(DragResult.NoChange);
        ValidationResult tr = _editor.TryTrimClip(t.Track, t.Clip, t.NewSource, t.NewDuration, t.NewStart);
        return tr.IsValid ? new DragOutcome(DragResult.Committed) : new DragOutcome(DragResult.Rejected, tr.Message);
    }
}
