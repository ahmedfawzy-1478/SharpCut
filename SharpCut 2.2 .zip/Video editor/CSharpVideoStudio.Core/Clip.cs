using System;

namespace CSharpVideoStudio;

public abstract class Clip
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public MediaItem Media { get; set; } = null!;
    public TimeSpan Start { get; set; }
    public TimeSpan Duration { get; set; }
    public TimeSpan SourceStart { get; set; }
    public bool Muted { get; set; }
    public double Volume { get; set; } = 1.0;

    // خصائص العرض والسرعة والتحويلات المفقودة
    public double Opacity { get; set; } = 1.0;
    public double Speed { get; set; } = 1.0;
    public double Scale { get; set; } = 1.0;
    public double Rotation { get; set; } = 0.0;

    /// <summary>Clips sharing the same non-null id move together (linked audio/video).</summary>
    public Guid? LinkGroupId { get; set; }

    public TimeSpan End => Start + Duration;

    public abstract Clip Clone();
}