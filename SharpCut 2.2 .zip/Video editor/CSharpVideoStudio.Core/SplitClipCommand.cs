using System;

namespace CSharpVideoStudio;

public class SplitClipCommand : IEditCommand
{
    public Track Track { get; }
    public Clip OriginalClip { get; }
    public Clip FirstClip { get; }
    public Clip SecondClip { get; }

    public SplitClipCommand(Track track, Clip originalClip, TimeSpan splitPosition)
    {
        Track = track;
        OriginalClip = originalClip;

        TimeSpan offset = splitPosition - originalClip.Start;
        TimeSpan firstDuration = offset;
        TimeSpan secondDuration = originalClip.Duration - offset;

        // إنشاء المقطع الأول
        FirstClip = originalClip.Clone();
        FirstClip.Start = originalClip.Start;
        FirstClip.Duration = firstDuration;
        FirstClip.SourceStart = originalClip.SourceStart;

        // إنشاء المقطع الثاني
        SecondClip = originalClip.Clone();
        SecondClip.Start = splitPosition;
        SecondClip.Duration = secondDuration;
        SecondClip.SourceStart = originalClip.SourceStart + offset;

        // نسخ خصائص التحكم للصوت والعرض والسرعة
        FirstClip.Volume = originalClip.Volume;
        FirstClip.Opacity = originalClip.Opacity;
        FirstClip.Speed = originalClip.Speed;
        FirstClip.Scale = originalClip.Scale;
        FirstClip.Rotation = originalClip.Rotation;

        SecondClip.Volume = originalClip.Volume;
        SecondClip.Opacity = originalClip.Opacity;
        SecondClip.Speed = originalClip.Speed;
        SecondClip.Scale = originalClip.Scale;
        SecondClip.Rotation = originalClip.Rotation;
    }

    public void Execute()
    {
        int index = Track.Clips.IndexOf(OriginalClip);
        if (index >= 0)
        {
            Track.Clips.RemoveAt(index);
            Track.Clips.Insert(index, FirstClip);
            Track.Clips.Insert(index + 1, SecondClip);
        }
    }

    public void Undo()
    {
        int index = Track.Clips.IndexOf(FirstClip);
        Track.Clips.Remove(FirstClip);
        Track.Clips.Remove(SecondClip);
        Track.Clips.Insert(Math.Clamp(index, 0, Track.Clips.Count), OriginalClip);
    }
}