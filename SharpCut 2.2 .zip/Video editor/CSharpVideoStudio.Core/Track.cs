using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharpVideoStudio;

public sealed class Track
{
    public Guid Id { get; } = Guid.NewGuid();

    public string Name { get; set; }

    public TrackType Type { get; }

    public bool IsMuted { get; set; }

    public bool IsLocked { get; set; }

    public bool IsVisible { get; set; } = true;

    public List<Clip> Clips { get; } = new();

    public Track(
        string name,
        TrackType type)
    {
        Name = name;
        Type = type;
    }

    public TimeSpan Duration
    {
        get
        {
            if (Clips.Count == 0)
                return TimeSpan.Zero;

            return Clips.Max(
                clip => clip.End);
        }
    }

    public bool CanAccept(Clip clip)
    {
        return Type == TrackType.Video
            ? clip is VideoClip || clip is ImageClip
            : clip is AudioClip;
    }

    public bool HasOverlap(
        Clip candidate,
        Clip? ignoredClip = null)
    {
        foreach (Clip clip in Clips)
        {
            if (clip == ignoredClip)
                continue;

            if (candidate.Start < clip.End &&
                candidate.End > clip.Start)
            {
                return true;
            }
        }

        return false;
    }

    public void AddClip(Clip clip)
    {
        if (!CanAccept(clip))
        {
            throw new InvalidOperationException(
                "This clip type cannot be added to this track.");
        }

        if (HasOverlap(clip))
        {
            throw new InvalidOperationException(
                "The clip overlaps another clip.");
        }

        Clips.Add(clip);

        SortClips();
    }

    public void RemoveClip(Clip clip)
    {
        Clips.Remove(clip);
    }

    public void SortClips()
    {
        Clips.Sort(
            (a, b) =>
                a.Start.CompareTo(b.Start));
    }
}