using System;
using System.Collections.Generic;
using System.Linq;
using CSharpVideoStudio.Timeline;

namespace CSharpVideoStudio;

public sealed class ProjectEditor
{
    public Project Project { get; }

    public TimelineValidationService Validation { get; } = new();

    public CommandManager Commands { get; } = new CommandManager();

    public ProjectEditor(Project project)
    {
        Project = project;
        Project.EnsureDefaultTracks();
    }

    public Track GetVideoTrack(int index = 0)
    {
        List<Track> tracks = Project.Tracks
            .Where(x => x.Type == TrackType.Video)
            .ToList();

        while (tracks.Count <= index)
        {
            Project.AddVideoTrack();
            tracks = Project.Tracks
                .Where(x => x.Type == TrackType.Video)
                .ToList();
        }

        return tracks[index];
    }

    public Track GetAudioTrack(int index = 0)
    {
        List<Track> tracks = Project.Tracks
            .Where(x => x.Type == TrackType.Audio)
            .ToList();

        while (tracks.Count <= index)
        {
            Project.AddAudioTrack();
            tracks = Project.Tracks
                .Where(x => x.Type == TrackType.Audio)
                .ToList();
        }

        return tracks[index];
    }

    public void AddMedia(MediaItem media)
    {
        bool exists = Project.Media.Any(x =>
            string.Equals(x.FilePath, media.FilePath, StringComparison.OrdinalIgnoreCase));

        if (!exists)
        {
            Project.Media.Add(media);
        }
    }

    public VideoClip AddVideo(MediaItem media, TimeSpan start, int trackIndex = 0)
    {
        if (media.Type != MediaType.Video)
        {
            throw new InvalidOperationException("Media is not a video.");
        }

        VideoClip clip = new VideoClip(media, start, media.Duration, TimeSpan.Zero);
        Track track = GetVideoTrack(trackIndex);

        Commands.Execute(new AddClipCommand(track, clip));
        return clip;
    }

    public AudioClip AddAudio(MediaItem media, TimeSpan start, int trackIndex = 0)
    {
        if (media.Type != MediaType.Audio)
        {
            throw new InvalidOperationException("Media is not an audio file.");
        }

        AudioClip clip = new AudioClip(media, start, media.Duration, TimeSpan.Zero);
        Track track = GetAudioTrack(trackIndex);

        Commands.Execute(new AddClipCommand(track, clip));
        return clip;
    }

    public ImageClip AddImage(MediaItem media, TimeSpan start, TimeSpan duration, int trackIndex = 0)
    {
        if (media.Type != MediaType.Image)
        {
            throw new InvalidOperationException("Media is not an image.");
        }

        ImageClip clip = new ImageClip(media, start, duration);
        Track track = GetVideoTrack(trackIndex);

        Commands.Execute(new AddClipCommand(track, clip));
        return clip;
    }

    public void DeleteClip(Track track, Clip clip)
    {
        if (!track.Clips.Contains(clip) || track.IsLocked)
            return;

        Commands.Execute(new RemoveClipCommand(track, clip));
    }

    /// <summary>Validated move of one or many clips as ONE undoable command. No partial moves.</summary>
    public ValidationResult TryMoveClips(IReadOnlyList<PlannedMove> moves)
    {
        ValidationResult result = Validation.ValidateMoves(Project, moves);
        if (!result.IsValid)
            return result;

        List<ClipMove> changes = moves
            .Where(m => m.NewStart != m.Clip.Start || m.TargetTrack != m.SourceTrack)
            .Select(m => new ClipMove(m.Clip, m.SourceTrack, m.Clip.Start, m.TargetTrack, m.NewStart))
            .ToList();

        if (changes.Count > 0)
            Commands.Execute(new MoveClipsCommand(changes));

        return result;
    }

    /// <summary>Validated trim as one undoable command. Returns false (model untouched) when rejected.</summary>
    public ValidationResult TryTrimClip(Track track, Clip clip, TimeSpan newSourceStart, TimeSpan newDuration, TimeSpan newStart)
    {
        ValidationResult result = Validation.ValidateTrim(Project, track, clip, newStart, newSourceStart, newDuration);
        if (!result.IsValid)
            return result;

        Commands.Execute(new TrimClipCommand(
            clip, clip.Start, clip.SourceStart, clip.Duration,
            newStart, newSourceStart, newDuration));
        return result;
    }

    public void Undo() => Commands.Undo();

    public void Redo() => Commands.Redo();

    public Track? FindTrackForClip(Clip clip)
    {
        return Project.Tracks.FirstOrDefault(track => track.Clips.Contains(clip));
    }
}