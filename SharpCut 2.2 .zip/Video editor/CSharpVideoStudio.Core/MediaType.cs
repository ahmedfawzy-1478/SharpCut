﻿namespace CSharpVideoStudio;

public enum MediaType
{
    Video,
    Audio,
    Image
}