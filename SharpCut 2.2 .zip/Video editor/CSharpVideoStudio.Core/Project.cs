﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharpVideoStudio;

public sealed class Project
{
    public Guid Id { get; } = Guid.NewGuid();

    public string Name { get; set; } =
        "Untitled Project";

    public string? FilePath { get; set; }

    public int Width { get; set; } = 1920;

    public int Height { get; set; } = 1080;

    public double FrameRate { get; set; } = 30;

    public List<MediaItem> Media { get; } = new();

    public List<Track> Tracks { get; } = new();

    public List<Marker> Markers { get; } = new();

    public TimeSpan? InPoint { get; set; }

    public TimeSpan? OutPoint { get; set; }

    public TimeSpan Duration
    {
        get
        {
            if (Tracks.Count == 0)
                return TimeSpan.Zero;

            return Tracks.Max(
                track => track.Duration);
        }
    }

    public Track AddVideoTrack(
        string? name = null)
    {
        int number =
            Tracks.Count(
                x => x.Type == TrackType.Video) + 1;

        Track track =
            new Track(
                name ?? $"Video {number}",
                TrackType.Video);

        Tracks.Add(track);

        return track;
    }

    public Track AddAudioTrack(
        string? name = null)
    {
        int number =
            Tracks.Count(
                x => x.Type == TrackType.Audio) + 1;

        Track track =
            new Track(
                name ?? $"Audio {number}",
                TrackType.Audio);

        Tracks.Add(track);

        return track;
    }

    /// <summary>Two lanes per media type so clips can be moved vertically out of the box.</summary>
    public void EnsureDefaultTracks()
    {
        while (Tracks.Count(x => x.Type == TrackType.Video) < 2)
            AddVideoTrack();

        while (Tracks.Count(x => x.Type == TrackType.Audio) < 2)
            AddAudioTrack();
    }
}
