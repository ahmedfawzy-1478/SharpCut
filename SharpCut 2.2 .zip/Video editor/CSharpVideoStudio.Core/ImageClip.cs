﻿using System;

namespace CSharpVideoStudio;

public class ImageClip : Clip
{
    public ImageClip() { }

    public ImageClip(MediaItem media, TimeSpan start, TimeSpan duration)
    {
        Media = media;
        Start = start;
        Duration = duration;
        SourceStart = TimeSpan.Zero;
        Volume = 1.0;
        Opacity = 1.0;
        Speed = 1.0;
        Scale = 1.0;
        Rotation = 0.0;
    }

    public override Clip Clone()
    {
        return new ImageClip(Media, Start, Duration)
        {
            Id = Guid.NewGuid(),
            Muted = Muted,
            Volume = Volume,
            Opacity = Opacity,
            Speed = Speed,
            Scale = Scale,
            Rotation = Rotation
        };
    }
}