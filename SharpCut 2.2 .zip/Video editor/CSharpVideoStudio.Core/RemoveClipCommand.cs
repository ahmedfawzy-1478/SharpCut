﻿using System;

namespace CSharpVideoStudio;

public sealed class RemoveClipCommand : IEditCommand
{
    private readonly Track _track;

    private readonly Clip _clip;

    private readonly int _index;

    public RemoveClipCommand(
        Track track,
        Clip clip)
    {
        _track = track;
        _clip = clip;

        _index =
            track.Clips.IndexOf(clip);
    }

    public void Execute()
    {
        _track.RemoveClip(_clip);
    }

    public void Undo()
    {
        if (_track.Clips.Contains(_clip))
            return;

        int index =
            Math.Clamp(
                _index,
                0,
                _track.Clips.Count);

        _track.Clips.Insert(
            index,
            _clip);

        _track.SortClips();
    }
}