﻿using System;
using System.IO;

namespace CSharpVideoStudio;

public sealed class MediaItem
{
    public Guid Id { get; } = Guid.NewGuid();

    public string FilePath { get; }

    public string FileName =>
        Path.GetFileName(FilePath);

    public MediaType Type { get; }

    public TimeSpan Duration { get; set; }

    public int Width { get; set; }

    public int Height { get; set; }

    public double FrameRate { get; set; }

    public MediaItem(
        string filePath,
        MediaType type)
    {
        FilePath = filePath;
        Type = type;
    }

    public override string ToString()
    {
        return FileName;
    }
}