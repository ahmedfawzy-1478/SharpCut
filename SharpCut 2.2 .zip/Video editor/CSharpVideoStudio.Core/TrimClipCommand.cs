﻿using System;

namespace CSharpVideoStudio;

public sealed class TrimClipCommand : IEditCommand
{
    private readonly Clip _clip;

    private readonly TimeSpan _oldStart;

    private readonly TimeSpan _oldSourceStart;

    private readonly TimeSpan _oldDuration;

    private readonly TimeSpan _newStart;

    private readonly TimeSpan _newSourceStart;

    private readonly TimeSpan _newDuration;

    public TrimClipCommand(
        Clip clip,
        TimeSpan oldStart,
        TimeSpan oldSourceStart,
        TimeSpan oldDuration,
        TimeSpan newStart,
        TimeSpan newSourceStart,
        TimeSpan newDuration)
    {
        _clip = clip;

        _oldStart = oldStart;
        _oldSourceStart = oldSourceStart;
        _oldDuration = oldDuration;

        _newStart = newStart;
        _newSourceStart = newSourceStart;
        _newDuration = newDuration;
    }

    public void Execute()
    {
        Apply(
            _newStart,
            _newSourceStart,
            _newDuration);
    }

    public void Undo()
    {
        Apply(
            _oldStart,
            _oldSourceStart,
            _oldDuration);
    }

    private void Apply(
        TimeSpan start,
        TimeSpan sourceStart,
        TimeSpan duration)
    {
        _clip.Start = start;
        _clip.SourceStart = sourceStart;
        _clip.Duration = duration;
    }
}