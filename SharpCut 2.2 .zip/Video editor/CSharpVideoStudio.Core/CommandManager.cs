﻿using System.Collections.Generic;

namespace CSharpVideoStudio;

public sealed class CommandManager
{
    private readonly Stack<IEditCommand> _undo = new();

    private readonly Stack<IEditCommand> _redo = new();

    public bool CanUndo =>
        _undo.Count > 0;

    public bool CanRedo =>
        _redo.Count > 0;

    public void Execute(
        IEditCommand command)
    {
        command.Execute();

        _undo.Push(command);

        _redo.Clear();
    }

    public void Undo()
    {
        if (_undo.Count == 0)
            return;

        IEditCommand command =
            _undo.Pop();

        command.Undo();

        _redo.Push(command);
    }

    public void Redo()
    {
        if (_redo.Count == 0)
            return;

        IEditCommand command =
            _redo.Pop();

        command.Execute();

        _undo.Push(command);
    }

    public void Clear()
    {
        _undo.Clear();
        _redo.Clear();
    }
}