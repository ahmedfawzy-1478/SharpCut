namespace CSharpVideoStudio.Playback;

public enum PlaybackState { Stopped, Loading, Playing, Paused, Seeking, Error }
