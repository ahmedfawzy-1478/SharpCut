namespace CSharpVideoStudio.Playback;

/// <summary>Owns the lifecycle of ONE media player. Pause never disposes or reloads the backend.</summary>
public sealed class MediaPlayerSession
{
    private readonly IPlaybackBackend _backend;
    private readonly PlaybackStateMachine _state = new();
    private readonly object _gate = new();

    public MediaPlayerSession(IPlaybackBackend backend) => _backend = backend;

    public PlaybackState State { get { lock (_gate) return _state.Current; } }
    public TimeSpan Position => _backend.Position;
    public event Action<PlaybackState, PlaybackState>? StateChanged
    {
        add => _state.Changed += value;
        remove => _state.Changed -= value;
    }

    public void Open(string path)
    {
        lock (_gate)
        {
            _state.TransitionTo(PlaybackState.Loading);
            try { _backend.Load(path); _state.TransitionTo(PlaybackState.Paused); }
            catch { _state.TransitionTo(PlaybackState.Error); throw; }
        }
    }

    public void Play()
    {
        lock (_gate)
        {
            if (_state.Current == PlaybackState.Playing) return;
            _backend.Play(); // resumes from current position when Paused
            _state.TransitionTo(PlaybackState.Playing);
        }
    }

    public void Pause()
    {
        lock (_gate)
        {
            if (_state.Current != PlaybackState.Playing) return;
            _backend.Pause();
            _state.TransitionTo(PlaybackState.Paused);
        }
    }

    /// <summary>Asynchronous backend failure (decoder error). Only flips state; never calls back into the backend.</summary>
    public void ReportFailure()
    {
        lock (_gate) _state.TransitionTo(PlaybackState.Error);
    }

    public void TogglePlayPause() { if (State == PlaybackState.Playing) Pause(); else Play(); }

    public void Stop()
    {
        lock (_gate)
        {
            _backend.Stop();
            _state.TransitionTo(PlaybackState.Stopped);
        }
    }

    public void Seek(TimeSpan target)
    {
        lock (_gate)
        {
            var resume = _state.Current == PlaybackState.Playing ? PlaybackState.Playing : PlaybackState.Paused;
            _state.TransitionTo(PlaybackState.Seeking);
            _backend.Seek(target < TimeSpan.Zero ? TimeSpan.Zero : target);
            _state.TransitionTo(resume);
        }
    }

    public void StepFrame(int frames, double fps)
    {
        if (fps <= 0) throw new ArgumentOutOfRangeException(nameof(fps));
        Pause();
        Seek(Position + TimeSpan.FromSeconds(frames / fps));
    }
}
