namespace CSharpVideoStudio.Playback;

public enum PreviewStatus { Idle, Loading, Playing, Paused, Error }

/// <summary>
/// Decides what the preview player must do for each timeline tick. The timeline is the ONLY clock;
/// the player follows it. The director is idempotent: calling Sync every tick issues backend
/// commands only when something actually changed (new media, a jump, paused scrubbing,
/// or real drift), so ticks never reload, re-seek or restart the media.
/// </summary>
public sealed class PreviewDirector
{
    /// <summary>A requested source position further than this from "where it should be" is a jump (seek/clip change).</summary>
    public static readonly TimeSpan JumpTolerance = TimeSpan.FromMilliseconds(400);
    /// <summary>Player vs timeline difference tolerated before a drift correction.</summary>
    public static readonly TimeSpan DriftTolerance = TimeSpan.FromMilliseconds(1500);
    /// <summary>Minimum gap between two drift corrections, so a slow decoder can never cause a seek storm.</summary>
    public static readonly TimeSpan DriftCooldown = TimeSpan.FromSeconds(3);
    public static readonly TimeSpan ScrubTolerance = TimeSpan.FromMilliseconds(40);
    private static readonly TimeSpan LoadingTimeout = TimeSpan.FromSeconds(3);

    private readonly MediaPlayerSession _session;
    private readonly IPlaybackBackend _backend;
    private readonly Func<TimeSpan> _clock;

    private string? _currentPath;
    private string? _failedPath;
    private TimeSpan _lastRequested;
    private TimeSpan _lastRequestedAt;
    private bool _lastWantedPlay;
    private TimeSpan _lastCorrection;
    private TimeSpan _openedAt;
    private TimeSpan _openSource;
    private bool _loading;
    private double _volume = -1;
    private PreviewStatus _status = PreviewStatus.Idle;
    private string? _message;

    public PreviewDirector(MediaPlayerSession session, IPlaybackBackend backend, Func<TimeSpan> clock)
    {
        _session = session;
        _backend = backend;
        _clock = clock;
        _backend.Failed += OnBackendFailed;
    }

    public PreviewStatus Status => _status;
    public string? Message => _message;
    public event Action<PreviewStatus, string?>? StatusChanged;

    public void Sync(string path, TimeSpan sourcePosition, bool shouldPlay, double volume)
    {
        if (_volume < 0 || Math.Abs(volume - _volume) > 0.001)
        {
            _volume = volume;
            _backend.SetVolume(volume);
        }

        // A media that already failed is not retried every tick; a different clip clears the failure.
        if (_failedPath != null)
        {
            if (SamePath(path, _failedPath)) return;
            _failedPath = null;
        }

        TimeSpan now = _clock();

        if (!SamePath(path, _currentPath))
        {
            OpenNew(path, sourcePosition, now);
            if (_failedPath != null) return;
        }
        else
        {
            bool steadyPaused = !shouldPlay && !_lastWantedPlay;
            TimeSpan expected = _lastWantedPlay ? _lastRequested + (now - _lastRequestedAt) : _lastRequested;
            TimeSpan tolerance = steadyPaused ? ScrubTolerance : JumpTolerance;

            if ((sourcePosition - expected).Duration() > tolerance)
            {
                _session.Seek(sourcePosition);            // user seek / clip switch inside the same file
                _lastCorrection = now;
            }
            else if (shouldPlay && _session.State == PlaybackState.Playing &&
                     now - _lastCorrection > DriftCooldown &&
                     (_session.Position - sourcePosition).Duration() > DriftTolerance)
            {
                _session.Seek(sourcePosition);            // real drift, rate limited
                _lastCorrection = now;
            }
        }

        _lastRequested = sourcePosition;
        _lastRequestedAt = now;
        _lastWantedPlay = shouldPlay;

        if (shouldPlay) _session.Play();   // no-op when already Playing
        else _session.Pause();             // no-op unless Playing

        UpdateLoading(now);
        Publish();
    }

    public void Pause()
    {
        _lastWantedPlay = false;
        if (_session.State == PlaybackState.Playing) _session.Pause();
        Publish();
    }

    public void Clear()
    {
        if (_session.State != PlaybackState.Stopped) _session.Stop();
        _currentPath = null;
        _failedPath = null;
        _loading = false;
        _lastWantedPlay = false;
        _message = null;
        Publish();
    }

    private void OpenNew(string path, TimeSpan source, TimeSpan now)
    {
        if (_session.State != PlaybackState.Stopped) _session.Stop();   // Error/Paused/Playing -> Stopped first

        try
        {
            _session.Open(path);
        }
        catch (Exception ex)
        {
            _failedPath = path;
            _currentPath = null;
            _loading = false;
            _message = ex is FileNotFoundException ? "Media file not found." : "Unable to play this media file.";
            Publish();
            return;
        }

        _currentPath = path;
        _session.Seek(source);               // applied by the backend as soon as the decoder is running
        _openedAt = now;
        _openSource = source;
        _lastCorrection = now;
        _lastWantedPlay = false;
        _lastRequested = source;
        _lastRequestedAt = now;
        _loading = true;
        _message = null;
    }

    private void UpdateLoading(TimeSpan now)
    {
        if (!_loading) return;
        if ((_backend.Position - _openSource).Duration() > TimeSpan.FromMilliseconds(50) || now - _openedAt > LoadingTimeout)
            _loading = false;
    }

    private void OnBackendFailed(string message)
    {
        // May arrive on a player thread: flip state only, never call back into the backend.
        _failedPath = _currentPath ?? _failedPath;
        _currentPath = null;
        _loading = false;
        _message = message;
        try { _session.ReportFailure(); } catch (InvalidOperationException) { }
        Publish();
    }

    private void Publish()
    {
        PreviewStatus next =
            _failedPath != null ? PreviewStatus.Error :
            _currentPath == null ? PreviewStatus.Idle :
            _loading ? PreviewStatus.Loading :
            _session.State == PlaybackState.Playing ? PreviewStatus.Playing : PreviewStatus.Paused;

        if (next == _status && next != PreviewStatus.Error) return;
        _status = next;
        StatusChanged?.Invoke(next, next == PreviewStatus.Error ? _message : null);
    }

    private static bool SamePath(string a, string? b) =>
        b != null && string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
}
