namespace CSharpVideoStudio.Playback;

/// <summary>
/// Backend abstraction (LibVLCSharp adapter lives in the App project).
/// Contract: Pause() keeps the decoder/session alive and keeps Position;
/// Play() after Pause() resumes from that position.
/// </summary>
public interface IPlaybackBackend : IDisposable
{
    TimeSpan Position { get; }
    TimeSpan Duration { get; }
    event Action<string>? Failed;
    void Load(string path);
    void Play();
    void Pause();
    void Stop();
    void Seek(TimeSpan position);
    void SetVolume(double volume01);
}
