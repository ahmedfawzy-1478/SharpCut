namespace CSharpVideoStudio.Playback;

/// <summary>Single source of truth for legal playback transitions.</summary>
public sealed class PlaybackStateMachine
{
    private static readonly Dictionary<PlaybackState, PlaybackState[]> Allowed = new()
    {
        [PlaybackState.Stopped] = [PlaybackState.Loading, PlaybackState.Playing, PlaybackState.Seeking, PlaybackState.Error],
        [PlaybackState.Loading] = [PlaybackState.Stopped, PlaybackState.Playing, PlaybackState.Paused, PlaybackState.Error],
        [PlaybackState.Playing] = [PlaybackState.Paused, PlaybackState.Seeking, PlaybackState.Stopped, PlaybackState.Error],
        [PlaybackState.Paused]  = [PlaybackState.Playing, PlaybackState.Seeking, PlaybackState.Stopped, PlaybackState.Error],
        [PlaybackState.Seeking] = [PlaybackState.Playing, PlaybackState.Paused, PlaybackState.Stopped, PlaybackState.Error],
        [PlaybackState.Error]   = [PlaybackState.Stopped, PlaybackState.Loading],
    };

    public PlaybackState Current { get; private set; } = PlaybackState.Stopped;
    public event Action<PlaybackState, PlaybackState>? Changed;

    public bool CanTransitionTo(PlaybackState next) => Allowed[Current].Contains(next);

    public void TransitionTo(PlaybackState next)
    {
        if (next == Current) return;
        if (!CanTransitionTo(next))
            throw new InvalidOperationException($"Illegal playback transition {Current} -> {next}");
        var old = Current;
        Current = next;
        Changed?.Invoke(old, next);
    }
}
