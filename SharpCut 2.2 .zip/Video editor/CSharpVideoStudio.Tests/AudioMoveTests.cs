using CSharpVideoStudio.Timeline;

namespace CSharpVideoStudio.Tests;

/// <summary>Vertical (track-to-track) moves of audio clips, mirroring the video ones.</summary>
static class AudioMoveTests
{
    static TimeSpan S(double s) => TimeSpan.FromSeconds(s);

    public static void Run()
    {
        Harness.Section("Vertical audio clip moves");

        {   // default project: the app's real starting point
            var p = new Project(); p.EnsureDefaultTracks();
            Harness.Check("Default project has 2 video + 2 audio tracks",
                p.Tracks.Count(t => t.Type == TrackType.Video) == 2 && p.Tracks.Count(t => t.Type == TrackType.Audio) == 2);
            var again = p.Tracks.Count; p.EnsureDefaultTracks();
            Harness.Check("EnsureDefaultTracks is idempotent", p.Tracks.Count == again);
        }

        {   // MP3 A1 -> A2, same time, then undo/redo
            var r = new TimelineTests.Rig();
            var c = r.Audio(r.A1, 10, 8); c.Volume = 0.4; c.Muted = true; var id = c.Id; var media = c.Media;
            var o = r.DragClip(c, 10, 3);
            Harness.Check("MP3 moves A1 -> A2", o.Result == DragResult.Committed && r.A2.Clips.Contains(c) && !r.A1.Clips.Contains(c));
            Harness.Check("Horizontal position preserved", c.Start == S(10));
            Harness.Check("Duration/source/volume/mute/media preserved", c.Duration == S(8) && c.SourceStart == S(0) && c.Volume == 0.4 && c.Muted && ReferenceEquals(c.Media, media) && c.Id == id);
            Harness.Check("Exactly one copy in the project (no duplicate, nothing lost)", r.Project.Tracks.Sum(t => t.Clips.Count(x => x.Id == id)) == 1);
            r.Editor.Undo();
            Harness.Check("Undo returns it to A1 in one step", r.A1.Clips.Contains(c) && !r.A2.Clips.Contains(c) && !r.Editor.Commands.CanUndo);
            r.Editor.Redo();
            Harness.Check("Redo moves it to A2 again", r.A2.Clips.Contains(c) && !r.A1.Clips.Contains(c));
        }

        {   // diagonal: horizontal + vertical together
            var r = new TimelineTests.Rig();
            var c = r.Audio(r.A1, 5, 4);
            r.DragClip(c, 20, 3);
            Harness.Check("Diagonal move: new track AND new start", r.A2.Clips.Contains(c) && c.Start == S(20));
        }

        {   // video -> still works (regression)
            var r = new TimelineTests.Rig();
            var v = r.Video(r.V1, 3, 6);
            var o = r.DragClip(v, 3, 1);
            Harness.Check("MP4 vertical move V1 -> V2 still works", o.Result == DragResult.Committed && r.V2.Clips.Contains(v) && v.Start == S(3));
        }

        {   // incompatible track
            var r = new TimelineTests.Rig();
            var c = r.Audio(r.A1, 5, 4);
            var o = r.DragClip(c, 5, 0);                     // onto V1
            Harness.Check("Audio onto a video track is rejected, model unchanged", o.Result == DragResult.Rejected && r.A1.Clips.Contains(c) && !r.V1.Clips.Any());
            Harness.Check("Rejected drop leaves nothing to undo", !r.Editor.Commands.CanUndo);
            var v = r.Video(r.V1, 30, 4);
            var o2 = r.DragClip(v, 30, 2);                   // video onto A1
            Harness.Check("Video onto an audio track is rejected", o2.Result == DragResult.Rejected && r.V1.Clips.Contains(v));
        }

        {   // locked target / source
            var r = new TimelineTests.Rig();
            var c = r.Audio(r.A1, 5, 4); r.A2.IsLocked = true;
            var o = r.DragClip(c, 5, 3);
            Harness.Check("Move to a locked audio track is rejected", o.Result == DragResult.Rejected && r.A1.Clips.Contains(c));
            r.A2.IsLocked = false; r.A1.IsLocked = true;
            var o2 = r.DragClip(c, 5, 3);
            Harness.Check("Move out of a locked audio track is rejected", o2.Result == DragResult.Rejected && r.A1.Clips.Contains(c));
        }

        {   // overlap on the destination
            var r = new TimelineTests.Rig();
            var c = r.Audio(r.A1, 5, 4); var other = r.Audio(r.A2, 6, 4);
            var o = r.DragClip(c, 5, 3);
            Harness.Check("Overlap on the destination audio track is rejected", o.Result == DragResult.Rejected && r.A1.Clips.Contains(c) && other.Start == S(6));
        }

        {   // multi-select
            var r = new TimelineTests.Rig();
            var a = r.Audio(r.A1, 2, 3); var b = r.Audio(r.A1, 10, 3);
            r.Selection.Select(a); r.Selection.Add(b);
            var o = r.DragClip(a, 2, 3);
            Harness.Check("Two selected MP3s move to A2 together", o.Result == DragResult.Committed && r.A2.Clips.Contains(a) && r.A2.Clips.Contains(b));
            Harness.Check("Relative offset preserved", b.Start - a.Start == S(8));
            r.Editor.Undo();
            Harness.Check("One undo restores both", r.A1.Clips.Contains(a) && r.A1.Clips.Contains(b));
        }

        {   // cancel
            var r = new TimelineTests.Rig();
            var c = r.Audio(r.A1, 5, 4);
            r.DragClip(c, 12, 3, release: false);
            r.Drag.Cancel();
            Harness.Check("Cancel: clip untouched, nothing to undo", r.A1.Clips.Contains(c) && c.Start == S(5) && !r.Editor.Commands.CanUndo);
        }

        {   // 500 moves = one command (same rule as video)
            var r = new TimelineTests.Rig();
            var c = r.Audio(r.A1, 5, 4);
            r.Drag.PointerDown(r.X(5) + 20, r.RowY(2), c, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
            for (int i = 0; i < 500; i++) r.Drag.PointerMove(r.X(5 + i * 0.01) + 20, r.RowY(i % 2 == 0 ? 2 : 3), PointerModifiers.None);
            r.Drag.PointerUp(r.X(10) + 20, r.RowY(3), PointerModifiers.None);
            r.Editor.Undo();
            Harness.Check("500 mouse moves between A1/A2 = ONE undo step", r.A1.Clips.Contains(c) && c.Start == S(5) && !r.Editor.Commands.CanUndo);
        }

        {   // preview must not be hidden by audio tracks
            var r = new TimelineTests.Rig();
            var tc = new TimelineController(r.Project);
            var v = r.Video(r.V2, 0, 10); var a = r.Audio(r.A1, 0, 10);
            r.Project.Tracks.Remove(r.A1); r.Project.Tracks.Insert(0, r.A1);   // audio track listed first
            Harness.Check("FindClipAt can return the audio clip first (the old preview bug)", tc.FindClipAt(S(5)) is AudioClip);
            Harness.Check("FindVisualClipAt ignores audio: preview still gets the video", ReferenceEquals(tc.FindVisualClipAt(S(5)), v));
            Harness.Check("FindVisualClipAt is null where only audio plays", tc.FindVisualClipAt(S(50)) is null);
        }
    }
}
