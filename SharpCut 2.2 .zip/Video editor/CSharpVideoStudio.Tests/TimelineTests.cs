using CSharpVideoStudio.Timeline;

namespace CSharpVideoStudio.Tests;

/// <summary>Everything the drag/drop system decides is tested here without WPF.</summary>
static class TimelineTests
{
    internal static TimeSpan S(double s) => TimeSpan.FromSeconds(s);

    internal sealed class Rig
    {
        public Project Project = new();
        public ProjectEditor Editor;
        public TimelineSelection Selection;
        public TimelineCoordinateService Coords = new() { PixelsPerSecond = 100, TrackHeight = 65 };
        public TimelineSnapEngine Snap = new() { Enabled = false };
        public TimelineDragController Drag;
        public TimelineDropController Drop;
        public Track V1, V2, A1, A2;
        public int Ended; public DragOutcome? Last;

        public Rig()
        {
            V1 = Project.AddVideoTrack(); V2 = Project.AddVideoTrack();
            A1 = Project.AddAudioTrack(); A2 = Project.AddAudioTrack();
            Editor = new ProjectEditor(Project);
            Selection = new TimelineSelection(Project);
            Drag = new TimelineDragController(Editor, Selection, Coords, Snap);
            Drop = new TimelineDropController(Editor, Coords, Snap);
            Drag.Ended += o => { Ended++; Last = o; };
        }

        public MediaItem Media(string name, MediaType t, double seconds) => new(name, t) { Duration = S(seconds) };

        public VideoClip Video(Track t, double start, double len, double src = 0)
        {
            var c = new VideoClip(Media("v.mp4", MediaType.Video, 600), S(start), S(len), S(src));
            t.Clips.Add(c); t.SortClips(); return c;
        }

        public AudioClip Audio(Track t, double start, double len)
        {
            var c = new AudioClip(Media("a.mp3", MediaType.Audio, 600), S(start), S(len), S(0));
            t.Clips.Add(c); t.SortClips(); return c;
        }

        public double X(double seconds) => Coords.TimeToContentX(S(seconds));
        public double RowY(int track) => Coords.TrackTop(track) + 30;

        /// <summary>Press 20px inside the clip, move to (targetStartSeconds, track row), release.</summary>
        public DragOutcome DragClip(Clip c, double toStart, int toTrack, PointerModifiers mods = PointerModifiers.None, bool release = true)
        {
            Drag.PointerDown(X(c.Start.TotalSeconds) + 20, RowY(Project.Tracks.FindIndex(t => t.Clips.Contains(c))), c, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
            Drag.PointerMove(X(toStart) + 20, RowY(toTrack), mods);
            return release ? Drag.PointerUp(X(toStart) + 20, RowY(toTrack), mods) : new DragOutcome(DragResult.None);
        }
    }

    static bool Near(TimeSpan a, TimeSpan b, double ms = 1) => Math.Abs((a - b).TotalMilliseconds) <= ms;

    public static void Run()
    {
        Coordinates();
        Snapping();
        SingleMove();
        TrackTargeting();
        MultiAndLinked();
        UndoCancelPerformance();
        Boundaries();
        TrimBehaviour();
        DropFromBin();
        AutoScroll();
        PlaybackUnaffected();
    }

    static void Coordinates()
    {
        Harness.Section("Coordinate service");
        var c = new TimelineCoordinateService { PixelsPerSecond = 80, TrackHeight = 65 };
        Harness.Check("Time->Pixel 2s @80pps = 160", Math.Abs(c.TimeToContentX(S(2)) - 160) < 1e-9);
        Harness.Check("Pixel->Time 160 = 2s", c.ContentXToTime(160) == S(2));
        Harness.Check("Round trip is exact for 1h @ 80pps", c.ContentXToTime(c.TimeToContentX(S(3600))) == S(3600));
        c.HorizontalOffset = 500;
        Harness.Check("Viewport X accounts for horizontal scroll", c.ViewportXToTime(0) == c.ContentXToTime(500));
        Harness.Check("TimeToViewportX is offset", Math.Abs(c.TimeToViewportX(S(10)) - 300) < 1e-9);
        c.VerticalOffset = 130;
        Harness.Check("Viewport Y accounts for vertical scroll", Math.Abs(c.ViewportYToContentY(10) - 140) < 1e-9);
        Harness.Check("Y -> track index", c.ContentYToTrackIndex(0) == 0 && c.ContentYToTrackIndex(64.9) == 0 && c.ContentYToTrackIndex(65) == 1 && c.ContentYToTrackIndex(140) == 2);
        Harness.Check("Y above first track = -1", c.ContentYToTrackIndex(-5) == -1);
        c.PixelsPerSecond = 1e9; Harness.Check("Zoom is clamped (max)", c.PixelsPerSecond == TimelineCoordinateService.MaxPixelsPerSecond);
        c.PixelsPerSecond = 0;   Harness.Check("Zoom is clamped (min)", c.PixelsPerSecond == TimelineCoordinateService.MinPixelsPerSecond);

        var f = FrameRate.Fps29_97;
        Harness.Check("29.97: frame 30 is NOT exactly 1s", f.FrameToTime(30) > S(1) && f.FrameToTime(30) < S(1.002));
        Harness.Check("29.97: time->frame->time is stable over 1h of frames", Enumerable.Range(0, 107892).All(i => f.TimeToFrame(f.FrameToTime(i)) == i));
        Harness.Check("29.97: no cumulative drift (30000 frames = exactly 1001s)", f.FrameToTime(30000) == S(1001) && f.FrameToTime(30000 * 36) == S(36036));
        Harness.Check("FrameRate.FromDouble(29.97) is rational 30000/1001", FrameRate.FromDouble(29.97) == FrameRate.Fps29_97);
        Harness.Check("24fps: 1s = frame 24", FrameRate.Fps24.TimeToFrame(S(1)) == 24);
        Harness.Check("Negative time floors correctly", FrameRate.Fps30.TimeToFrame(TimeSpan.FromTicks(-1)) == -1);
    }

    static void Snapping()
    {
        Harness.Section("Snap engine");
        var r = new Rig { };
        r.Snap.Enabled = true;
        var other = r.Video(r.V1, 10, 5);                 // edges 10 and 15
        var moving = r.Video(r.V2, 0, 2);
        r.Project.Markers.Add(new Marker { Time = S(30) });
        r.Project.InPoint = S(40);

        // threshold = 10px @100pps = 100ms; move so clip END is 40ms from other.Start(10): start=7.96 -> end 9.96
        r.DragClip(moving, 7.96, 1, release: false);
        Harness.Check("Snaps clip end to neighbour start (within threshold)", r.Drag.Preview is { IsValid: true, Snap.Kind: SnapKind.ClipStart } p1 && Near(p1.PrimaryStart, S(8)));
        r.Drag.Cancel();

        r.DragClip(moving, 7.5, 1, release: false);
        Harness.Check("No snap outside threshold", r.Drag.Preview is { Snap: null } p2 && Near(p2.PrimaryStart, S(7.5)));
        r.Drag.Cancel();

        r.DragClip(moving, 7.96, 1, PointerModifiers.Alt, release: false);
        Harness.Check("Alt temporarily disables snapping", r.Drag.Preview is { Snap: null });
        r.Drag.Cancel();

        r.Snap.Enabled = false;
        r.DragClip(moving, 7.96, 1, release: false);
        Harness.Check("Snap OFF: no snapping", r.Drag.Preview is { Snap: null });
        r.Drag.Cancel(); r.Snap.Enabled = true;

        r.DragClip(moving, 29.96, 1, release: false);
        Harness.Check("Snaps to marker", r.Drag.Preview is { Snap.Kind: SnapKind.Marker });
        r.Drag.Cancel();

        r.DragClip(moving, 40.04, 1, release: false);
        Harness.Check("Snaps to In point", r.Drag.Preview is { Snap.Kind: SnapKind.InPoint });
        r.Drag.Cancel();

        r.Coords.PixelsPerSecond = 10;   // zoomed out: 10px = 1s of threshold
        r.DragClip(moving, 14.2, 1, release: false);
        Harness.Check("Threshold is in pixels: zoomed out => larger time window", r.Drag.Preview is { Snap: not null });
        r.Drag.Cancel();
        r.Coords.PixelsPerSecond = 1000; // zoomed in: 10px = 10ms
        r.DragClip(moving, 7.96, 1, release: false);
        Harness.Check("Zoomed in => same 40ms is outside the threshold", r.Drag.Preview is { Snap: null });
        r.Drag.Cancel(); r.Coords.PixelsPerSecond = 100;

        r.Snap.Enabled = true;
        var playhead = new Rig(); playhead.Snap.Enabled = true;
        var m2 = playhead.Video(playhead.V1, 0, 2);
        playhead.Drag.PointerDown(playhead.X(0) + 20, playhead.RowY(0), m2, DragKind.Move, PointerModifiers.None, S(20));
        playhead.Drag.PointerMove(playhead.X(19.95) + 20, playhead.RowY(0));
        Harness.Check("Snaps to playhead", playhead.Drag.Preview is { Snap.Kind: SnapKind.Playhead });
        playhead.Drag.Cancel();
    }

    static void SingleMove()
    {
        Harness.Section("Single clip move");
        var r = new Rig();
        var c = r.Video(r.V1, 10, 5, src: 3);

        var click = r.Drag;
        r.Drag.PointerDown(r.X(10) + 20, r.RowY(0), c, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
        r.Drag.PointerMove(r.X(10) + 22, r.RowY(0));
        Harness.Check("Movement under threshold stays PotentialDrag (no jump)", r.Drag.State == DragState.PotentialDrag && c.Start == S(10));
        var o = r.Drag.PointerUp(r.X(10) + 22, r.RowY(0));
        Harness.Check("Press+release = Click, nothing changes", o.Result == DragResult.Click && c.Start == S(10) && !r.Editor.Commands.CanUndo);

        r.Drag.PointerDown(r.X(10) + 20, r.RowY(0), c, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
        r.Drag.PointerMove(r.X(10) + 20 + 50, r.RowY(0));
        Harness.Check("Reaches Dragging after threshold", r.Drag.State == DragState.Dragging);
        Harness.Check("Model NOT modified during MouseMove", c.Start == S(10) && !r.Editor.Commands.CanUndo);
        Harness.Check("Ghost is produced at the predicted place", r.Drag.Preview!.Ghosts.Count == 1 && Near(r.Drag.Preview.Ghosts[0].Start, S(10.5)));
        r.Drag.PointerMove(r.X(10) + 20 + 500, r.RowY(0));
        var done = r.Drag.PointerUp(r.X(10) + 20 + 500, r.RowY(0));
        Harness.Check("Commit moves to 15s", done.Result == DragResult.Committed && Near(c.Start, S(15)));
        Harness.Check("Move changes position only (duration + source in unchanged)", c.Duration == S(5) && c.SourceStart == S(3));
        Harness.Check("Clip object identity preserved (not recreated)", r.V1.Clips.Single() == c);
        Harness.Check("State returns to Idle", r.Drag.State == DragState.Idle);

        r.Editor.Undo();
        Harness.Check("Undo restores 10s in ONE step", Near(c.Start, S(10)) && !r.Editor.Commands.CanUndo);
        r.Editor.Redo();
        Harness.Check("Redo re-applies 15s", Near(c.Start, S(15)));

        // press offset: grabbing near the right side must not make the clip jump
        var g = new Rig(); var gc = g.Video(g.V1, 10, 5);
        g.Drag.PointerDown(g.X(10) + 400, g.RowY(0), gc, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
        g.Drag.PointerMove(g.X(10) + 400 + 100, g.RowY(0));
        g.Drag.PointerUp(g.X(10) + 400 + 100, g.RowY(0));
        Harness.Check("Grab offset preserved: 100px drag = exactly +1s", Near(gc.Start, S(11)));

        // overlap rejection
        var o2 = new Rig(); var a = o2.Video(o2.V1, 0, 5); var b = o2.Video(o2.V1, 10, 5);
        var res = o2.DragClip(b, 3, 0);
        Harness.Check("Overlap is rejected and model untouched", res.Result == DragResult.Rejected && b.Start == S(10));
        var adj = o2.DragClip(b, 5, 0);
        Harness.Check("Adjacent (touching) clips are allowed", adj.Result == DragResult.Committed && Near(b.Start, S(5)));
    }

    static void TrackTargeting()
    {
        Harness.Section("Track targeting / validation");
        var r = new Rig(); var v = r.Video(r.V1, 5, 5);

        r.DragClip(v, 5, 1, release: false);
        Harness.Check("Y selects target track (V2 = index 1)", r.Drag.Preview is { IsValid: true, TargetTrackIndex: 1 });
        var res = r.Drag.PointerUp(r.X(5) + 20, r.RowY(1));
        Harness.Check("Video moves to another video track", res.Result == DragResult.Committed && r.V2.Clips.Contains(v) && !r.V1.Clips.Contains(v));
        r.Editor.Undo();
        Harness.Check("Undo returns it to the original track", r.V1.Clips.Contains(v) && !r.V2.Clips.Contains(v));

        r.DragClip(v, 5, 2, release: false);
        Harness.Check("Video over audio track = invalid with reason", r.Drag.Preview is { IsValid: false, Reason: Rejection.TrackTypeMismatch, Message: not null });
        var rej = r.Drag.PointerUp(r.X(5) + 20, r.RowY(2));
        Harness.Check("Invalid drop doesn't mutate the model", rej.Result == DragResult.Rejected && r.V1.Clips.Contains(v) && v.Start == S(5) && !r.Editor.Commands.CanUndo);

        var au = r.Audio(r.A1, 0, 4);
        r.DragClip(au, 0, 0, release: false);
        Harness.Check("Audio over video track = invalid", r.Drag.Preview is { IsValid: false, Reason: Rejection.TrackTypeMismatch });
        r.Drag.Cancel();
        r.DragClip(au, 1, 3);
        Harness.Check("Audio moves between audio tracks", r.A2.Clips.Contains(au));

        r.DragClip(v, 5, 9, release: false);
        Harness.Check("Empty area below tracks is invalid (no silent track creation)", r.Drag.Preview is { IsValid: false, Reason: Rejection.TrackMissing });
        r.Drag.Cancel();

        r.V2.IsLocked = true;
        var toLocked = r.DragClip(v, 5, 1);
        Harness.Check("Move INTO a locked track is rejected", toLocked.Result == DragResult.Rejected && r.V1.Clips.Contains(v));
        r.V2.IsLocked = false;
        var inV2 = r.Video(r.V2, 20, 3);
        r.V2.IsLocked = true;
        var fromLocked = r.DragClip(inV2, 25, 1);
        Harness.Check("Move OUT of / within a locked track is rejected", fromLocked.Result == DragResult.Rejected && inV2.Start == S(20));
        r.V2.IsLocked = false;
        r.Editor.Commands.Execute(new SetTrackLockedCommand(r.V2, true));
        Harness.Check("Lock toggle is an undoable command", r.V2.IsLocked);
        r.Editor.Undo();
        Harness.Check("Undo unlocks the track", !r.V2.IsLocked);
        r.Editor.Redo();
        var trim = r.Editor.TryTrimClip(r.V2, inV2, inV2.SourceStart, S(1), inV2.Start);
        Harness.Check("Editing clips inside a locked track is rejected", !trim.IsValid && trim.Reason == Rejection.TrackLocked);
        Harness.Check("Locked track blocks adding clips", !r.Editor.Validation.ValidateNewClip(r.Project, r.V2, new VideoClip(r.Media("x.mp4", MediaType.Video, 5), S(0), S(5), S(0))).IsValid);
    }

    static void MultiAndLinked()
    {
        Harness.Section("Multi-select / linked clips");
        var r = new Rig();
        var a = r.Video(r.V1, 10, 2); var b = r.Video(r.V1, 14, 2); var c = r.Video(r.V2, 12, 2);
        r.Selection.Select(a); r.Selection.Add(b); r.Selection.Add(c);

        var res = r.DragClip(b, 20, 0);   // b: 14 -> 20 => +6s for all
        Harness.Check("Group moves together keeping relative offsets", res.Result == DragResult.Committed && Near(a.Start, S(16)) && Near(b.Start, S(20)) && Near(c.Start, S(18)));
        r.Editor.Undo();
        Harness.Check("ONE undo restores the whole group", Near(a.Start, S(10)) && Near(b.Start, S(14)) && Near(c.Start, S(12)));
        Harness.Check("Group drag produced exactly one command", !r.Editor.Commands.CanUndo);
        r.Editor.Redo();

        // vertical group move: a,b on V1 + c on V2 -> down one track not possible for c (no V3) => nothing moves
        var r2 = new Rig();
        var a2 = r2.Video(r2.V1, 0, 2); var c2 = r2.Video(r2.V2, 5, 2);
        r2.Selection.Select(a2); r2.Selection.Add(c2);
        var bad = r2.DragClip(a2, 0, 1);
        Harness.Check("Group invalid as a whole => NO partial move", bad.Result == DragResult.Rejected && r2.V1.Clips.Contains(a2) && r2.V2.Clips.Contains(c2) && a2.Start == S(0) && c2.Start == S(5));

        // group stops at timeline start (relative offsets kept)
        var r3 = new Rig();
        var x = r3.Video(r3.V1, 2, 2); var y = r3.Video(r3.V1, 6, 2);
        r3.Selection.Select(x); r3.Selection.Add(y);
        r3.DragClip(y, 0, 0);
        Harness.Check("Group clamps at 00:00 as a unit (x=0, y=4)", Near(x.Start, S(0)) && Near(y.Start, S(4)));

        // linked A/V
        var r4 = new Rig();
        var vid = r4.Video(r4.V1, 10, 5); var aud = r4.Audio(r4.A1, 10, 5);
        r4.Editor.Commands.Execute(new LinkClipsCommand(new Clip[] { vid, aud }));
        r4.Selection.Select(vid);
        var lres = r4.DragClip(vid, 20, 0);
        Harness.Check("Linked audio follows video", lres.Result == DragResult.Committed && Near(vid.Start, S(20)) && Near(aud.Start, S(20)));
        r4.Editor.Undo();
        Harness.Check("Undo moves both back (one step)", Near(vid.Start, S(10)) && Near(aud.Start, S(10)));
        r4.Editor.Undo(); r4.Editor.Undo(); // undo link
        Harness.Check("Unlink (undo link) frees clips", vid.LinkGroupId == null && aud.LinkGroupId == null);

        var r5 = new Rig();
        var v5 = r5.Video(r5.V1, 10, 5); var a5 = r5.Audio(r5.A1, 12, 5);
        r5.Editor.Commands.Execute(new LinkClipsCommand(new Clip[] { v5, a5 }));
        r5.Editor.Commands.Execute(new UnlinkClipsCommand(new Clip[] { v5, a5 }));
        r5.Selection.Select(v5);
        r5.DragClip(v5, 30, 0);
        Harness.Check("After unlink, clips move independently", Near(v5.Start, S(30)) && Near(a5.Start, S(12)));

        var r6 = new Rig();
        var v6 = r6.Video(r6.V1, 10, 5); var a6 = r6.Audio(r6.A1, 12, 5); var blocker = r6.Audio(r6.A1, 22, 5);
        r6.Editor.Commands.Execute(new LinkClipsCommand(new Clip[] { v6, a6 }));
        var blocked = r6.DragClip(v6, 20, 0);
        Harness.Check("Linked partner blocked => whole move rejected", blocked.Result == DragResult.Rejected && v6.Start == S(10) && a6.Start == S(12));

        var r7 = new Rig();
        var v7 = r7.Video(r7.V1, 10, 5); var a7 = r7.Audio(r7.A1, 10, 5);
        r7.Editor.Commands.Execute(new LinkClipsCommand(new Clip[] { v7, a7 }));
        r7.A1.IsLocked = true;
        var lockedPartner = r7.DragClip(v7, 20, 0);
        Harness.Check("Linked partner on a locked track blocks the move", lockedPartner.Result == DragResult.Rejected && v7.Start == S(10));
    }

    static void UndoCancelPerformance()
    {
        Harness.Section("Cancel / one-command / performance");
        var r = new Rig(); var c = r.Video(r.V1, 10, 5);
        r.DragClip(c, 30, 1, release: false);
        r.Drag.Cancel();
        Harness.Check("Escape cancels: model unchanged, nothing to undo", c.Start == S(10) && r.V1.Clips.Contains(c) && !r.Editor.Commands.CanUndo);
        Harness.Check("Cancel ends in Idle and reports Cancelled", r.Drag.State == DragState.Idle && r.Last?.Result == DragResult.Cancelled);
        var after = r.Drag.PointerUp(0, 0);
        Harness.Check("Stray MouseUp after cancel is ignored", after.Result == DragResult.None && c.Start == S(10));

        // many MouseMoves -> exactly one command
        r.Drag.PointerDown(r.X(10) + 20, r.RowY(0), c, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
        for (int i = 1; i <= 500; i++) r.Drag.PointerMove(r.X(10) + 20 + i, r.RowY(0));
        r.Drag.PointerUp(r.X(10) + 20 + 500, r.RowY(0));
        r.Editor.Undo();
        Harness.Check("500 MouseMoves = ONE undo step", Near(c.Start, S(10)) && !r.Editor.Commands.CanUndo);

        // pointer leaves the timeline (huge coords / negative) then returns
        r.Drag.PointerDown(r.X(10) + 20, r.RowY(0), c, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
        r.Drag.PointerMove(-5000, -5000);
        Harness.Check("Pointer far outside: preview invalid/clamped, model intact", c.Start == S(10) && r.Drag.Preview!.Ghosts[0].Start >= TimeSpan.Zero);
        r.Drag.PointerMove(r.X(10) + 20 + 100, r.RowY(0));
        var back = r.Drag.PointerUp(r.X(10) + 20 + 100, r.RowY(0));
        Harness.Check("Returning to the timeline works normally", back.Result == DragResult.Committed && Near(c.Start, S(11)));

        // scale: 500 clips, many moves
        var big = new Rig(); big.Snap.Enabled = true;
        Clip? target = null;
        for (int i = 0; i < 500; i++) { var k = big.Video(big.V1, i * 3, 2); if (i == 250) target = k; }
        big.Drag.PointerDown(big.X(750) + 20, big.RowY(0), target!, DragKind.Move, PointerModifiers.None, TimeSpan.Zero);
        var sw = System.Diagnostics.Stopwatch.StartNew();
        for (int i = 0; i < 2000; i++) big.Drag.PointerMove(big.X(750) + 20 + 4 + i * 0.7, big.RowY(i % 2 == 0 ? 0 : 1));
        sw.Stop();
        big.Drag.Cancel();
        Harness.Check($"2000 MouseMoves over 500 clips: {sw.ElapsedMilliseconds} ms (< 400)", sw.ElapsedMilliseconds < 400);
    }

    static void Boundaries()
    {
        Harness.Section("Boundaries");
        var r = new Rig(); var c = r.Video(r.V1, 3, 5, src: 7);
        r.DragClip(c, -10, 0);
        Harness.Check("Cannot go before 00:00 (clamped to 0)", c.Start == TimeSpan.Zero && c.Duration == S(5) && c.SourceStart == S(7));

        var f = new Rig(); var d = f.Video(f.V1, 3, 5);
        f.DragClip(d, 3.017, 0);   // 30fps frame = 33.3ms
        Harness.Check("Position is frame-aligned", f.Coords.FrameRate.FrameToTime(f.Coords.FrameRate.TimeToFrame(d.Start)) == d.Start);

        var near = new Rig(); var e = near.Video(near.V1, 0.05, 1);
        near.DragClip(e, 0.01, 0);
        Harness.Check("Clip near 00:00 can reach exactly 00:00 and not below", e.Start >= TimeSpan.Zero && e.Start <= S(0.05));

        var inv = new Rig();
        var bad = new VideoClip(inv.Media("z.mp4", MediaType.Video, 5), S(0), TimeSpan.Zero, S(0));
        Harness.Check("Zero-duration clip is invalid", !inv.Editor.Validation.ValidateNewClip(inv.Project, inv.V1, bad).IsValid);
        Harness.Check("Negative start is rejected", !inv.Editor.Validation.ValidateMoves(inv.Project, new[] { new PlannedMove(c, r.V1, r.V1, S(-1)) }).IsValid);
        Harness.Check("Empty move list is rejected", !inv.Editor.Validation.ValidateMoves(inv.Project, Array.Empty<PlannedMove>()).IsValid);
    }

    static void TrimBehaviour()
    {
        Harness.Section("Trim handles");
        var r = new Rig(); var c = r.Video(r.V1, 10, 5, src: 2);
        r.Drag.PointerDown(r.X(15) - 3, r.RowY(0), c, DragKind.TrimRight, PointerModifiers.None, TimeSpan.Zero);
        r.Drag.PointerMove(r.X(15) - 3 + 100, r.RowY(0));
        var o = r.Drag.PointerUp(r.X(15) - 3 + 100, r.RowY(0));
        Harness.Check("Trim right extends duration, start/source unchanged", o.Result == DragResult.Committed && Near(c.Duration, S(6)) && c.Start == S(10) && c.SourceStart == S(2));
        r.Editor.Undo();
        Harness.Check("Trim undo is one step", c.Duration == S(5));

        r.Drag.PointerDown(r.X(10) + 3, r.RowY(0), c, DragKind.TrimLeft, PointerModifiers.None, TimeSpan.Zero);
        r.Drag.PointerMove(r.X(10) + 3 + 100, r.RowY(0));
        r.Drag.PointerUp(r.X(10) + 3 + 100, r.RowY(0));
        Harness.Check("Trim left moves start+source together, end fixed", Near(c.Start, S(11)) && Near(c.SourceStart, S(3)) && Near(c.End, S(15)));

        var neighbour = r.Video(r.V1, 16, 3);
        r.Drag.PointerDown(r.X(15) - 3, r.RowY(0), c, DragKind.TrimRight, PointerModifiers.None, TimeSpan.Zero);
        r.Drag.PointerMove(r.X(15) - 3 + 300, r.RowY(0));
        var rej = r.Drag.PointerUp(r.X(15) - 3 + 300, r.RowY(0));
        Harness.Check("Trim into a neighbour is rejected", rej.Result == DragResult.Rejected && Near(c.End, S(15)));

        var d = new Rig(); var m = d.Video(d.V1, 1, 5, src: 0);
        d.Drag.PointerDown(d.X(1) + 3, d.RowY(0), m, DragKind.TrimLeft, PointerModifiers.None, TimeSpan.Zero);
        d.Drag.PointerMove(d.X(1) + 3 - 80, d.RowY(0));
        d.Drag.PointerUp(d.X(1) + 3 - 80, d.RowY(0));
        Harness.Check("Can't extend left past the start of the source media", m.SourceStart >= TimeSpan.Zero && m.Start >= TimeSpan.Zero);
    }

    static void DropFromBin()
    {
        Harness.Section("Drop from Media Bin");
        var r = new Rig();
        var vm = r.Media("clip.mp4", MediaType.Video, 8);
        var am = r.Media("song.mp3", MediaType.Audio, 20);
        var im = r.Media("pic.png", MediaType.Image, 0);

        var o = r.Drop.Drop(vm, r.X(4), r.RowY(0), TimeSpan.Zero);
        Harness.Check("Video drop creates a REAL clip in the model", o.Success && r.V1.Clips.Count == 1 && r.V1.Clips[0].Start == S(4) && r.V1.Clips[0].Duration == S(8));
        r.Editor.Undo();
        Harness.Check("Drop is one undo step", r.V1.Clips.Count == 0);
        r.Editor.Redo();
        Harness.Check("Drop redo works", r.V1.Clips.Count == 1);

        var onAudio = r.Drop.Drop(vm, r.X(4), r.RowY(2), TimeSpan.Zero);
        Harness.Check("Video dropped on audio track is rejected, model unchanged", !onAudio.Success && r.A1.Clips.Count == 0);
        var audOnVideo = r.Drop.Drop(am, r.X(0), r.RowY(0), TimeSpan.Zero);
        Harness.Check("Audio dropped on video track is rejected", !audOnVideo.Success);

        var ao = r.Drop.Drop(am, r.X(1), r.RowY(3), TimeSpan.Zero);
        Harness.Check("Audio drop on audio track works", ao.Success && r.A2.Clips.Count == 1);

        var overlap = r.Drop.Drop(vm, r.X(6), r.RowY(0), TimeSpan.Zero);
        Harness.Check("Drop overlapping an existing clip is rejected", !overlap.Success && r.V1.Clips.Count == 1);

        var img = r.Drop.Drop(im, r.X(0), r.RowY(1), TimeSpan.Zero);
        Harness.Check("Image drop gets a default duration", img.Success && img.Clip!.Duration == TimelineDropController.DefaultImageDuration);

        int tracksBefore = r.Project.Tracks.Count;
        var newTrack = r.Drop.Drop(vm, r.X(40), r.RowY(tracksBefore + 1), TimeSpan.Zero);
        Harness.Check("Drop below the last track creates a matching track (one undo step)", newTrack.Success && r.Project.Tracks.Count == tracksBefore + 1);
        r.Editor.Undo();
        Harness.Check("Undo removes the clip AND the created track", r.Project.Tracks.Count == tracksBefore);

        var add = r.Drop.AddAtPlayhead(vm, S(50));
        Harness.Check("Add-at-playhead places clip at playhead", add.Success && add.Clip!.Start == S(50));
        var bad = r.Drop.AddAtPlayhead(new MediaItem("", MediaType.Video) { Duration = S(5) }, S(1));
        Harness.Check("Invalid media (empty path) is rejected", !bad.Success);
        var zero = r.Drop.AddAtPlayhead(r.Media("empty.mp4", MediaType.Video, 0), S(1));
        Harness.Check("Zero-duration media is rejected", !zero.Success);

        r.V1.IsLocked = true;
        var lk = r.Drop.Drop(vm, r.X(100), r.RowY(0), TimeSpan.Zero);
        Harness.Check("Drop on locked track is rejected", !lk.Success);
        var pv = r.Drop.Preview(vm, r.X(100), r.RowY(0), TimeSpan.Zero);
        Harness.Check("Drop preview explains the rejection", !pv.IsValid && !string.IsNullOrEmpty(pv.Message));

        var snapRig = new Rig(); snapRig.Snap.Enabled = true;
        snapRig.Video(snapRig.V1, 0, 5);
        var snapped = snapRig.Drop.Drop(snapRig.Media("s.mp4", MediaType.Video, 3), snapRig.X(5.04), snapRig.RowY(0), TimeSpan.Zero);
        Harness.Check("Drop applies snapping", snapped.Success && Near(snapped.Clip!.Start, S(5)));
    }

    static void AutoScroll()
    {
        Harness.Section("Auto-scroll");
        var a = new TimelineAutoScrollService { EdgeZone = 60, MaxSpeed = 1000 };
        Harness.Check("Center of viewport: no scroll", a.ComputeVelocity(500, 200, 1000, 400) == (0, 0));
        var slow = a.ComputeVelocity(940 + 10, 200, 1000, 400).Dx;
        var fast = a.ComputeVelocity(995, 200, 1000, 400).Dx;
        Harness.Check("Speed increases as the pointer nears the edge", slow > 0 && fast > slow);
        Harness.Check("Left edge scrolls left", a.ComputeVelocity(5, 200, 1000, 400).Dx < 0);
        Harness.Check("Past the edge is capped at max speed", Math.Abs(a.ComputeVelocity(5000, 200, 1000, 400).Dx - 1000) < 1e-9);
        Harness.Check("Vertical auto-scroll works", a.ComputeVelocity(500, 395, 1000, 400).Dy > 0 && a.ComputeVelocity(500, 2, 1000, 400).Dy < 0);
        var adv = a.Advance((-1000, 0), S(1), 100, 0, 5000, 0);
        Harness.Check("Offsets are clamped at 0", adv.X == 0);
        var adv2 = a.Advance((1000, 0), S(10), 100, 0, 5000, 0);
        Harness.Check("Offsets are clamped at max", adv2.X == 5000);
    }

    static void PlaybackUnaffected()
    {
        Harness.Section("Regression: drag does not touch playback");
        var b = new FakeBackend(); var session = new CSharpVideoStudio.Playback.MediaPlayerSession(b);
        var r = new Rig(); var c = r.Video(r.V1, 0, 10);
        session.Open("x.mp4"); session.Play(); b.Advance(S(3));
        r.DragClip(c, 20, 1);
        Harness.Check("Dragging clips never reloads/seeks/pauses the player", b.LoadCount == 1 && b.Playing && b.Position == S(3));
        session.Pause(); session.Play(); b.Advance(S(1));
        Harness.Check("Play->Pause->Play still resumes after a timeline edit", b.Position == S(4));
    }
}
