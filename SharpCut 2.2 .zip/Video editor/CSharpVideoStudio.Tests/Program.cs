namespace CSharpVideoStudio.Tests;

static class Harness
{
    public static int Failed, Passed;

    public static void Section(string name) => Console.WriteLine($"\n== {name}");

    public static void Check(string name, bool ok)
    {
        Console.WriteLine($"{(ok ? "PASS" : "FAIL")}  {name}");
        if (ok) Passed++; else Failed++;
    }

    /// <summary>A test that throws counts as a failure instead of aborting the run.</summary>
    public static void Safe(string name, Action body)
    {
        try { body(); }
        catch (Exception ex) { Check($"{name} (threw {ex.GetType().Name}: {ex.Message})", false); }
    }
}

static class Program
{
    static int Main()
    {
        Harness.Safe("playback", PlaybackTests.Run);
        Harness.Safe("timeline", TimelineTests.Run);
        Harness.Safe("audio vertical move", AudioMoveTests.Run);
        Harness.Safe("preview director", PreviewTests.Run);
        Console.WriteLine($"\n{Harness.Passed} passed, {Harness.Failed} failed");
        return Harness.Failed == 0 ? 0 : 1;
    }
}
