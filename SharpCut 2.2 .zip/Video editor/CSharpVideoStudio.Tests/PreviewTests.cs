using CSharpVideoStudio.Playback;

namespace CSharpVideoStudio.Tests;

/// <summary>
/// Models a LibVLC-like backend: counts every command so tests can prove the preview never reloads,
/// re-seeks or re-plays on ticks. This verifies the coordination logic; it is NOT proof that real
/// LibVLC/WPF playback works (that needs the manual checklist in INTEGRATION_NOTES.md).
/// </summary>
internal sealed class SimBackend : IPlaybackBackend
{
    public int Loads, Plays, Pauses, Stops, Seeks, VolumeCalls;
    public bool Started, Wanted;
    public TimeSpan LagOnStart = TimeSpan.Zero;
    public TimeSpan Position { get; private set; }
    public TimeSpan Duration => TimeSpan.FromMinutes(5);
    public event Action<string>? Failed;

    public void Load(string path)
    {
        if (path.Contains("missing")) throw new FileNotFoundException("missing", path);
        Loads++; Position = TimeSpan.Zero; Started = false; Wanted = false;
    }
    public void Play() { Plays++; Wanted = true; if (!Started) { Started = true; Position -= LagOnStart; if (Position < TimeSpan.Zero) Position = TimeSpan.Zero; } }
    public void Pause() { Pauses++; Wanted = false; }
    public void Stop() { Stops++; Wanted = false; Started = false; Position = TimeSpan.Zero; }
    public void Seek(TimeSpan t) { Seeks++; Position = t; }
    public void SetVolume(double v) => VolumeCalls++;
    public void Tick(TimeSpan dt) { if (Wanted) Position += dt; }
    public void RaiseFailed() => Failed?.Invoke("decoder error");
    public void Dispose() { }
}

static class PreviewTests
{
    static TimeSpan S(double s) => TimeSpan.FromSeconds(s);
    static readonly TimeSpan Tick = TimeSpan.FromMilliseconds(100);

    sealed class Rig
    {
        public SimBackend B = new();
        public MediaPlayerSession Session;
        public PreviewDirector D;
        public TimeSpan Now = TimeSpan.Zero;       // virtual clock
        public TimeSpan Pos = TimeSpan.Zero;       // timeline source position
        public bool Playing;
        public List<(PreviewStatus, string?)> Statuses = new();

        public Rig(TimeSpan? lag = null)
        {
            if (lag is { } l) B.LagOnStart = l;
            Session = new MediaPlayerSession(B);
            D = new PreviewDirector(Session, B, () => Now);
            D.StatusChanged += (s, m) => Statuses.Add((s, m));
        }

        public void Sync(string path) => D.Sync(path, Pos, Playing, 1.0);

        /// <summary>One UI tick: advance both clocks if playing, then Sync (exactly what the app does every 100 ms).</summary>
        public void Run(string path, double seconds)
        {
            int n = (int)Math.Round(seconds * 10);
            for (int i = 0; i < n; i++)
            {
                Now += Tick; B.Tick(Tick);
                if (Playing) Pos += Tick;
                Sync(path);
            }
        }
    }

    public static void Run()
    {
        Harness.Section("Preview director (simulated backend, virtual clock)");
        SteadyPlayback();
        PauseSeekStop();
        ClipSwitching();
        Failures();
        ExtremeCases();
    }

    static void SteadyPlayback()
    {
        var r = new Rig(lag: TimeSpan.FromMilliseconds(300));
        r.Playing = true; r.Sync("a.mp4");
        r.Run("a.mp4", 40);      // spans the reported 10-11 s freeze point
        Harness.Check("40 s of ticks: media loaded ONCE", r.B.Loads == 1);
        Harness.Check("40 s of ticks: Play issued once, never per tick", r.B.Plays == 1 && r.B.Pauses == 0 && r.B.Stops == 0);
        Harness.Check("40 s of ticks: only the initial positioning seek", r.B.Seeks == 1);
        Harness.Check("Volume forwarded once, not per tick", r.B.VolumeCalls == 1);
        Harness.Check("Status is Playing", r.D.Status == PreviewStatus.Playing);

        var slow = new Rig(lag: TimeSpan.FromSeconds(5));   // pathological decoder far behind the timeline
        slow.Playing = true; slow.Sync("a.mp4"); slow.Run("a.mp4", 40);
        Harness.Check($"Large drift: corrections are rate limited ({slow.B.Seeks - 1} in 40 s)", slow.B.Seeks - 1 <= 13);
        Harness.Check("Large drift never reloads the media", slow.B.Loads == 1);

        var stall = new Rig(); stall.Playing = true; stall.Sync("a.mp4"); stall.Run("a.mp4", 5);
        int before = stall.B.Seeks;
        // UI thread stalls 600 ms: wall time passes, the timeline adds the whole elapsed time, the player free-runs.
        stall.Now += S(0.6); stall.B.Tick(S(0.6)); stall.Pos += S(0.6); stall.Sync("a.mp4");
        stall.Run("a.mp4", 5);
        Harness.Check("UI stall (clocks stay consistent): no seek, no reload", stall.B.Seeks == before && stall.B.Loads == 1);

        var skew = new Rig(); skew.Playing = true; skew.Sync("a.mp4"); skew.Run("a.mp4", 5);
        int b2 = skew.B.Seeks;
        skew.Pos += S(0.8); skew.Sync("a.mp4");                    // timeline jumps ahead of wall time (e.g. clip trimmed under playhead)
        skew.Run("a.mp4", 5);
        Harness.Check("Timeline jump of 0.8 s: exactly one re-align seek, then stable", skew.B.Seeks == b2 + 1);
    }

    static void PauseSeekStop()
    {
        var r = new Rig();
        r.Playing = true; r.Sync("a.mp4"); r.Run("a.mp4", 5);
        int seeks = r.B.Seeks, loads = r.B.Loads;
        r.Playing = false; r.D.Pause(); r.Run("a.mp4", 2);
        Harness.Check("Pause: backend paused once, state Paused", r.B.Pauses == 1 && r.Session.State == PlaybackState.Paused);
        r.Playing = true; r.Run("a.mp4", 3);
        Harness.Check("Play -> Pause -> Play resumes (Playing, same media, no seek)", r.Session.State == PlaybackState.Playing && r.B.Loads == loads && r.B.Seeks == seeks && r.B.Stops == 0);

        r.Playing = false; r.D.Pause(); r.Run("a.mp4", 1);
        r.Pos = S(30); r.Run("a.mp4", 0.1);                     // seek while paused (scrub)
        Harness.Check("Seek while paused: one seek, still Paused", r.B.Seeks == seeks + 1 && r.Session.State == PlaybackState.Paused);
        r.Playing = true; r.Run("a.mp4", 2);
        Harness.Check("Play -> Pause -> Seek -> Play resumes from the new spot", r.Session.State == PlaybackState.Playing && r.B.Seeks == seeks + 1 && Math.Abs((r.B.Position - r.Pos).TotalMilliseconds) < 400);

        int s2 = r.B.Seeks;
        r.Pos += S(20); r.Run("a.mp4", 0.1);                    // seek while playing
        Harness.Check("Seek while playing: one immediate seek, keeps playing", r.B.Seeks == s2 + 1 && r.Session.State == PlaybackState.Playing);

        r.Playing = false; r.D.Clear();
        Harness.Check("Stop/Clear: backend stopped, status Idle", r.B.Stops >= 1 && r.Session.State == PlaybackState.Stopped && r.D.Status == PreviewStatus.Idle);
        r.Pos = S(2); r.Playing = true; r.Sync("a.mp4"); r.Run("a.mp4", 1);
        Harness.Check("Play -> Pause -> Stop -> Play works (media reopened)", r.Session.State == PlaybackState.Playing && r.B.Loads == loads + 1);

        var t = new Rig(); t.Playing = true; t.Sync("a.mp4");
        for (int i = 0; i < 200; i++) { t.Playing = !t.Playing; t.Now += Tick; if (!t.Playing) t.D.Pause(); t.Sync("a.mp4"); }
        Harness.Check("200 rapid play/pause toggles: one load, no seeks beyond the first", t.B.Loads == 1 && t.B.Seeks == 1);
    }

    static void ClipSwitching()
    {
        var r = new Rig();
        r.Playing = true; r.Sync("a.mp4"); r.Run("a.mp4", 3);
        r.Pos = S(0); r.Sync("b.mp4"); r.Run("b.mp4", 3);
        Harness.Check("Switch MP4 -> MP4: new media loaded, old stopped, playing", r.B.Loads == 2 && r.B.Stops == 1 && r.Session.State == PlaybackState.Playing);

        var split = new Rig(); split.Playing = true; split.Sync("a.mp4"); split.Run("a.mp4", 3);
        int s = split.B.Seeks;
        split.Run("a.mp4", 3);                                   // contiguous halves of the same file: no discontinuity
        Harness.Check("Same file continuing (split halves): no reload, no seek", split.B.Loads == 1 && split.B.Seeks == s);
        split.Pos += S(40); split.Run("a.mp4", 0.1);             // other part of the same file
        Harness.Check("Same file, different source range: one seek, no reload", split.B.Seeks == s + 1 && split.B.Loads == 1);

        var m = new Rig();                                       // MP4 -> (MP3 only: preview cleared) -> MP4
        m.Playing = true; m.Sync("a.mp4"); m.Run("a.mp4", 2);
        m.D.Clear();
        Harness.Check("MP4 -> MP3 region: preview cleared (Idle)", m.D.Status == PreviewStatus.Idle && m.Session.State == PlaybackState.Stopped);
        m.Run("a.mp4", 0);  m.Pos = S(0); m.Sync("a.mp4"); m.Run("a.mp4", 2);
        Harness.Check("MP3 region -> MP4: plays again", m.Session.State == PlaybackState.Playing && m.B.Loads == 2);

        var e = new Rig(); e.Playing = true; e.Sync("a.mp4"); e.Run("a.mp4", 2);
        e.Playing = false; e.D.Clear();                          // PlaybackController.Stop() at end of project
        Harness.Check("End of project: stopped and Idle", e.Session.State == PlaybackState.Stopped && e.D.Status == PreviewStatus.Idle);
    }

    static void Failures()
    {
        var r = new Rig(); r.Playing = true;
        r.Sync("missing.mp4");
        Harness.Check("Missing media: no exception, status Error", r.D.Status == PreviewStatus.Error && r.Statuses.Any(x => x.Item1 == PreviewStatus.Error && x.Item2 == "Media file not found."));
        r.Run("missing.mp4", 10);
        Harness.Check("Missing media is not retried every tick", r.B.Loads == 0 && r.B.Plays == 0);
        Harness.Check("State machine consistent after the error", r.Session.State == PlaybackState.Stopped || r.Session.State == PlaybackState.Error);
        r.Pos = S(0); r.Sync("a.mp4"); r.Run("a.mp4", 1);
        Harness.Check("Recovers on the next valid clip", r.D.Status == PreviewStatus.Playing && r.B.Loads == 1);

        var a = new Rig(); a.Playing = true; a.Sync("a.mp4"); a.Run("a.mp4", 2);
        a.B.RaiseFailed();                                       // async decoder failure
        Harness.Check("Async decoder failure: status Error, session Error", a.D.Status == PreviewStatus.Error && a.Session.State == PlaybackState.Error);
        int plays = a.B.Plays, loads = a.B.Loads;
        a.Run("a.mp4", 5);
        Harness.Check("After async failure ticks do not hammer the backend", a.B.Plays == plays && a.B.Loads == loads);
        a.Pos = S(0); a.Sync("b.mp4"); a.Run("b.mp4", 1);
        Harness.Check("Async failure then a different clip: recovers", a.D.Status == PreviewStatus.Playing && a.Session.State == PlaybackState.Playing);
    }

    static void ExtremeCases()
    {
        var r = new Rig(); r.Playing = true; r.Sync("a.mp4"); r.Run("a.mp4", 1);
        Harness.Check("Loading state is shown before the first frame moves", r.Statuses.Any(x => x.Item1 == PreviewStatus.Loading));
        Harness.Check("Same path with different case is the same media", Check(r));
    }

    static bool Check(Rig r) { int l = r.B.Loads; r.Sync("A.MP4"); return r.B.Loads == l; }
}
