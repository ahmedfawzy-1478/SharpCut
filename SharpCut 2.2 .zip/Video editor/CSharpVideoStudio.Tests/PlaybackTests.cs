using CSharpVideoStudio.Playback;

namespace CSharpVideoStudio.Tests;

// Fake backend that models real behaviour: position advances only while playing,
// and any use after Dispose/Stop-without-reload would throw.
internal sealed class FakeBackend : IPlaybackBackend
{
    public bool Disposed, Playing; public int LoadCount;
    public TimeSpan Position { get; private set; }
    public TimeSpan Duration => TimeSpan.FromMinutes(1);
    public event Action<string>? Failed;
    public double Volume;
    public void SetVolume(double v) => Volume = v;
    public void Load(string p) { LoadCount++; Position = TimeSpan.Zero; }
    public void Play() { if (Disposed) throw new ObjectDisposedException("backend"); Playing = true; }
    public void Pause() { Playing = false; }
    public void Stop() { Playing = false; Position = TimeSpan.Zero; }
    public void Seek(TimeSpan t) => Position = t;
    public void Advance(TimeSpan d) { if (Playing) Position += d; }
    public void Dispose() => Disposed = true;
}

static class PlaybackTests
{
    public static void Run()
    {
        Harness.Section("Playback");
        {   // Regression: Play -> Pause -> Play must resume from paused position
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Play(); b.Advance(TimeSpan.FromSeconds(5));
            c.Pause(); var paused = c.Position; b.Advance(TimeSpan.FromSeconds(3));
            c.Play(); b.Advance(TimeSpan.FromSeconds(2));
            Harness.Check("Play->Pause->Play state is Playing", c.State == PlaybackState.Playing);
            Harness.Check("Pause keeps position", paused == TimeSpan.FromSeconds(5));
            Harness.Check("Resumes from paused position", c.Position == TimeSpan.FromSeconds(7));
            Harness.Check("Backend not reloaded or disposed", b.LoadCount == 1 && !b.Disposed);
        }
        {   // Repeated toggling
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4");
            for (int i = 0; i < 100; i++) c.TogglePlayPause();
            Harness.Check("100 toggles end Paused", c.State == PlaybackState.Paused);
        }
        {   // Seek preserves the prior state
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Seek(TimeSpan.FromSeconds(10));
            Harness.Check("Seek while Paused stays Paused", c.State == PlaybackState.Paused && c.Position.TotalSeconds == 10);
            c.Play(); c.Seek(TimeSpan.FromSeconds(20));
            Harness.Check("Seek while Playing stays Playing", c.State == PlaybackState.Playing);
        }
        {   // Stop then Play
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Play(); c.Stop();
            Harness.Check("Stop resets to Stopped/0", c.State == PlaybackState.Stopped && c.Position == TimeSpan.Zero);
            c.Play();
            Harness.Check("Stopped -> Playing allowed", c.State == PlaybackState.Playing);
        }
        {   // Frame step at 29.97
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Seek(TimeSpan.FromSeconds(1)); c.StepFrame(1, 30000.0 / 1001);
            Harness.Check("Frame step forward ~33.37ms", Math.Abs((c.Position - TimeSpan.FromSeconds(1)).TotalMilliseconds - 33.37) < 0.1);
        }
        {   // Illegal transition
            var m = new PlaybackStateMachine(); m.TransitionTo(PlaybackState.Playing);
            bool threw = false; try { m.TransitionTo(PlaybackState.Loading); } catch (InvalidOperationException) { threw = true; }
            Harness.Check("Playing -> Loading rejected", threw);
        }
        {   // Play -> Pause -> Seek -> Play
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Play(); b.Advance(TimeSpan.FromSeconds(4)); c.Pause();
            c.Seek(TimeSpan.FromSeconds(30)); c.Play(); b.Advance(TimeSpan.FromSeconds(1));
            Harness.Check("Play->Pause->Seek->Play resumes at seek target", c.State == PlaybackState.Playing && c.Position == TimeSpan.FromSeconds(31));
        }
        {   // Play -> Pause -> Stop -> Play
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Play(); c.Pause(); c.Stop(); c.Play();
            Harness.Check("Play->Pause->Stop->Play works", c.State == PlaybackState.Playing && b.Playing && !b.Disposed);
        }
        {   // Play -> Seek -> Pause -> Play
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Play(); c.Seek(TimeSpan.FromSeconds(12)); c.Pause(); c.Play(); b.Advance(TimeSpan.FromSeconds(1));
            Harness.Check("Play->Seek->Pause->Play keeps position", c.State == PlaybackState.Playing && c.Position == TimeSpan.FromSeconds(13));
        }
        {   // Pause when not playing is a no-op, Play twice is idempotent
            var b = new FakeBackend(); var c = new MediaPlayerSession(b);
            c.Open("x.mp4"); c.Pause(); c.Play(); c.Play();
            Harness.Check("Idempotent Pause/Play", c.State == PlaybackState.Playing);
        }
    }
}
