﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace CSharpVideoStudio;

public sealed class MediaImportService
{
    private readonly MediaService _mediaService;

    public MediaImportService(
        MediaService mediaService)
    {
        _mediaService =
            mediaService;
    }

    public async Task<MediaItem?> ImportAsync(
        string filePath)
    {
        if (!File.Exists(filePath))
            return null;

        MediaType? type =
            DetectType(filePath);

        if (type == null)
            return null;

        MediaItem item =
            new MediaItem(
                filePath,
                type.Value);

        if (type == MediaType.Video ||
            type == MediaType.Audio)
        {
            item.Duration =
                await _mediaService
                    .GetDurationAsync(
                        filePath);
        }
        else
        {
            item.Duration =
                TimeSpan.FromSeconds(5);
        }

        return item;
    }

    private static MediaType? DetectType(
        string filePath)
    {
        string extension =
            Path.GetExtension(filePath)
                .ToLowerInvariant();

        return extension switch
        {
            ".mp4" or
            ".mkv" or
            ".avi" or
            ".mov" or
            ".wmv" or
            ".webm"
                => MediaType.Video,

            ".mp3" or
            ".wav" or
            ".aac" or
            ".flac" or
            ".m4a"
                => MediaType.Audio,

            ".png" or
            ".jpg" or
            ".jpeg" or
            ".bmp" or
            ".webp"
                => MediaType.Image,

            _ => null
        };
    }
}