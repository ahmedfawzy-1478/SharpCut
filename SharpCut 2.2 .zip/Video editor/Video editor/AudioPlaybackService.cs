﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

namespace CSharpVideoStudio;

public sealed class AudioPlaybackService : IDisposable
{
    private sealed class PlayerEntry
    {
        public required AudioClip Clip { get; init; }
        public required MediaPlayer Player { get; init; }
        public bool IsOpened { get; set; }
        public bool IsActive { get; set; }
        public bool WantsToPlay { get; set; }
        public bool IsPlaying { get; set; }
        public TimeSpan PendingPosition { get; set; }
    }

    private readonly Dictionary<Guid, PlayerEntry> _players = new();
    private double _masterVolume = 1.0;

    public double MasterVolume
    {
        get => _masterVolume;
        set
        {
            _masterVolume = Math.Clamp(value, 0.0, 1.0);
            ApplyVolumeToAllActivePlayers();
        }
    }

    public void ApplyVolumeToAllActivePlayers()
    {
        foreach (var entry in _players.Values)
        {
            if (entry.IsOpened)
            {
                entry.Player.Volume = Math.Clamp(entry.Clip.Volume * _masterVolume, 0.0, 1.0);
            }
        }
    }

    public void SyncAudio(Project project, TimeSpan currentPosition, bool isPlaying, bool isSeeking = false)
    {
        HashSet<Guid> activeIds = new();

        foreach (Track track in project.Tracks)
        {
            if (track.Type != TrackType.Audio || track.IsMuted)
                continue;

            foreach (AudioClip clip in track.Clips.OfType<AudioClip>())
            {
                bool active = currentPosition >= clip.Start &&
                             currentPosition < clip.End &&
                             !clip.Muted;

                if (!active)
                    continue;

                activeIds.Add(clip.Id);

                PlayerEntry entry = GetOrCreate(clip);
                bool newlyActivated = !entry.IsActive;
                entry.IsActive = true;
                entry.WantsToPlay = isPlaying;

                entry.Player.Volume = Math.Clamp(clip.Volume * MasterVolume, 0.0, 1.0);

                TimeSpan targetSourcePos = clip.SourceStart + (currentPosition - clip.Start);
                entry.PendingPosition = targetSourcePos;

                if (isPlaying)
                {
                    if (entry.IsOpened)
                    {
                        if (newlyActivated || isSeeking || !entry.IsPlaying)
                        {
                            entry.Player.Position = targetSourcePos;
                            entry.Player.Play();
                            entry.IsPlaying = true;
                        }
                    }
                }
                else
                {
                    if (entry.IsOpened)
                    {
                        if (entry.IsPlaying || isSeeking || newlyActivated)
                        {
                            entry.Player.Pause();
                            entry.Player.Position = targetSourcePos;
                            entry.IsPlaying = false;
                        }
                    }
                }
            }
        }

        foreach (PlayerEntry entry in _players.Values)
        {
            if (!activeIds.Contains(entry.Clip.Id))
            {
                if (entry.IsActive)
                {
                    entry.IsActive = false;
                    entry.WantsToPlay = false;
                    if (entry.IsOpened && entry.IsPlaying)
                    {
                        entry.Player.Pause();
                        entry.IsPlaying = false;
                    }
                }
            }
        }
    }

    private PlayerEntry GetOrCreate(AudioClip clip)
    {
        if (_players.TryGetValue(clip.Id, out PlayerEntry? existing))
            return existing;

        MediaPlayer player = new MediaPlayer();

        PlayerEntry entry = new PlayerEntry
        {
            Clip = clip,
            Player = player
        };

        player.MediaOpened += (_, _) =>
        {
            entry.IsOpened = true;
            player.Volume = Math.Clamp(clip.Volume * MasterVolume, 0.0, 1.0);
            player.Position = entry.PendingPosition;

            if (entry.IsActive && entry.WantsToPlay)
            {
                player.Play();
                entry.IsPlaying = true;
            }
        };

        player.MediaEnded += (_, _) =>
        {
            entry.IsPlaying = false;
        };

        player.MediaFailed += (_, _) =>
        {
            entry.IsOpened = false;
            entry.IsPlaying = false;
            entry.WantsToPlay = false;
            entry.IsActive = false;
        };

        _players.Add(clip.Id, entry);

        try
        {
            player.Open(new Uri(clip.Media.FilePath, UriKind.Absolute));
        }
        catch
        {
            _players.Remove(clip.Id);
            player.Close();
            throw;
        }

        return entry;
    }

    public void PauseAll()
    {
        foreach (PlayerEntry entry in _players.Values)
        {
            entry.WantsToPlay = false;

            if (entry.IsOpened && entry.IsPlaying)
            {
                entry.Player.Pause();
                entry.IsPlaying = false;
            }
        }
    }

    public void StopAll()
    {
        foreach (PlayerEntry entry in _players.Values)
        {
            entry.WantsToPlay = false;
            entry.IsActive = false;

            if (entry.IsOpened)
            {
                entry.Player.Stop();
                entry.IsPlaying = false;
            }
        }
    }

    public void Clear()
    {
        foreach (PlayerEntry entry in _players.Values)
        {
            entry.Player.Stop();
            entry.Player.Close();
        }

        _players.Clear();
    }

    public void Dispose()
    {
        Clear();
    }
}