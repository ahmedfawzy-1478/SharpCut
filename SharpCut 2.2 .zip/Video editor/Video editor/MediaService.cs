﻿using System;
using System.Threading.Tasks;
using System.Windows.Media;

namespace CSharpVideoStudio;

public sealed class MediaService
{
    public Task<TimeSpan> GetDurationAsync(
        string filePath)
    {
        TaskCompletionSource<TimeSpan> source =
            new(
                TaskCreationOptions
                    .RunContinuationsAsynchronously);

        MediaPlayer player =
            new MediaPlayer();

        EventHandler? opened = null;

        EventHandler<ExceptionEventArgs>? failed =
            null;

        opened = (_, _) =>
        {
            TimeSpan duration =
                player.NaturalDuration
                    .HasTimeSpan
                    ? player.NaturalDuration.TimeSpan
                    : TimeSpan.Zero;

            source.TrySetResult(
                duration);

            Cleanup();
        };

        failed = (_, _) =>
        {
            source.TrySetResult(
                TimeSpan.Zero);

            Cleanup();
        };

        void Cleanup()
        {
            player.MediaOpened -=
                opened;

            player.MediaFailed -=
                failed;

            player.Close();
        }

        player.MediaOpened +=
            opened;

        player.MediaFailed +=
            failed;

        try
        {
            player.Open(
                new Uri(
                    filePath,
                    UriKind.Absolute));
        }
        catch
        {
            Cleanup();

            source.TrySetResult(
                TimeSpan.Zero);
        }

        return source.Task;
    }
}