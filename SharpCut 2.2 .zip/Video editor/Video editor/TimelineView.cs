﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using CSharpVideoStudio.Timeline;

namespace CSharpVideoStudio;

public sealed class TimelineView
{
    private const double ClipPadding = 4;
    private const double TrimHandleWidth = 10;
    private const double GrowMarginPixels = 1200;

    private static readonly Brush RowEven = Frozen(Color.FromRgb(24, 27, 34));
    private static readonly Brush RowOdd = Frozen(Color.FromRgb(20, 23, 29));
    private static readonly Brush RowLocked = Frozen(Color.FromRgb(34, 28, 24));
    private static readonly Brush ValidFill = Frozen(Color.FromArgb(70, 80, 200, 120));
    private static readonly Brush InvalidFill = Frozen(Color.FromArgb(80, 230, 70, 70));
    private static readonly Brush GhostValid = Frozen(Color.FromArgb(150, 90, 170, 255));
    private static readonly Brush GhostInvalid = Frozen(Color.FromArgb(150, 230, 70, 70));
    private static readonly Brush SnapStroke = Frozen(Color.FromRgb(255, 214, 10));
    private static readonly Brush HatchBrush = CreateHatch();

    private readonly Canvas _canvas;
    private readonly Canvas _ruler;
    private readonly Border _playhead;
    private readonly ScrollViewer _scroll;
    private readonly ScrollViewer? _rulerScroll;
    private readonly ScrollViewer? _headersScroll;
    private readonly TranslateTransform _playheadTransform = new();

    private readonly Dictionary<Guid, Border> _clipViews = new();
    private readonly List<Rectangle> _rows = new();
    private readonly List<Border> _ghostPool = new();
    private readonly HashSet<Guid> _dimmed = new();

    private readonly Rectangle _targetRow = new() { IsHitTestVisible = false, Visibility = Visibility.Collapsed };
    private readonly Line _snapLine = new() { IsHitTestVisible = false, Visibility = Visibility.Collapsed, StrokeThickness = 1.5, Stroke = SnapStroke };
    private readonly Border _hint;
    private readonly TextBlock _hintText;
    private readonly DispatcherTimer _hintTimer = new() { Interval = TimeSpan.FromSeconds(2.5) };

    private readonly DispatcherTimer _autoScrollTimer = new(DispatcherPriority.Render) { Interval = TimeSpan.FromMilliseconds(16) };
    private readonly Stopwatch _autoScrollClock = new();
    private TimeSpan _lastAutoScrollTick;

    private TimelineController _timeline;
    private Point _lastPointer;

    public event Action? SelectionChanged;
    public event Action? ModelChanged;
    public event Action<TimeSpan>? SeekRequested;

    public TimelineView(Canvas canvas, Canvas ruler, Border playhead, ScrollViewer scroll,
        ScrollViewer? rulerScroll, ScrollViewer? headersScroll, TimelineController timeline)
    {
        _canvas = canvas;
        _ruler = ruler;
        _playhead = playhead;
        _scroll = scroll;
        _rulerScroll = rulerScroll;
        _headersScroll = headersScroll;
        _timeline = timeline;

        _playhead.RenderTransform = _playheadTransform;
        _playhead.IsHitTestVisible = false;

        _hintText = new TextBlock { Foreground = Brushes.White, FontSize = 11, Margin = new Thickness(8, 4, 8, 4) };
        _hint = new Border
        {
            Child = _hintText,
            Background = Frozen(Color.FromArgb(235, 120, 30, 30)),
            CornerRadius = new CornerRadius(4),
            IsHitTestVisible = false,
            Visibility = Visibility.Collapsed
        };

        _canvas.Background = Brushes.Transparent;
        _canvas.MouseLeftButtonDown += Canvas_MouseLeftButtonDown;
        _canvas.MouseMove += Canvas_MouseMove;
        _canvas.MouseLeftButtonUp += Canvas_MouseLeftButtonUp;
        _canvas.LostMouseCapture += Canvas_LostMouseCapture;
        _scroll.ScrollChanged += Scroll_ScrollChanged;
        _autoScrollTimer.Tick += AutoScrollTimer_Tick;
        _hintTimer.Tick += (_, _) => { _hintTimer.Stop(); _hint.Visibility = Visibility.Collapsed; };

        _autoScrollClock.Start();
        AttachDragEvents(_timeline);
    }

    private TimelineCoordinateService Coords => _timeline.Coordinates;

    public void SetTimeline(TimelineController timeline)
    {
        CancelDrag();
        DetachDragEvents(_timeline);
        _timeline = timeline;
        AttachDragEvents(_timeline);
    }

    private void AttachDragEvents(TimelineController t)
    {
        t.Drag.Started += OnDragStarted;
        t.Drag.PreviewChanged += OnPreviewChanged;
        t.Drag.Ended += OnDragEnded;
    }

    private void DetachDragEvents(TimelineController t)
    {
        t.Drag.Started -= OnDragStarted;
        t.Drag.PreviewChanged -= OnPreviewChanged;
        t.Drag.Ended -= OnDragEnded;
    }

    public bool CancelDrag()
    {
        bool was = _timeline.Drag.State != DragState.Idle;
        _timeline.Drag.Cancel();
        if (_canvas.IsMouseCaptured) _canvas.ReleaseMouseCapture();
        HideOverlays();
        return was;
    }

    public void Rebuild(TimeSpan playheadPosition)
    {
        CancelDrag();

        // فك ارتباط الـ Playhead لتجنب أخطاء Parent duplicate
        if (_playhead.Parent is Panel p)
        {
            p.Children.Remove(_playhead);
        }

        Project project = _timeline.Project;
        _canvas.Children.Clear();
        _ruler.Children.Clear();
        _clipViews.Clear();
        _rows.Clear();
        _dimmed.Clear();

        double width = Math.Max(
            Coords.TimeToContentX(project.Duration) + GrowMarginPixels,
            Coords.TimeToContentX(TimeSpan.FromSeconds(30)));
        width = Math.Max(width, _scroll.ViewportWidth + GrowMarginPixels);

        int rowCount = project.Tracks.Count + 3;
        double height = rowCount * Coords.TrackHeight;
        _canvas.Width = width;
        _canvas.Height = height;
        _ruler.Width = width;

        for (int i = 0; i < rowCount; i++)
        {
            bool locked = i < project.Tracks.Count && project.Tracks[i].IsLocked;
            Rectangle row = new()
            {
                Width = width,
                Height = Coords.TrackHeight,
                Fill = locked ? RowLocked : (i % 2 == 0 ? RowEven : RowOdd),
                IsHitTestVisible = false
            };
            Canvas.SetLeft(row, 0);
            Canvas.SetTop(row, Coords.TrackTop(i));
            _canvas.Children.Add(row);
            _rows.Add(row);

            if (locked)
            {
                Rectangle hatch = new() { Width = width, Height = Coords.TrackHeight, Fill = HatchBrush, IsHitTestVisible = false };
                Canvas.SetLeft(hatch, 0);
                Canvas.SetTop(hatch, Coords.TrackTop(i));
                _canvas.Children.Add(hatch);
                _rows.Add(hatch);
            }
        }

        for (int i = 0; i < project.Tracks.Count; i++)
            foreach (Clip clip in project.Tracks[i].Clips)
                AddClipView(project.Tracks[i], clip, i);

        DrawRuler(width);
        AddOverlays(height);
        UpdatePlayhead(playheadPosition);
    }

    private void AddClipView(Track track, Clip clip, int trackIndex)
    {
        bool selected = _timeline.Selection.IsSelected(clip);
        Border border = new()
        {
            Width = Math.Max(2, Coords.DurationToPixels(clip.Duration)),
            Height = Math.Max(8, Coords.TrackHeight - ClipPadding * 2),
            Background = ClipBrush(clip, track),
            BorderBrush = selected ? Brushes.White : Brushes.Gray,
            BorderThickness = new Thickness(selected ? 2 : 1),
            CornerRadius = new CornerRadius(4),
            ClipToBounds = true,
            IsHitTestVisible = false
        };

        string name = clip.Media?.FileName ?? "Clip";
        border.Child = new TextBlock
        {
            Text = clip.LinkGroupId.HasValue ? "🔗 " + name : name,
            Foreground = Brushes.White,
            FontSize = 11,
            Margin = new Thickness(10, 0, 10, 0),
            VerticalAlignment = VerticalAlignment.Center,
            TextTrimming = TextTrimming.CharacterEllipsis,
            IsHitTestVisible = false
        };

        Canvas.SetLeft(border, Coords.TimeToContentX(clip.Start));
        Canvas.SetTop(border, Coords.TrackTop(trackIndex) + ClipPadding);
        Panel.SetZIndex(border, selected ? 20 : 5);
        _canvas.Children.Add(border);
        _clipViews[clip.Id] = border;
    }

    private static Brush ClipBrush(Clip clip, Track track)
    {
        Color c = clip switch
        {
            VideoClip => Color.FromRgb(43, 70, 112),
            AudioClip => Color.FromRgb(42, 91, 68),
            _ => Color.FromRgb(88, 62, 112)
        };
        if (track.IsLocked) c = Color.FromRgb((byte)(c.R / 2 + 30), (byte)(c.G / 2 + 30), (byte)(c.B / 2 + 30));
        return new SolidColorBrush(c);
    }

    private void AddOverlays(double canvasHeight)
    {
        if (_targetRow.Parent is Panel trP) trP.Children.Remove(_targetRow);
        _canvas.Children.Add(_targetRow);
        Panel.SetZIndex(_targetRow, 400);

        _snapLine.Y1 = 0;
        _snapLine.Y2 = canvasHeight;
        if (_snapLine.Parent is Panel slP) slP.Children.Remove(_snapLine);
        _canvas.Children.Add(_snapLine);
        Panel.SetZIndex(_snapLine, 900);

        foreach (Border g in _ghostPool)
        {
            g.Visibility = Visibility.Collapsed;
            if (g.Parent is Panel gP) gP.Children.Remove(g);
            _canvas.Children.Add(g);
            Panel.SetZIndex(g, 600);
        }

        if (_hint.Parent is Panel hP) hP.Children.Remove(_hint);
        _canvas.Children.Add(_hint);
        Panel.SetZIndex(_hint, 950);

        if (_playhead.Parent is Panel pP) pP.Children.Remove(_playhead);
        _canvas.Children.Add(_playhead);
        Canvas.SetLeft(_playhead, 0);
        Canvas.SetTop(_playhead, 0);
        Panel.SetZIndex(_playhead, 1000);
        _playhead.Height = canvasHeight;
    }

    private static readonly double[] TickSteps = { 0.04, 0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 1800, 3600 };

    private void DrawRuler(double width)
    {
        double step = TickSteps.FirstOrDefault(s => s * Coords.PixelsPerSecond >= 80);
        if (step <= 0) step = TickSteps[^1];

        double maxSeconds = width / Coords.PixelsPerSecond;
        for (double s = 0; s <= maxSeconds; s += step)
        {
            double x = s * Coords.PixelsPerSecond;
            _ruler.Children.Add(new Line { X1 = x, X2 = x, Y1 = 17, Y2 = 28, Stroke = Brushes.Gray, StrokeThickness = 1 });

            TimeSpan t = TimeSpan.FromSeconds(s);
            string label = step < 1
                ? t.ToString(@"mm\:ss\.ff")
                : (t.TotalHours >= 1 ? t.ToString(@"h\:mm\:ss") : t.ToString(@"mm\:ss"));

            TextBlock text = new() { Text = label, Foreground = Brushes.Gray, FontSize = 10 };
            Canvas.SetLeft(text, x + 4);
            Canvas.SetTop(text, 2);
            _ruler.Children.Add(text);
        }
    }

    public void UpdatePlayhead(TimeSpan position) => _playheadTransform.X = Coords.TimeToContentX(position);

    public void RefreshSelectionVisuals()
    {
        foreach (Track track in _timeline.Project.Tracks)
            foreach (Clip clip in track.Clips)
            {
                if (!_clipViews.TryGetValue(clip.Id, out Border? view)) continue;
                bool selected = _timeline.Selection.IsSelected(clip);
                view.BorderBrush = selected ? Brushes.White : Brushes.Gray;
                view.BorderThickness = new Thickness(selected ? 2 : 1);
                Panel.SetZIndex(view, selected ? 20 : 5);
            }
    }

    private void Scroll_ScrollChanged(object sender, ScrollChangedEventArgs e)
    {
        Coords.HorizontalOffset = e.HorizontalOffset;
        Coords.VerticalOffset = e.VerticalOffset;
        _rulerScroll?.ScrollToHorizontalOffset(e.HorizontalOffset);
        _headersScroll?.ScrollToVerticalOffset(e.VerticalOffset);
    }

    private static PointerModifiers Mods()
    {
        PointerModifiers m = PointerModifiers.None;
        ModifierKeys k = Keyboard.Modifiers;
        if ((k & ModifierKeys.Shift) != 0) m |= PointerModifiers.Shift;
        if ((k & ModifierKeys.Control) != 0) m |= PointerModifiers.Ctrl;
        if ((k & ModifierKeys.Alt) != 0) m |= PointerModifiers.Alt;
        return m;
    }

    private (Track Track, Clip Clip, DragKind Kind)? HitTest(Point p)
    {
        int row = Coords.ContentYToTrackIndex(p.Y);
        Project project = _timeline.Project;
        if (row < 0 || row >= project.Tracks.Count) return null;

        Track track = project.Tracks[row];
        TimeSpan time = Coords.ContentXToTime(p.X);
        foreach (Clip clip in track.Clips)
        {
            if (time < clip.Start || time >= clip.End) continue;

            double left = Coords.TimeToContentX(clip.Start);
            double right = left + Coords.DurationToPixels(clip.Duration);
            double handle = Math.Min(TrimHandleWidth, (right - left) / 3);
            DragKind kind = p.X - left <= handle ? DragKind.TrimLeft
                          : right - p.X <= handle ? DragKind.TrimRight
                          : DragKind.Move;
            return (track, clip, kind);
        }
        return null;
    }

    private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        Point p = e.GetPosition(_canvas);
        _lastPointer = p;
        HideHint();

        var hit = HitTest(p);
        if (hit is null)
        {
            if ((Keyboard.Modifiers & ModifierKeys.Control) == 0 && _timeline.Selection.Count > 0)
            {
                _timeline.ClearSelection();
                RefreshSelectionVisuals();
                SelectionChanged?.Invoke();
            }

            TimeSpan t = Coords.ContentXToTime(p.X);
            if (t >= TimeSpan.Zero) SeekRequested?.Invoke(t);
            return;
        }

        bool selectionChanged = _timeline.Drag.PointerDown(
            p.X, p.Y, hit.Value.Clip, hit.Value.Kind, Mods(), _timeline.State.Position);

        _timeline.State.ActiveTrack = hit.Value.Track;
        _timeline.State.ActiveClip = hit.Value.Clip;

        _canvas.CaptureMouse();
        if (selectionChanged)
        {
            RefreshSelectionVisuals();
            SelectionChanged?.Invoke();
        }
        e.Handled = true;
    }

    private void Canvas_MouseMove(object sender, MouseEventArgs e)
    {
        Point p = e.GetPosition(_canvas);
        _lastPointer = p;

        if (_timeline.Drag.State == DragState.Idle)
        {
            UpdateCursor(p);
            return;
        }

        if (e.LeftButton != MouseButtonState.Pressed)
        {
            CancelDrag();
            return;
        }

        _timeline.Drag.PointerMove(p.X, p.Y, Mods());
        MoveHintWithPointer();
    }

    private void Canvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (_timeline.Drag.State == DragState.Idle)
        {
            if (_canvas.IsMouseCaptured) _canvas.ReleaseMouseCapture();
            return;
        }

        Point p = e.GetPosition(_canvas);
        _timeline.Drag.PointerUp(p.X, p.Y, Mods());
        if (_canvas.IsMouseCaptured) _canvas.ReleaseMouseCapture();
        e.Handled = true;
    }

    private void Canvas_LostMouseCapture(object sender, MouseEventArgs e)
    {
        if (_timeline.Drag.State != DragState.Idle)
        {
            _timeline.Drag.Cancel();
            HideOverlays();
        }
    }

    private void UpdateCursor(Point p)
    {
        var hit = HitTest(p);
        _canvas.Cursor = hit is null ? Cursors.Arrow
            : hit.Value.Track.IsLocked ? Cursors.No
            : hit.Value.Kind == DragKind.Move ? Cursors.SizeAll
            : Cursors.SizeWE;
    }

    private void OnDragStarted()
    {
        _lastAutoScrollTick = TimeSpan.Zero;
        _autoScrollClock.Restart();
        _autoScrollTimer.Start();
    }

    private void OnPreviewChanged(DragPreview preview)
    {
        foreach (GhostClip g in preview.Ghosts)
            if (_dimmed.Add(g.ClipId) && _clipViews.TryGetValue(g.ClipId, out Border? original))
                original.Opacity = 0.35;

        ShowGhosts(preview.Ghosts.Select(g => (g.TrackIndex, g.Start, g.Duration, g.IsValid)).ToList());
        ShowTargetRow(preview.TargetTrackIndex, preview.IsValid);

        if (preview.Snap is { } snap)
        {
            double x = Coords.TimeToContentX(snap.Time);
            _snapLine.X1 = x;
            _snapLine.X2 = x;
            _snapLine.Visibility = Visibility.Visible;
        }
        else
        {
            _snapLine.Visibility = Visibility.Collapsed;
        }

        if (!preview.IsValid && !string.IsNullOrEmpty(preview.Message))
            ShowHint(preview.Message!, _lastPointer);
        else
            HideHint();
    }

    private void OnDragEnded(DragOutcome outcome)
    {
        _autoScrollTimer.Stop();
        HideOverlays();

        switch (outcome.Result)
        {
            case DragResult.Committed:
                ModelChanged?.Invoke();
                break;
            case DragResult.Rejected:
                if (!string.IsNullOrEmpty(outcome.Message))
                    ShowTransientHint(outcome.Message!, _lastPointer);
                break;
            case DragResult.Click:
                RefreshSelectionVisuals();
                SelectionChanged?.Invoke();
                break;
        }
    }

    private void ShowGhosts(IReadOnlyList<(int TrackIndex, TimeSpan Start, TimeSpan Duration, bool IsValid)> ghosts)
    {
        while (_ghostPool.Count < ghosts.Count)
        {
            Border g = new()
            {
                CornerRadius = new CornerRadius(4),
                BorderThickness = new Thickness(1.5),
                BorderBrush = Brushes.White,
                IsHitTestVisible = false,
                Visibility = Visibility.Collapsed
            };
            _ghostPool.Add(g);
            _canvas.Children.Add(g);
            Panel.SetZIndex(g, 600);
        }

        double rightmost = 0;
        for (int i = 0; i < _ghostPool.Count; i++)
        {
            Border g = _ghostPool[i];
            if (i >= ghosts.Count) { g.Visibility = Visibility.Collapsed; continue; }

            var d = ghosts[i];
            double left = Coords.TimeToContentX(d.Start);
            double width = Math.Max(2, Coords.DurationToPixels(d.Duration));
            g.Width = width;
            g.Height = Math.Max(8, Coords.TrackHeight - ClipPadding * 2);
            g.Background = d.IsValid ? GhostValid : GhostInvalid;
            Canvas.SetLeft(g, left);
            Canvas.SetTop(g, Coords.TrackTop(Math.Max(0, d.TrackIndex)) + ClipPadding);
            g.Visibility = Visibility.Visible;
            rightmost = Math.Max(rightmost, left + width);
        }

        GrowCanvasIfNeeded(rightmost);
    }

    private void ShowTargetRow(int trackIndex, bool valid)
    {
        if (trackIndex < 0) { _targetRow.Visibility = Visibility.Collapsed; return; }
        _targetRow.Width = _canvas.Width;
        _targetRow.Height = Coords.TrackHeight;
        _targetRow.Fill = valid ? ValidFill : InvalidFill;
        Canvas.SetLeft(_targetRow, 0);
        Canvas.SetTop(_targetRow, Coords.TrackTop(trackIndex));
        _targetRow.Visibility = Visibility.Visible;
    }

    private void GrowCanvasIfNeeded(double rightEdge)
    {
        if (rightEdge < _canvas.Width - 300) return;
        double newWidth = rightEdge + GrowMarginPixels;
        _canvas.Width = newWidth;
        _ruler.Width = newWidth;
        foreach (Rectangle row in _rows) row.Width = newWidth;
    }

    private void HideOverlays()
    {
        _autoScrollTimer.Stop();
        foreach (Border g in _ghostPool) g.Visibility = Visibility.Collapsed;
        _targetRow.Visibility = Visibility.Collapsed;
        _snapLine.Visibility = Visibility.Collapsed;
        HideHint();

        foreach (Guid id in _dimmed)
            if (_clipViews.TryGetValue(id, out Border? view)) view.Opacity = 1.0;
        _dimmed.Clear();
    }

    private void ShowHint(string text, Point near)
    {
        _hintTimer.Stop();
        _hintText.Text = text;
        _hint.Visibility = Visibility.Visible;
        Canvas.SetLeft(_hint, near.X + 14);
        Canvas.SetTop(_hint, near.Y + 14);
    }

    private void ShowTransientHint(string text, Point near)
    {
        ShowHint(text, near);
        _hintTimer.Stop();
        _hintTimer.Start();
    }

    private void HideHint()
    {
        _hintTimer.Stop();
        _hint.Visibility = Visibility.Collapsed;
    }

    private void MoveHintWithPointer()
    {
        if (_hint.Visibility != Visibility.Visible) return;
        Canvas.SetLeft(_hint, _lastPointer.X + 14);
        Canvas.SetTop(_hint, _lastPointer.Y + 14);
    }

    private void AutoScrollTimer_Tick(object? sender, EventArgs e)
    {
        if (_timeline.Drag.State == DragState.Idle) { _autoScrollTimer.Stop(); return; }

        TimeSpan now = _autoScrollClock.Elapsed;
        TimeSpan dt = now - _lastAutoScrollTick;
        _lastAutoScrollTick = now;
        if (dt > TimeSpan.FromMilliseconds(50)) dt = TimeSpan.FromMilliseconds(50);

        Point viewportPoint = Mouse.GetPosition(_scroll);
        var velocity = _timeline.AutoScroll.ComputeVelocity(
            viewportPoint.X, viewportPoint.Y, _scroll.ViewportWidth, _scroll.ViewportHeight);
        if (velocity.Dx == 0 && velocity.Dy == 0) return;

        GrowCanvasIfNeeded(_scroll.HorizontalOffset + _scroll.ViewportWidth + 200);

        var (nx, ny) = _timeline.AutoScroll.Advance(
            velocity, dt, _scroll.HorizontalOffset, _scroll.VerticalOffset,
            _scroll.ScrollableWidth + (velocity.Dx > 0 ? 400 : 0), _scroll.ScrollableHeight);

        if (nx == _scroll.HorizontalOffset && ny == _scroll.VerticalOffset) return;

        _scroll.ScrollToHorizontalOffset(nx);
        _scroll.ScrollToVerticalOffset(ny);

        Coords.HorizontalOffset = nx;
        Coords.VerticalOffset = ny;
        _lastPointer = new Point(viewportPoint.X + nx, viewportPoint.Y + ny);
        _timeline.Drag.PointerMove(_lastPointer.X, _lastPointer.Y, Mods());
        MoveHintWithPointer();
    }

    public void HandleMediaDragOver(DragEventArgs e)
    {
        if (!TryGetMedia(e, out MediaItem? media))
        {
            e.Effects = DragDropEffects.None;
            e.Handled = true;
            return;
        }

        Point p = e.GetPosition(_canvas);
        _lastPointer = p;
        DropPreview preview = _timeline.Drop.Preview(media!, p.X, p.Y, _timeline.State.Position, Mods());

        ShowGhosts(new[] { (preview.TrackIndex, preview.Start, preview.Duration, preview.IsValid) });
        ShowTargetRow(preview.TrackIndex, preview.IsValid);

        if (preview.Snap is { } snap)
        {
            double x = Coords.TimeToContentX(snap.Time);
            _snapLine.X1 = x;
            _snapLine.X2 = x;
            _snapLine.Visibility = Visibility.Visible;
        }
        else
        {
            _snapLine.Visibility = Visibility.Collapsed;
        }

        if (!preview.IsValid && !string.IsNullOrEmpty(preview.Message)) ShowHint(preview.Message!, p);
        else if (preview.CreatesTrack) ShowHint("A new track will be created", p);
        else HideHint();

        Point vp = e.GetPosition(_scroll);
        var v = _timeline.AutoScroll.ComputeVelocity(vp.X, vp.Y, _scroll.ViewportWidth, _scroll.ViewportHeight);
        if (v.Dx != 0 || v.Dy != 0)
        {
            TimeSpan now = _autoScrollClock.Elapsed;
            TimeSpan dt = now - _lastAutoScrollTick;
            _lastAutoScrollTick = now;
            if (dt <= TimeSpan.Zero || dt > TimeSpan.FromMilliseconds(50)) dt = TimeSpan.FromMilliseconds(16);
            if (!_autoScrollClock.IsRunning) _autoScrollClock.Start();
            GrowCanvasIfNeeded(_scroll.HorizontalOffset + _scroll.ViewportWidth + 200);
            var (nx, ny) = _timeline.AutoScroll.Advance(v, dt, _scroll.HorizontalOffset, _scroll.VerticalOffset,
                _scroll.ScrollableWidth + (v.Dx > 0 ? 400 : 0), _scroll.ScrollableHeight);
            _scroll.ScrollToHorizontalOffset(nx);
            _scroll.ScrollToVerticalOffset(ny);
        }

        e.Effects = preview.IsValid ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    public void HandleMediaDragLeave() => HideOverlays();

    public void HandleMediaDrop(DragEventArgs e)
    {
        HideOverlays();
        if (!TryGetMedia(e, out MediaItem? media)) return;

        Point p = e.GetPosition(_canvas);
        DropOutcome outcome = _timeline.Drop.Drop(media!, p.X, p.Y, _timeline.State.Position, Mods());

        if (!outcome.Success)
        {
            if (!string.IsNullOrEmpty(outcome.Message)) ShowTransientHint(outcome.Message!, p);
        }
        else if (outcome.Clip is { } clip && _timeline.Selection.TrackOf(clip) is { } track)
        {
            _timeline.Select(track, clip);
            ModelChanged?.Invoke();
            SelectionChanged?.Invoke();
        }
        e.Handled = true;
    }

    private static bool TryGetMedia(DragEventArgs e, out MediaItem? media)
    {
        media = null;
        if (!e.Data.GetDataPresent(typeof(MediaItem))) return false;
        media = e.Data.GetData(typeof(MediaItem)) as MediaItem;
        return media is not null;
    }

    private static Brush Frozen(Color c)
    {
        SolidColorBrush b = new(c);
        b.Freeze();
        return b;
    }

    private static Brush CreateHatch()
    {
        Pen pen = new(new SolidColorBrush(Color.FromArgb(70, 255, 170, 60)), 1);
        GeometryDrawing drawing = new(null, pen, new LineGeometry(new Point(0, 8), new Point(8, 0)));
        DrawingBrush brush = new(drawing)
        {
            TileMode = TileMode.Tile,
            Viewbox = new Rect(0, 0, 8, 8),
            ViewboxUnits = BrushMappingMode.Absolute,
            Viewport = new Rect(0, 0, 8, 8),
            ViewportUnits = BrushMappingMode.Absolute
        };
        return brush;
    }
}