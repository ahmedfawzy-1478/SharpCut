﻿namespace CSharpVideoStudio;

public sealed class ProjectService
{
    public Project CreateNew(
        string name = "Untitled Project")
    {
        Project project =
            new Project
            {
                Name = name
            };

        project.EnsureDefaultTracks();

        return project;
    }
}