﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharpVideoStudio;

public sealed class PlaybackController : IDisposable
{
    private readonly Project _project;
    private readonly TimelineController _timeline;
    private readonly AudioPlaybackService _audio;

    private Guid _lastActiveAudioClipId = Guid.Empty;

    public TimeSpan Position { get; private set; }
    public bool IsPlaying { get; private set; }

    public double AudioVolume
    {
        get => _audio.MasterVolume;
        set => _audio.MasterVolume = Math.Clamp(value, 0.0, 1.0);
    }

    public event Action<TimeSpan>? PositionChanged;

    public event Action<string, TimeSpan>? VideoFrameRequested;
    public event Action<string>? ImageFrameRequested;
    public event Action? ClearFrameRequested;
    public event Action? VideoPauseRequested;

    public PlaybackController(Project project, TimelineController timeline)
    {
        _project = project;
        _timeline = timeline;
        _audio = new AudioPlaybackService();
    }

    public void Play()
    {
        IsPlaying = true;
        _audio.SyncAudio(_project, Position, isPlaying: true, isSeeking: true);
        UpdatePlaybackUI();
    }

    public void Pause()
    {
        IsPlaying = false;
        _audio.PauseAll();
        VideoPauseRequested?.Invoke();
        UpdatePlaybackUI();
    }

    public void Stop()
    {
        IsPlaying = false;
        Position = TimeSpan.Zero;
        _audio.StopAll();
        VideoPauseRequested?.Invoke();
        NotifyPosition();
        ClearFrameRequested?.Invoke();
    }

    public void Clear()
    {
        Stop();
    }

    public void Seek(TimeSpan newPosition)
    {
        Position = newPosition;
        if (Position < TimeSpan.Zero) Position = TimeSpan.Zero;
        if (Position > _project.Duration) Position = _project.Duration;

        _audio.SyncAudio(_project, Position, IsPlaying, isSeeking: true);
        UpdatePlaybackUI();
        NotifyPosition();
    }

    public void Update(TimeSpan deltaTime)
    {
        if (!IsPlaying) return;

        Position += deltaTime;
        if (Position >= _project.Duration)
        {
            Stop();
            return;
        }

        CheckAudioTransitions();
        UpdatePlaybackUI();
        NotifyPosition();
    }

    private void CheckAudioTransitions()
    {
        AudioClip? currentAudioClip = _project.Tracks
            .Where(t => t.Type == TrackType.Audio && !t.IsMuted)
            .SelectMany(t => t.Clips.OfType<AudioClip>())
            .FirstOrDefault(c => Position >= c.Start && Position < c.End && !c.Muted);

        Guid currentId = currentAudioClip?.Id ?? Guid.Empty;

        if (currentId != _lastActiveAudioClipId)
        {
            _lastActiveAudioClipId = currentId;
            _audio.SyncAudio(_project, Position, IsPlaying, isSeeking: false);
        }
    }

    private void UpdatePlaybackUI()
    {
        Clip? activeClip = _timeline.FindVisualClipAt(Position);

        if (activeClip != null)
        {
            TimeSpan sourcePosition = activeClip.SourceStart + (Position - activeClip.Start);

            if (activeClip is VideoClip videoClip)
            {
                VideoFrameRequested?.Invoke(videoClip.Media.FilePath, sourcePosition);
            }
            else if (activeClip is ImageClip imageClip)
            {
                ImageFrameRequested?.Invoke(imageClip.Media.FilePath);
                ClearFrameRequested?.Invoke();   // no video should keep playing under an image
            }
        }
        else
        {
            ClearFrameRequested?.Invoke();
        }
    }

    private void NotifyPosition()
    {
        PositionChanged?.Invoke(Position);
    }

    public void Dispose()
    {
        IsPlaying = false;
        VideoPauseRequested?.Invoke();
        ClearFrameRequested?.Invoke();
        _audio.Dispose();
    }
}