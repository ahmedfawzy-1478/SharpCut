﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Video_editor
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
    public partial class App : Application
    {
        public App()
        {
            this.DispatcherUnhandledException += (sender, e) =>
            {
                MessageBox.Show($"حدث خطأ غير متوقع:\n{e.Exception.Message}\n\n التفاصيل:\n{e.Exception.InnerException?.Message}");
                e.Handled = true;
            };
        }
    }

}
