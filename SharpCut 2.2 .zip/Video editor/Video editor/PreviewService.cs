﻿using System;
using System.Windows.Controls;

namespace CSharpVideoStudio.Playback;

public class PreviewService : IDisposable
{
    private readonly MediaElement _player;
    private string? _currentFilePath;

    
    private bool _isCurrentlyPlaying = false;

    public event Action<PreviewStatus, string?>? StatusChanged;

    public PreviewService(MediaElement player)
    {
        _player = player;
        _player.ScrubbingEnabled = true; // 🟢 دي بتخلي سحب الفيديو بالماوس (المونتاج) ناعم جداً
        _player.MediaOpened += (s, e) => StatusChanged?.Invoke(PreviewStatus.Ready, null);
        _player.MediaFailed += (s, e) => StatusChanged?.Invoke(PreviewStatus.Error, e.ErrorException?.Message ?? "فشل تشغيل الفيديو.");
    }

    public void Sync(string filePath, TimeSpan position, bool isPlaying, double volume, double speed = 1.0, double opacity = 1.0)
    {
        try
        {
            if (_player != null) _player.Opacity = Math.Clamp(opacity, 0.0, 1.0);

            if (_currentFilePath != filePath)
            {
                _currentFilePath = filePath;
                _player.Source = new Uri(filePath);
                _isCurrentlyPlaying = false;
            }

            double targetVolume = Math.Clamp(volume, 0.0, 1.0);
            if (Math.Abs(_player.Volume - targetVolume) > 0.01) _player.Volume = targetVolume;

            double targetSpeed = Math.Clamp(speed, 0.25, 4.0);
            if (Math.Abs(_player.SpeedRatio - targetSpeed) > 0.01) _player.SpeedRatio = targetSpeed;

           
            if (isPlaying)
            {
                if (!_isCurrentlyPlaying)
                {
                    _player.Play();
                    _isCurrentlyPlaying = true;
                }
            }
            else
            {
                if (_isCurrentlyPlaying)
                {
                    _player.Pause();
                    _isCurrentlyPlaying = false;
                }

                
                if (Math.Abs(_player.Position.TotalMilliseconds - position.TotalMilliseconds) > 100)
                {
                    _player.Position = position;
                }
            }
        }
        catch (Exception ex)
        {
            StatusChanged?.Invoke(PreviewStatus.Error, ex.Message);
        }
    }

    public void Pause()
    {
        if (_player != null && _isCurrentlyPlaying)
        {
            _player.Pause();
            _isCurrentlyPlaying = false;
        }
    }

    public void SetVolume(double volume)
    {
        if (_player != null) _player.Volume = Math.Clamp(volume, 0.0, 1.0);
    }

    public void Clear()
    {
        _currentFilePath = null;
        if (_player != null)
        {
            _player.Source = null;
            _player.Opacity = 1.0;
            _isCurrentlyPlaying = false;
        }
    }


    public void Dispose()
    {
        if (_player != null) _player.Source = null;
    }
}


public enum PreviewStatus
{
    Loading,
    Ready,
    Error
}
