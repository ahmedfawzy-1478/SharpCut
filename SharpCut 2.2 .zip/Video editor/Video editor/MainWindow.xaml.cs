﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using CSharpVideoStudio.Playback;
using CSharpVideoStudio.Timeline;

namespace CSharpVideoStudio;

public partial class MainWindow : Window
{
    private readonly ProjectService _projectService;
    private readonly MediaService _mediaService;
    private readonly MediaImportService _importService;

    private Project _project;
    private TimelineController _timeline;
    private PreviewService _preview;
    private PlaybackController _playback;
    private TimelineView _timelineView;

    private readonly DispatcherTimer _timer;
    private bool _isSeeking;
    private bool _isUpdatingSeekBar;
    private bool _isUpdatingClipVolume;
    private bool _isUpdatingClipSpeed;
    private bool _isUpdatingClipOpacity;

    private int _lastShownSecond = -1;
    private bool _isDraggingMedia;
    private string? _currentProjectPath;

    private DateTime _lastTick;

    public MainWindow()
    {
        
            InitializeComponent();

            _projectService = new ProjectService();
            _mediaService = new MediaService();
            _importService = new MediaImportService(_mediaService);

            _project = _projectService.CreateNew();
            _timeline = new TimelineController(_project);

            _preview = new PreviewService(PreviewVideo);
            _preview.StatusChanged += OnPreviewStatusChanged;

            _playback = new PlaybackController(_project, _timeline);

            _timelineView = new TimelineView(
                TimelineCanvas,
                TimelineRuler,
                Playhead,
                TimelineScrollViewer,
                RulerScrollViewer,
                HeadersScrollViewer,
                _timeline);

            SetupTimelineEvents();
            SetupPlaybackEvents();

            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(50)
            };

            _timer.Tick += Timer_Tick;
            _timer.Start();

            Loaded += MainWindow_Loaded;
            PreviewKeyDown += MainWindow_PreviewKeyDown;
        
        
    }
   

    private void SetupTimelineEvents()
    {
        _timelineView.SelectionChanged += () => RefreshInspector();

        _timelineView.ModelChanged += () =>
        {
            RefreshAll();
            _playback.Seek(_playback.Position);
        };

        _timelineView.SeekRequested += newPosition =>
        {
            _playback.Seek(newPosition);
            _timeline.State.Position = newPosition;
            RefreshPlaybackUI();
        };
    }

    private void SetupPlaybackEvents()
    {
        _playback.VideoPauseRequested += () => _preview?.Pause();

        _playback.VideoFrameRequested += (filePath, position) =>
        {
            Clip? activeClip = _timeline.FindVisualClipAt(_playback.Position);

            double clipVol = activeClip is VideoClip vClip ? vClip.Volume : (activeClip is AudioClip aClip ? aClip.Volume : 1.0);
            double clipSpeed = activeClip?.Speed ?? 1.0;
            double clipOpacity = activeClip?.Opacity ?? 1.0;

            _preview?.Sync(
                filePath,
                position,
                _playback.IsPlaying,
                Math.Clamp(clipVol * _playback.AudioVolume, 0.0, 1.0),
                clipSpeed,
                clipOpacity);
        };

        _playback.ClearFrameRequested += () => _preview?.Clear();
    }

    private void OpenButton_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog dialog = new OpenFileDialog
        {
            Filter = "Video Studio Project (*.cvsproj)|*.cvsproj|JSON Files (*.json)|*.json|All Files (*.*)|*.*"
        };

        if (dialog.ShowDialog() != true) return;

        try
        {
            string json = File.ReadAllText(dialog.FileName);
            Project? loadedProject = JsonSerializer.Deserialize<Project>(json);

            if (loadedProject != null)
            {
                _playback.Stop();
                _preview?.Clear();

                _project = loadedProject;
                _currentProjectPath = dialog.FileName;

                _timeline = new TimelineController(_project);
                _timelineView.SetTimeline(_timeline);
                _playback = new PlaybackController(_project, _timeline);

                SetupPlaybackEvents();
                RefreshAll();

                MessageBox.Show("تم فتح المشروع بنجاح!", "فتح مشروع", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"فشل فتح المشروع:\n{ex.Message}", "خطأ", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(_currentProjectPath))
        {
            SaveAsButton_Click(sender, e);
        }
        else
        {
            SaveProjectToDisk(_currentProjectPath);
        }
    }

    private void SaveAsButton_Click(object sender, RoutedEventArgs e)
    {
        SaveFileDialog dialog = new SaveFileDialog
        {
            Filter = "Video Studio Project (*.cvsproj)|*.cvsproj|JSON Files (*.json)|*.json",
            DefaultExt = ".cvsproj",
            FileName = "MyProject"
        };

        if (dialog.ShowDialog() != true) return;

        _currentProjectPath = dialog.FileName;
        SaveProjectToDisk(_currentProjectPath);
    }

    private void SaveProjectToDisk(string filePath)
    {
        try
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(_project, options);
            File.WriteAllText(filePath, json);

            MessageBox.Show("تم حفظ المشروع بنجاح!", "حفظ المشروع", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"تعذر حفظ المشروع:\n{ex.Message}", "خطأ", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void MainWindow_Loaded(object sender, RoutedEventArgs e) => RefreshAll();

    private void RefreshAll()
    {
        if (_timeline == null || _playback == null || _project == null) return;

        RefreshMediaList();
        RefreshTrackHeaders();
        RefreshTimeline();
        RefreshInspector();
        RefreshPlaybackUI();
    }

    private void RefreshMediaList()
    {
        MediaList.ItemsSource = null;
        MediaList.ItemsSource = _project.Media.ToList();
    }

    private void RefreshTrackHeaders()
    {
        TrackHeadersPanel.Children.Clear();

        foreach (Track track in _project.Tracks)
        {
            Track captured = track;
            Border header = new Border
            {
                Height = _timeline.Coordinates.TrackHeight,
                Background = new System.Windows.Media.SolidColorBrush(
                    track.IsLocked ? System.Windows.Media.Color.FromRgb(38, 31, 25) : System.Windows.Media.Color.FromRgb(25, 29, 36)),
                BorderBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(45, 50, 61)),
                BorderThickness = new Thickness(0, 0, 1, 1),
                Padding = new Thickness(10, 8, 5, 5)
            };

            DockPanel dock = new DockPanel();
            Button lockButton = new Button
            {
                Content = track.IsLocked ? "🔒" : "🔓",
                Width = 24,
                Height = 24,
                Padding = new Thickness(0),
                VerticalAlignment = VerticalAlignment.Top
            };

            lockButton.Click += (_, _) =>
            {
                _timeline.Editor.Commands.Execute(new SetTrackLockedCommand(captured, !captured.IsLocked));
                RefreshAll();
            };

            DockPanel.SetDock(lockButton, Dock.Right);
            dock.Children.Add(lockButton);

            StackPanel panel = new StackPanel();
            panel.Children.Add(new TextBlock { Text = track.Name, Foreground = System.Windows.Media.Brushes.White, FontWeight = FontWeights.SemiBold, FontSize = 11 });
            panel.Children.Add(new TextBlock { Text = track.Type == TrackType.Video ? "VIDEO" : "AUDIO", Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(135, 143, 158)), FontSize = 9 });

            dock.Children.Add(panel);
            header.Child = dock;
            TrackHeadersPanel.Children.Add(header);
        }

        for (int i = 0; i < 3; i++)
        {
            TrackHeadersPanel.Children.Add(new Border { Height = _timeline.Coordinates.TrackHeight });
        }
    }

    private void RefreshTimeline() => _timelineView.Rebuild(_playback.Position);

    private void RefreshInspector()
    {
        Clip? clip = _timeline.Selection.Clip;

        if (clip == null)
        {
            InspectorName.Text = "None";
            InspectorStart.Text = "00:00";
            InspectorDuration.Text = "00:00";
            InspectorType.Text = "-";

            _isUpdatingClipVolume = _isUpdatingClipSpeed = _isUpdatingClipOpacity = true;

            ClipVolumeSlider.Value = 1.0;
            InspectorVolumeText.Text = "100%";
            ClipVolumeSlider.IsEnabled = false;

            ClipSpeedSlider.Value = 1.0;
            InspectorSpeedText.Text = "1.0x";
            ClipSpeedSlider.IsEnabled = false;

            ClipOpacitySlider.Value = 1.0;
            InspectorOpacityText.Text = "100%";
            ClipOpacitySlider.IsEnabled = false;

            _isUpdatingClipVolume = _isUpdatingClipSpeed = _isUpdatingClipOpacity = false;
            return;
        }

        InspectorName.Text = clip.Media.FileName;
        InspectorStart.Text = FormatTime(clip.Start);
        InspectorDuration.Text = FormatTime(clip.Duration);
        InspectorType.Text = clip switch { VideoClip => "Video", AudioClip => "Audio", ImageClip => "Image", _ => "Unknown" };

        _isUpdatingClipVolume = _isUpdatingClipSpeed = _isUpdatingClipOpacity = true;

        ClipVolumeSlider.IsEnabled = clip is AudioClip || clip is VideoClip;
        ClipVolumeSlider.Value = clip.Volume;
        InspectorVolumeText.Text = $"{(int)(clip.Volume * 100)}%";

        ClipSpeedSlider.IsEnabled = clip is AudioClip || clip is VideoClip;
        ClipSpeedSlider.Value = clip.Speed;
        InspectorSpeedText.Text = $"{clip.Speed:0.00}x";

        ClipOpacitySlider.IsEnabled = clip is VideoClip || clip is ImageClip;
        ClipOpacitySlider.Value = clip.Opacity;
        InspectorOpacityText.Text = $"{(int)(clip.Opacity * 100)}%";

        _isUpdatingClipVolume = _isUpdatingClipSpeed = _isUpdatingClipOpacity = false;
    }

    private void ClipVolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_isUpdatingClipVolume || _timeline == null || _playback == null) return;
        Clip? clip = _timeline.Selection?.Clip;
        if (clip != null)
        {
            clip.Volume = Math.Clamp(e.NewValue, 0.0, 1.0);
            InspectorVolumeText.Text = $"{(int)(clip.Volume * 100)}%";
            _playback.Seek(_playback.Position);
        }
    }

    private void ClipSpeedSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_isUpdatingClipSpeed || _timeline == null || _playback == null) return;
        Clip? clip = _timeline.Selection?.Clip;
        if (clip != null)
        {
            clip.Speed = Math.Clamp(e.NewValue, 0.25, 4.0);
            InspectorSpeedText.Text = $"{clip.Speed:0.00}x";

            RefreshTimeline();
            _playback.Seek(_playback.Position);
        }
    }

    private void ClipOpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_isUpdatingClipOpacity || _timeline == null || _playback == null) return;
        Clip? clip = _timeline.Selection?.Clip;
        if (clip != null)
        {
            clip.Opacity = Math.Clamp(e.NewValue, 0.0, 1.0);
            InspectorOpacityText.Text = $"{(int)(clip.Opacity * 100)}%";

            _playback.Seek(_playback.Position);
        }
    }

    private void RefreshPlaybackUI()
    {
        if (_timeline == null || _playback == null || _project == null) return;

        TimeSpan position = _playback.Position;
        _timeline.State.Position = position;
        TimeSpan duration = _project.Duration;

        _timelineView?.UpdatePlayhead(position);

        int currentSecond = (int)position.TotalSeconds;

        if (currentSecond != _lastShownSecond || Math.Abs(PreviewSeekBar.Maximum - duration.TotalSeconds) > 0.1)
        {
            _lastShownSecond = currentSecond;
            CurrentTimeText.Text = FormatTime(position);
            DurationText.Text = FormatTime(duration);

            double max = Math.Max(1, duration.TotalSeconds);
            if (PreviewSeekBar.Maximum != max) PreviewSeekBar.Maximum = max;

            if (!_isSeeking)
            {
                _isUpdatingSeekBar = true;
                PreviewSeekBar.Value = Math.Clamp(position.TotalSeconds, 0, max);
                _isUpdatingSeekBar = false;
            }
        }

        string label = _playback.IsPlaying ? "Pause" : "Play";
        if (!Equals(PlayButton.Content, label)) PlayButton.Content = label;
    }

    private static string FormatTime(TimeSpan value) => value.TotalHours >= 1 ? value.ToString(@"hh\:mm\:ss") : value.ToString(@"mm\:ss");

    private void Timer_Tick(object? sender, EventArgs e)
    {
        DateTime now = DateTime.UtcNow;
        if (_lastTick == default) { _lastTick = now; return; }

        TimeSpan elapsed = now - _lastTick;
        _lastTick = now;

        if (_playback.IsPlaying)
        {
            _playback.Update(elapsed);
            RefreshPlaybackUI();
        }
    }

    private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        double newVolume = Math.Clamp(e.NewValue, 0.0, 1.0);
        if (_playback != null) _playback.AudioVolume = newVolume;
    }

    private void ExtractAudioButton_Click(object sender, RoutedEventArgs e)
    {
        Track? track = _timeline.Selection.Track;
        Clip? clip = _timeline.Selection.Clip;

        if (track == null || clip is not VideoClip videoClip)
        {
            MessageBox.Show("يرجى تحديد مقطع فيديو على التايم لاين أولاً لاستخراج الصوت منه.", "فصل الصوت", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        AudioClip? extractedAudio = _timeline.ExtractAudio(track, videoClip);
        if (extractedAudio != null)
        {
            RefreshAll();
            MessageBox.Show("تم استخراج الصوت بنجاح وإضافته إلى مسار الصوت!", "فصل الصوت", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private async void AddMediaButton_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog dialog = new OpenFileDialog
        {
            Multiselect = true,
            Filter = "Media files|*.mp4;*.mkv;*.avi;*.mov;*.wmv;*.webm;*.mp3;*.wav;*.aac;*.flac;*.m4a;*.png;*.jpg;*.jpeg;*.bmp;*.webp|All files|*.*"
        };

        if (dialog.ShowDialog() != true) return;

        foreach (string file in dialog.FileNames)
        {
            MediaItem? item = await _importService.ImportAsync(file);
            if (item == null) continue;
            _timeline.Editor.AddMedia(item);
        }

        RefreshMediaList();
    }

    private void MediaList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => AddSelectedMediaToTimeline();

    private void MediaList_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || _isDraggingMedia) return;
        if (MediaList.SelectedItem is not MediaItem media) return;

        _isDraggingMedia = true;
        try
        {
            DragDrop.DoDragDrop(MediaList, new DataObject(typeof(MediaItem), media), DragDropEffects.Copy);
        }
        finally
        {
            _isDraggingMedia = false;
        }
    }

    private void AddSelectedToTimelineButton_Click(object sender, RoutedEventArgs e) => AddSelectedMediaToTimeline();

    private void AddSelectedMediaToTimeline()
    {
        if (MediaList.SelectedItem is not MediaItem media) return;

        DropOutcome outcome = _timeline.Drop.AddAtPlayhead(media, _playback.Position);
        if (!outcome.Success)
        {
            MessageBox.Show(outcome.Message ?? "Can't add this media to the timeline.", "Timeline", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (outcome.Clip is { } clip && _timeline.Selection.TrackOf(clip) is { } track)
        {
            _timeline.Select(track, clip);
        }

        RefreshAll();
    }

    private void TimelineScrollViewer_Drop(object sender, DragEventArgs e) => _timelineView.HandleMediaDrop(e);
    private void TimelineScrollViewer_DragOver(object sender, DragEventArgs e) => _timelineView.HandleMediaDragOver(e);
    private void TimelineScrollViewer_DragLeave(object sender, DragEventArgs e) => _timelineView.HandleMediaDragLeave();

    private void PlayButton_Click(object sender, RoutedEventArgs e)
    {
        if (_playback.IsPlaying)
        {
            _playback.Pause();
        }
        else
        {
            _playback.Play();
        }

        RefreshPlaybackUI();
    }

    private void OnPreviewStatusChanged(PreviewStatus status, string? message)
    {
        Dispatcher.BeginInvoke(new Action(() =>
        {
            PreviewStatusText.Text = status switch
            {
                PreviewStatus.Loading => "Loading…",
                PreviewStatus.Error => message ?? "Unable to play this media file.",
                _ => string.Empty
            };

            PreviewStatusText.Visibility = string.IsNullOrEmpty(PreviewStatusText.Text) ? Visibility.Collapsed : Visibility.Visible;
            if (status == PreviewStatus.Error && _playback.IsPlaying) _playback.Pause();
        }));
    }

    private void PreviewSeekBar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_isUpdatingSeekBar || _isSeeking || !IsLoaded) return;
        _playback.Seek(TimeSpan.FromSeconds(e.NewValue));
        RefreshPlaybackUI();
    }

    private void PreviewSeekBar_PreviewMouseDown(object sender, MouseButtonEventArgs e) => _isSeeking = true;

    private void PreviewSeekBar_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        _isSeeking = false;
        _playback.Seek(TimeSpan.FromSeconds(PreviewSeekBar.Value));
        RefreshPlaybackUI();
    }

    private void RewindButton_Click(object sender, RoutedEventArgs e) => _playback.Seek(_playback.Position - TimeSpan.FromSeconds(10));
    private void ForwardButton_Click(object sender, RoutedEventArgs e) => _playback.Seek(_playback.Position + TimeSpan.FromSeconds(10));

    private void PreviousButton_Click(object sender, RoutedEventArgs e)
    {
        Clip? previous = _project.Tracks.SelectMany(x => x.Clips).Where(x => x.Start < _playback.Position).OrderByDescending(x => x.Start).FirstOrDefault();
        if (previous == null) { _playback.Seek(TimeSpan.Zero); return; }
        _playback.Seek(previous.Start);
    }

    private void NextButton_Click(object sender, RoutedEventArgs e)
    {
        Clip? next = _project.Tracks.SelectMany(x => x.Clips).Where(x => x.Start > _playback.Position).OrderBy(x => x.Start).FirstOrDefault();
        if (next != null) _playback.Seek(next.Start);
    }

    private void UndoButton_Click(object sender, RoutedEventArgs e) { _timeline.Undo(); RefreshAll(); }
    private void RedoButton_Click(object sender, RoutedEventArgs e) { _timeline.Redo(); RefreshAll(); }
    private void DeleteButton_Click(object sender, RoutedEventArgs e) => DeleteSelectedClips();

    private void DeleteSelectedClips()
    {
        if (_timeline.DeleteSelected() == 0) return;
        RefreshAll();
        _playback.Seek(_playback.Position);
    }

    private void SplitButton_Click(object sender, RoutedEventArgs e)
    {
        Track? track = _timeline.Selection.Track;
        Clip? clip = _timeline.Selection.Clip;
        if (track == null || clip == null) return;

        TimeSpan splitPosition = _playback.Position;
        TimeSpan clipEnd = clip.Start + clip.Duration;
        if (splitPosition <= clip.Start || splitPosition >= clipEnd) return;

        SplitClipCommand command = new SplitClipCommand(track, clip, splitPosition);
        _timeline.Editor.Commands.Execute(command);
        _timeline.Select(track, command.FirstClip);
        RefreshAll();
    }

    private void TrimButton_Click(object sender, RoutedEventArgs e)
    {
        Track? track = _timeline.Selection.Track;
        Clip? clip = _timeline.Selection.Clip;
        if (track == null || clip == null) return;

        TimeSpan newDuration = _playback.Position - clip.Start;
        if (newDuration <= TimeSpan.Zero || newDuration >= clip.Duration) return;

        _timeline.TrimClip(track, clip, clip.SourceStart, newDuration, clip.Start);
        RefreshAll();
    }

    private void ZoomInButton_Click(object sender, RoutedEventArgs e) { _timeline.Coordinates.PixelsPerSecond *= 1.25; RefreshTimeline(); }
    private void ZoomOutButton_Click(object sender, RoutedEventArgs e) { _timeline.Coordinates.PixelsPerSecond /= 1.25; RefreshTimeline(); }

    private void SnapCheckBox_Changed(object sender, RoutedEventArgs e)
    {
        if (_timeline == null) return;
        _timeline.Snap.Enabled = SnapCheckBox.IsChecked == true;
    }

    private void NewButton_Click(object sender, RoutedEventArgs e)
    {
        _playback.Stop();
        _preview?.Clear();

        _project = _projectService.CreateNew();
        _currentProjectPath = null;

        _timeline = new TimelineController(_project);
        _timeline.Snap.Enabled = SnapCheckBox.IsChecked == true;
        _timelineView.SetTimeline(_timeline);

        _playback = new PlaybackController(_project, _timeline);
        SetupPlaybackEvents();
        RefreshAll();
    }

    private void ExportButton_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show("تصدير MP4 سيتم تفعيله في خطوة التصدير القادمة.", "تصدير", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.OriginalSource is TextBox) return;
        ModifierKeys mods = Keyboard.Modifiers;

        if (e.Key == Key.Escape)
        {
            if (_timelineView.CancelDrag()) e.Handled = true;
        }
        else if (e.Key == Key.Delete) { DeleteSelectedClips(); e.Handled = true; }
        else if (e.Key == Key.Z && mods == ModifierKeys.Control) { _timeline.Undo(); RefreshAll(); e.Handled = true; }
        else if (e.Key == Key.Y && mods == ModifierKeys.Control) { _timeline.Redo(); RefreshAll(); e.Handled = true; }
    }

    protected override void OnClosed(EventArgs e)
    {
        _timer.Stop();
        _playback?.Dispose();
        _preview?.Dispose();
        base.OnClosed(e);
    }
}