# Integration notes

## Projects
- `CSharpVideoStudio.Core` (net8.0, no WPF): model, commands, and the timeline interaction system
  (`Timeline/`: TimelineCoordinateService, FrameRate, TimelineSnapEngine, TimelineValidationService,
  TimelineDragController, TimelineDropController, TimelineAutoScrollService, TrackPicker, TimelineCommands).
- `CSharpVideoStudio.Playback` (net8.0): PlaybackStateMachine, MediaPlayerSession, IPlaybackBackend.
- `Video editor` (WPF, net9.0-windows): `TimelineView` (UI only), `PreviewService` + `LibVlcPlaybackBackend` (LibVLCSharp), MainWindow.
- `CSharpVideoStudio.Tests`: `dotnet run --project CSharpVideoStudio.Tests` (core + playback logic, no WPF needed).

## Timeline interaction design
- Drag state machine: Idle -> PotentialDrag (4px threshold) -> Dragging -> Commit | Cancel (Esc / lost capture).
- The model is NOT touched during MouseMove: the controller only produces a `DragPreview` (ghosts, target track,
  snap point, validity + reason). MouseUp executes ONE command (`MoveClipsCommand`, or trim command).
- All Time<->Pixel / Y<->Track math is in `TimelineCoordinateService`; hit-testing is model based, not visual tree.
- Group / linked moves are validated as a whole (no partial moves). Locked tracks block moves in, out and edits.
- Rounding: `FrameRate.FrameToTime` rounds UP so TimeToFrame(FrameToTime(n)) == n (nearest-rounding broke this; found by a test).

## NOT verified in my environment
The WPF project was NOT compiled or run (no Windows desktop SDK / NuGet access here). Only the Core/Playback/Tests
projects were built and executed. `TimelineView.cs`, `MainWindow.xaml(.cs)` were only checked for syntax and for
references to Core types. Expect a few small compile errors on first build in Visual Studio.

# Timeline interaction redesign
- `CSharpVideoStudio.Core` (net8.0, WPF-free): model + commands + `Timeline/` services
  (CoordinateService, SnapEngine, DragController state machine, DropController, ValidationService, AutoScrollService, TrackPicker, FrameRate).
- `Video editor/TimelineView.cs`: WPF view only (mouse capture, ghost/target-track overlays, snap line, auto-scroll timer, Escape cancel). Drag never touches the model until MouseUp (one command).
- Tests: `dotnet run --project CSharpVideoStudio.Tests` -> 122 checks (playback + timeline).
- NOT verified: WPF project compile/run (needs Windows + NuGet). Build in Visual Studio and report errors.

# Preview / playback repair (MP4 freeze, Video Overview, MP3 vertical move)
Changed: `LibVlcPlaybackBackend` (single-thread actor; no LibVLC call inside LibVLC callbacks; cached Position; coalesced seeks),
`CSharpVideoStudio.Playback/PreviewDirector.cs` (all preview decisions, idempotent per tick, rate-limited drift correction, failure memory),
`PreviewService` (thin wiring), `MainWindow` (status overlay on the VideoView, status marshalled to UI thread),
`TimelineController.FindVisualClipAt` + `PlaybackController` (audio clips no longer hide/replace the video lookup),
`Project.EnsureDefaultTracks` (2 video + 2 audio lanes).
Tests: `dotnet run --project CSharpVideoStudio.Tests` -> 178 checks.

## Manual verification checklist (needs Windows; NOT done by the assistant)
1. Build in Visual Studio (restores LibVLCSharp.WPF + VideoLAN.LibVLC.Windows).
2. Add an MP4 (>40 s), press Play, let it run past 0:11 and to ~0:40: UI must stay responsive (move the window, click the timeline).
3. Pause/Play 20x, seek while paused and while playing, split the clip and play across the cut.
4. MP4 then MP3 then MP4 on the timeline; end of project; delete the file on disk and press Play (should show an error line, not hang).
5. Drag an MP3 from Audio 1 to Audio 2 (both tracks exist in new projects); undo/redo.
If the freeze persists: capture a dump of the hung process (Task Manager -> Create dump file) and try LibVLC option `--avcodec-hw=none` in PreviewService.
